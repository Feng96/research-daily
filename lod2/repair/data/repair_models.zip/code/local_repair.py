"""Observation-constrained component reassignment; frozen scores, no new DL head.

Input XYZ is read-only. A replacement is a generated plane hypothesis, not a
new observation. Local settings are a development probe, not calibrated accuracy.
"""
import copy
import numpy as np
from shapely import intersects_xy
from shapely.geometry import Polygon, MultiPoint, LineString
from shapely.geometry.polygon import orient
from shapely.ops import unary_union

CONFIG=dict(anchor_area_m2=10.,anchor_seed_points=30,roof_score=.7,band_m=.25,
            anchor_mean_score=.65,suspect_max_area_m2=80.,suspect_max_seed_points=14,
            suspect_mean_score=.4,minimum_new_support=6,minimum_support_gain=4,
            minimum_support_ratio=1.25,adjacency_m=.3)

def height(plane,xy):
    xy=np.asarray(xy);return plane['center'][2]-((xy-plane['center'][:2])@plane['normal'][:2])/plane['normal'][2]

def patches(model):
    rows=[]
    for i,s in enumerate(model['surfaces']):
        if s['type']!='RoofSurface':continue
        a=np.asarray(s['rings'][0],float);a=a[:-1] if np.array_equal(a[0],a[-1]) else a
        if len(a)<3:continue
        center=a.mean(0);normal=np.linalg.svd(a-center,full_matrices=False)[2][-1]
        if normal[2]<0:normal=-normal
        poly=Polygon(a[:,:2],[np.asarray(r)[:,:2] for r in s['rings'][1:]])
        if poly.is_valid and poly.area>1e-6 and normal[2]>.05:rows.append(dict(index=i,polygon=poly,center=center,normal=normal))
    return rows

def propose(model,xyz,keep,score,config=CONFIG):
    ps=patches(model);anchors=[];rows=[];replacement={}
    for p in ps:
        inside=keep&intersects_xy(p['polygon'],xyz[:,0],xyz[:,1]);on=inside&(np.abs((xyz-p['center'])@p['normal'])<=config['band_m']);seed=on&(score>=config['roof_score'])
        p.update(support=int(on.sum()),strong=int(seed.sum()),mean=float(score[on].mean()) if on.any() else 0.)
        if p['polygon'].area>=config['anchor_area_m2'] and p['strong']>=config['anchor_seed_points'] and p['mean']>=config['anchor_mean_score'] and p['normal'][2]>=.5:
            # Fit only original roof-like observations already near this anchor.
            c=xyz[seed].mean(0);n=np.linalg.svd(xyz[seed]-c,full_matrices=False)[2][-1];n*=1 if n[2]>=0 else -1
            q=dict(p,center=c,normal=n);anchors.append(q)
    for p in ps:
        row=dict(surface_index=p['index'],area_m2=float(p['polygon'].area),own_support=p['support'],own_strong_support=p['strong'],own_mean_score=p['mean'],action='keep',alternatives=[])
        suspect=p['polygon'].area<=config['suspect_max_area_m2'] and p['strong']<=config['suspect_max_seed_points'] and (p['mean']<config['suspect_mean_score'] or p['support']<6)
        if suspect:
            inside=keep&intersects_xy(p['polygon'],xyz[:,0],xyz[:,1])
            for a in anchors:
                if a['index']==p['index'] or p['polygon'].distance(a['polygon'])>config['adjacency_m']:continue
                on=inside&(np.abs((xyz-a['center'])@a['normal'])<=config['band_m']);strong=on&(score>=config['roof_score']);n=int(strong.sum())
                local=xyz[strong,:2];hull=MultiPoint(local).convex_hull if len(local) else Polygon()
                coverage=float(hull.buffer(.35).intersection(p['polygon']).area/p['polygon'].area) if len(local) else 0.
                accepted=n>=config['minimum_new_support'] and n>=p['strong']+config['minimum_support_gain'] and n>=max(1,p['strong'])*config['minimum_support_ratio']
                row['alternatives'].append(dict(anchor_surface=a['index'],support=int(on.sum()),strong_support=n,local_support_coverage_fraction=coverage,eligible=bool(accepted)))
            candidates=[x for x in row['alternatives'] if x['eligible']]
            if candidates:
                best=max(candidates,key=lambda x:x['strong_support']);anchor=next(a for a in anchors if a['index']==best['anchor_surface']);replacement[p['index']]=next(x for x in ps if x['index']==anchor['index'])
                row.update(action='candidate_reassign_and_refit',selected=best,anchor_geometry='reuse existing observation-fitted anchor exactly; seed refit used for evidence only',
                    extrapolation_uncertain=True,reason='more original roof-like observations agree with an adjacent supported plane; not target truth')
            else:row['action']='uncertain_no_supported_replacement'
        rows.append(row)
    return replacement,rows

def stitch(model,replacements):
    """Rebuild walls between the original XY roof partition and assigned planes.

    XY partition and holes stay fixed. Generated faces are flagged. Vertically
    aligned vertices are subdivided so real steps remain closed without filling
    them as sloped roof. An edge diagnostic is still not a solid certificate.
    """
    original=patches(model);polys=[]
    for p in original:
        rings=[np.round(np.asarray(p['polygon'].exterior.coords),3)]+[np.round(np.asarray(r.coords),3) for r in p['polygon'].interiors]
        poly=Polygon(rings[0],rings[1:]);assert poly.is_valid
        polys.append(dict(p,polygon=orient(poly,sign=1),**({'center':replacements[p['index']]['center'],'normal':replacements[p['index']]['normal']} if p['index'] in replacements else {})))
    network=unary_union([p['polygon'].boundary for p in polys]);lines=list(network.geoms) if hasattr(network,'geoms') else [network]
    edges=[]
    for line in lines:
        xy=list(line.coords)
        for a,b in zip(xy,xy[1:]):
            if np.linalg.norm(np.subtract(a,b))>1e-8:edges.append((np.asarray(a),np.asarray(b)))
    # Also split edges where two assigned planes cross.
    split=[]
    for a,b in edges:
        mid=(a+b)/2;near=[p for p in polys if p['polygon'].boundary.distance(LineString([mid,mid+1e-10]))<1e-6]
        if len(near)==2:
            delta=[float(height(near[0],q)-height(near[1],q)) for q in [a,b]]
            if delta[0]*delta[1]<-1e-10:
                t=delta[0]/(delta[0]-delta[1]);c=a+t*(b-a);split.extend([(a,c),(c,b)]);continue
        split.append((a,b))
    edges=split;nodes=np.unique(np.round(np.vstack([q for edge in edges for q in edge]),8),axis=0);surfaces=[]
    def noded_ring(r,plane):
        xy=np.asarray(r.coords);out=[]
        for a,b in zip(xy,xy[1:]):
            v=b-a;l=v@v;t=((nodes-a)@v)/l;d=np.linalg.norm(nodes-(a+t[:,None]*v),axis=1);take=np.flatnonzero((t>=-1e-7)&(t<1-1e-7)&(d<1e-6))
            for k in take[np.argsort(t[take])]:out.append([*nodes[k],float(height(plane,nodes[k]))])
        return out+[out[0]]
    for p in polys:
        surfaces.append(dict(type='RoofSurface',rings=[noded_ring(p['polygon'].exterior,p)]+[noded_ring(r,p) for r in p['polygon'].interiors],source_surface_index=p['index'],generated_local_refit=p['index'] in replacements))
    ground=float(model['ground_z']);bottom=dict(center=np.array([0.,0.,ground]),normal=np.array([0.,0.,1.]))
    for a,b in edges:
        mid=(a+b)/2;near=[p for p in polys if p['polygon'].boundary.distance(LineString([mid,mid+1e-10]))<1e-6]
        if not near:raise ValueError('No incident roof')
        if len(near)>2:raise ValueError('More than two incident roofs')
        high=max(near,key=lambda p:float(height(p,mid)));low=min(near,key=lambda p:float(height(p,mid))) if len(near)==2 else bottom
        za,zb=float(height(high,a)),float(height(high,b));la,lb=float(height(low,a)),float(height(low,b))
        if max(abs(za-la),abs(zb-lb))<1e-6:continue
        # Use direction in the CCW high-face boundary (interior on its left).
        v=b-a;left=mid+np.array([-v[1],v[0]])/np.linalg.norm(v)*1e-5
        if not high['polygon'].covers(__import__('shapely').geometry.Point(left)):
            a,b=b,a;za,zb=zb,za;la,lb=lb,la
        ring=[[*a,za],[*a,la],[*b,lb],[*b,zb]]
        cleaned=[]
        for q in ring:
            if not cleaned or np.linalg.norm(np.subtract(q,cleaned[-1]))>1e-7:cleaned.append(q)
        if len(cleaned)>2:surfaces.append(dict(type='WallSurface',rings=[cleaned+[cleaned[0]]],generated_local_refit=True))
    union=unary_union([p['polygon'] for p in polys]);parts=list(union.geoms) if hasattr(union,'geoms') else [union]
    for part in parts:
        g=orient(part,sign=-1);surfaces.append(dict(type='GroundSurface',rings=[noded_ring(g.exterior,bottom)]+[noded_ring(r,bottom) for r in g.interiors]))
    # A wall edge at a triple roof junction can span multiple real step levels.
    levels={}
    for s in surfaces:
        for r in s['rings']:
            for x,y,z in r:levels.setdefault((round(x,7),round(y,7)),set()).add(z)
    for s in surfaces:
        for ri,ring in enumerate(s['rings']):
            out=[]
            for a,b in zip(ring,ring[1:]):
                out.append(a)
                if np.linalg.norm(np.subtract(a[:2],b[:2]))<1e-7 and abs(a[2]-b[2])>1e-7:
                    zz=sorted(z for z in levels[(round(a[0],7),round(a[1],7))] if min(a[2],b[2])+1e-7<z<max(a[2],b[2])-1e-7)
                    if a[2]>b[2]:zz.reverse()
                    out.extend([[*a[:2],z] for z in zz])
            s['rings'][ri]=out+[out[0]]
    result=copy.deepcopy(model);result['surfaces']=surfaces;result['method']='observation_local_refit_probe';result['generated_geometry']=True;result['original_XYZ_modified']=False
    return result
