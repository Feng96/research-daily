from pathlib import Path
import sys,json,hashlib,importlib.util,copy,subprocess,os
import numpy as np
from shapely.geometry import box,Polygon,mapping
from shapely import intersects_xy
from local_repair import propose,stitch,patches,height,CONFIG
H=Path('/nfs/home/yfeng21');ROOT=Path('/lustre/isaac24/scratch/yfeng21/lod2_local_repair_20261022');RUN=ROOT/'runs/local8_v3';O=Path('/lustre/isaac24/scratch/yfeng21/lod2_workflow_20261022/runs/smoke8_v1');C=Path('/lustre/isaac24/scratch/yfeng21/lod2_canopy_20261022/runs/probe8_v1')
def load(p):return json.loads(Path(p).read_text())
def dump(p,d):p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def mod(n,p):s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
G=mod('local_geometry_audit',H/'lod2_pilot_20261017/tools/evaluate_pilot.py')

def run_real():
    front=np.load(O/'evidence/frontend_decisions.npz');probs=np.load(O/'evidence/target_probabilities.npz');models=load(C/'products/guarded.json')['buildings'];rows=[];products=[]
    for model in models:
        bid=model['pilot_id'];d=np.load(C/'buildings'/bid/'decisions.npz');xyz=d['original_XYZ'];sha=hashlib.sha256(xyz.tobytes()).hexdigest();ix=np.searchsorted(front['source_indices'],d['source_indices']);p=probs['point'][ix,0];keep=d['guarded_keep']
        replacement,decisions=propose(model,xyz,keep,p);candidate=stitch(model,replacement) if replacement else copy.deepcopy(model)
        before=G.edge_statistics(model['surfaces']);after=G.edge_statistics(candidate['surfaces']);ok=after['all_edges_have_two_incidences'] and after['orientation_inconsistent_edges']==0
        # Store candidate and reject from accepted product if shell diagnostic regresses.
        selected=candidate if ok else copy.deepcopy(model)
        changes=[x for x in decisions if x['action']=='candidate_reassign_and_refit']
        displacement=[]
        for old in patches(model):
            if old['index'] in replacement:
                xy=np.asarray(old['polygon'].exterior.coords);displacement.extend((height(replacement[old['index']],xy)-height(old,xy)).tolist())
        anchors=[x for x in patches(model) if x['polygon'].area>=100]
        unchanged=[]
        for a in anchors:
            assert a['index'] not in replacement
            b=next(x for x in patches(candidate) if candidate['surfaces'][x['index']].get('source_surface_index',x['index'])==a['index']) if replacement else a
            xy=np.asarray(a['polygon'].exterior.coords);unchanged.append(dict(source_surface=a['index'],area_m2=float(a['polygon'].area),max_height_change_m=float(np.max(np.abs(height(a,xy)-height(b,xy))))))
        assert hashlib.sha256(xyz.tobytes()).hexdigest()==sha
        row=dict(id=bid,proposed_components=len(changes),accepted_components=len(changes) if ok else 0,decisions=decisions,
            shell_before=before,shell_after=after,shell_diagnostic_passed=bool(ok),candidate_is_accuracy_verified=False,
            max_absolute_candidate_vertex_change_m=float(np.max(np.abs(displacement))) if displacement else 0,
            large_roof_preservation=unchanged,original_xyz_sha256=sha,original_xyz_unchanged=True,point_deletion_change=0,
            caveat='Same observations inform selection and fit. This is a development candidate, not an independent accuracy measurement.')
        dump(RUN/'buildings'/bid/'audit.json',row);dump(RUN/'buildings'/bid/'candidate.json',candidate);products.append(selected);rows.append(row)
        print('REAL',bid,'candidates',len(changes),'shell',ok,'large roofs delta',max([r['max_height_change_m'] for r in unchanged]or[0]),flush=True)
    dump(RUN/'products/local.json',dict(crs='EPSG:26985',buildings=products));return rows

def fixtures():
    """Analytic roofs: truth is used only for generation and final scoring.
    Corruption is deliberately bounded; these are mechanism tests, not a roof GT benchmark.
    """
    cases=['clean_step','real_raised_detail','real_depressed_detail','model_bump','model_dip','scattered_high','coherent_canopy','complete_occlusion']
    records=[];features=[];prepared=[];feat=mod('local_feature_extractor',H/'lod2_tree_20261020/tools/features.py')
    for seed in range(6):
        rng=np.random.default_rng(220100+seed);slope=rng.uniform(-.08,.08,2);step=rng.uniform(1.8,3);left=box(0,0,12,12);right=box(12,0,20,12);patch=box(16,0,20,4);rest=right.difference(patch)
        for case in cases:
            real_delta=2 if case=='real_raised_detail' else -1.5 if case=='real_depressed_detail' else 0
            def ztrue(xy,slope=slope.copy(),step=float(step),real_delta=float(real_delta)):return 12+xy@slope-np.where(xy[:,0]>=12,step,0)+np.where((xy[:,0]>=16)&(xy[:,1]<=4),real_delta,0)
            xy=rng.uniform([0,0],[20,12],(2400,2));z=ztrue(xy);xyz=np.c_[xy,z+rng.normal(0,.04,len(xy))];inside=(xy[:,0]>=16)&(xy[:,1]<=4)
            if case in ['scattered_high','coherent_canopy']:
                n=120;q=rng.uniform([16,0],[20,4],(n,2));h=3+rng.normal(0,.04 if case=='coherent_canopy' else 1.,n);xyz=np.vstack([xyz,np.c_[q,ztrue(q)+h]])
            if case=='complete_occlusion':xyz=xyz[~inside]
            bad=3 if case in ['model_bump','scattered_high','coherent_canopy','complete_occlusion'] else -3 if case=='model_dip' else real_delta
            surfaces=[]
            for poly,offset in [(left,0),(rest,-step),(patch,-step+bad)]:
                rr=[]
                for ring in [poly.exterior,*poly.interiors]:
                    a=np.asarray(ring.coords);rr.append(np.c_[a,12+a@slope+offset].tolist())
                surfaces.append(dict(type='RoofSurface',rings=rr))
            model=dict(pilot_id=f'analytic-{seed}-{case}',surfaces=surfaces,footprint=mapping(box(0,0,20,12)),ground_z=0.,status='success')
            groundxy=rng.uniform([-5,-5],[25,17],(200,2));context=np.vstack([xyz,np.c_[groundxy,np.zeros(200)]]);g,_=feat.geometry_features(xyz,context,np.ones(len(xyz)),np.ones(len(xyz)));features.append(g)
            prepared.append((model,xyz,ztrue,case,seed));records.append(dict(id=model['pilot_id'],case=case,seed=seed,start=sum(len(x) for x in features[:-1]),count=len(g)))
    f=RUN/'controlled/features.npz';f.parent.mkdir(parents=True,exist_ok=True);gg=np.concatenate(features);np.savez_compressed(f,geometry=gg,optical=np.zeros((len(gg),8),np.float32),optical_valid=np.zeros(len(gg),bool))
    out=f.with_name('frozen_probabilities.npz');env=dict(os.environ);env.pop('PYTHONPATH',None);env.update(CUDA_VISIBLE_DEVICES='',OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='1')
    with out.with_suffix('.log').open('w') as log:subprocess.run(['/sw/isaac/applications/conda_envs/Pytorch_Jupyter_OOD_251/bin/python',str(H/'lod2_workflow_20261022/tools/infer_semantics.py'),'--features',str(f),'--output',str(out)],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=300)
    probabilities=np.load(out)['point'][:,0];results=[]
    for r,(model,xyz,ztrue,case,seed) in zip(records,prepared):
        q=np.c_[np.linspace(.1,19.9,100).repeat(60),np.tile(np.linspace(.1,11.9,60),100)];truth=ztrue(q)
        def measure(m):
            predicted=np.full(len(q),np.nan)
            for p in patches(m):
                mask=intersects_xy(p['polygon'],q[:,0],q[:,1]);predicted[mask]=height(p,q[mask])
            return float(np.nanmean(np.abs(predicted-truth)))
        row=dict(r,raw_mae_m=measure(model),methods={})
        for name,score in [('geometry',np.ones(len(xyz))),('frozen_DL',probabilities[r['start']:r['start']+len(xyz)])]:
            replacement,audit=propose(model,xyz,np.ones(len(xyz),bool),score);candidate=stitch(model,replacement) if replacement else model;t=G.edge_statistics(candidate['surfaces']);row['methods'][name]=dict(mae_m=measure(candidate),changed_components=len(replacement),shell_check=t['all_edges_have_two_incidences'] and t['orientation_inconsistent_edges']==0)
        results.append(row)
    summary=[]
    for case in cases:
        rr=[r for r in results if r['case']==case];summary.append(dict(case=case,n=len(rr),raw_mae_m=float(np.mean([r['raw_mae_m'] for r in rr])),methods={m:dict(mae_m=float(np.mean([r['methods'][m]['mae_m'] for r in rr])),changed_components=sum(r['methods'][m]['changed_components'] for r in rr),harmed_over_2cm=sum(r['methods'][m]['mae_m']-r['raw_mae_m']>.02 for r in rr)) for m in ['geometry','frozen_DL']}))
    dump(RUN/'controlled/results.json',dict(analytic_mechanism_test=True,independent_real_GT=False,labels_input_to_repair=False,optical_input=False,rows=results,summary=summary));print('CONTROLLED',json.dumps(summary),flush=True);return summary

def main():
    assert not RUN.exists();RUN.mkdir(parents=True);dump(RUN/'config.json',dict(parameters=CONFIG,new_training=False,source='guarded eight-case reconstruction',target_GT=False,scope='bounded local component correction mechanism verification'))
    real=run_real();controlled=fixtures();summary=dict(status='complete',real_buildings=8,real_rows=real,controlled_summary=controlled,proposed_components=sum(r['proposed_components'] for r in real),accepted_components=sum(r['accepted_components'] for r in real),all_original_xyz_unchanged=True,new_training=False,independent_US_GT=False,optical_boundary_confirmation_implemented=False,complete_occlusion_completion_implemented=False,source_code_sha256=hashlib.sha256(Path(__file__).with_name('local_repair.py').read_bytes()).hexdigest())
    dump(RUN/'completion.json',summary);dump(ROOT/'reports/latest_run.json',summary)
if __name__=='__main__':main()
