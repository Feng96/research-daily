from pathlib import Path
import os,sys,copy,json,hashlib,shutil,importlib.util,datetime,time,argparse
os.environ.setdefault('OPENBLAS_NUM_THREADS','1');os.environ.setdefault('PYTHONDONTWRITEBYTECODE','1')
import numpy as np
import rasterio,laspy,shapely
from shapely.geometry import shape,Polygon,box,mapping
from shapely.affinity import translate,rotate
from progressive import image_features,refine
H=Path('/nfs/home/yfeng21');R=Path('/lustre/isaac24/scratch/yfeng21/lod2_paper_compare_20261022');C=Path('/lustre/isaac24/scratch/yfeng21/lod2_canopy_20261022/runs/probe8_v1');O=Path('/lustre/isaac24/scratch/yfeng21/lod2_workflow_20261022/runs/smoke8_v1');CODE=H/'lod2_paper_compare_20261022'
def load(p):return json.loads(Path(p).read_text())
def dump(p,d):p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def mod(n,p):s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def array_sha(x):return hashlib.sha256(np.ascontiguousarray(x).tobytes()).hexdigest()
W=mod('paper_common_native',H/'lod2_workflow_20261022/tools/run_workflow.py');L=mod('paper_compare_local',H/'lod2_local_repair_20261022/tools/local_repair.py');G=W.G

def shell(model):
 t=G.edge_statistics(model['surfaces']);return dict(passed=bool(t['all_edges_have_two_incidences'] and t['orientation_inconsistent_edges']==0),diagnostic=t,certified_solid=False)

def xy_changed(a,b):
 aa=[shapely.geometry.Polygon(np.asarray(s['rings'][0])[:,:2],[np.asarray(r)[:,:2] for r in s['rings'][1:]]) for s in a['surfaces'] if s['type']=='RoofSurface'];bb=[shapely.geometry.Polygon(np.asarray(s['rings'][0])[:,:2],[np.asarray(r)[:,:2] for r in s['rings'][1:]]) for s in b['surfaces'] if s['type']=='RoofSurface'];aa=shapely.union_all(aa);bb=shapely.union_all(bb);diffs=[]
 for x,y in zip(L.patches(a),L.patches(b)):
  diffs.append(x['polygon'].symmetric_difference(y['polygon']))
 changed=shapely.union_all(diffs).area if diffs else 0.
 return dict(changed_partition_area_m2=float(changed),symmetric_difference_area_m2=float(aa.symmetric_difference(bb).area),hausdorff_displacement_m=float(aa.boundary.hausdorff_distance(bb.boundary)),area_before_m2=float(aa.area),area_after_m2=float(bb.area))

def predict(model,xy):
 result=np.full(len(xy),np.nan)
 for p in L.patches(model):
  keep=shapely.intersects_xy(p['polygon'],xy[:,0],xy[:,1]);result[keep]=L.height(p,xy[keep])
 return result

def diagnostics(model,initial,xyz):
 pred=predict(model,xyz[:,:2]);valid=np.isfinite(pred);res=np.abs(pred[valid]-xyz[valid,2]);fp=shape(initial['footprint']);x0,y0,x1,y1=fp.bounds;q=np.c_[np.linspace(x0,x1,65).repeat(65),np.tile(np.linspace(y0,y1,65),65)];a=predict(initial,q);b=predict(model,q);both=np.isfinite(a)&np.isfinite(b);delta=np.abs(a[both]-b[both]);return dict(roof_faces=sum(s['type']=='RoofSurface' for s in model['surfaces']),roof_vertices=sum(len(r)-1 for s in model['surfaces'] if s['type']=='RoofSurface' for r in s['rings']),original_candidate_point_count=len(xyz),original_echo_coverage=float(valid.mean()),original_echo_mean_absolute_residual_m=float(res.mean()) if len(res) else None,original_echo_median_absolute_residual_m=float(np.median(res)) if len(res) else None,echo_fit_is_not_roof_accuracy=True,maximum_common_grid_height_change_m=float(delta.max()) if len(delta) else None,mean_common_grid_height_change_m=float(delta.mean()) if len(delta) else None,**xy_changed(initial,model))

def run_arm(bdir,initial,xyz,features,config,score,shared_keep):
 start=time.monotonic();replacement,decisions=L.propose(initial,xyz,shared_keep,score);ours=L.stitch(initial,replacement) if replacement else copy.deepcopy(initial);ours_quality=shell(ours);dump(bdir/'ours/candidate.json',ours);dump(bdir/'ours/checked.json',ours if ours_quality['passed'] else initial);dump(bdir/'ours/audit.json',dict(replacement_surfaces=list(replacement),decisions=decisions,quality=ours_quality,seconds=time.monotonic()-start));rows=[];models=[]
 for seed in config['seeds']:
  candidate,report=refine(initial,xyz[shared_keep],features,config,seed);changed=bool(report.get('best_edits'))
  if changed:
   source_faces=[s.get('source_surface_index') for s in candidate['surfaces'] if s['type']=='RoofSurface'];candidate=L.stitch(candidate,{})
   for face in candidate['surfaces']:
    if face['type']=='RoofSurface':face['source_surface_index']=source_faces[face['source_surface_index']]
  else:candidate=copy.deepcopy(initial)
  quality=shell(candidate);report.update(quality=quality,changed=changed,diagnostics=diagnostics(candidate,initial,xyz));sd=bdir/'paper/seeds'/str(seed);dump(sd/'candidate.json',candidate);dump(sd/'report.json',report);rows.append(report);models.append(candidate)
 # Shared geometry checks may reject a generated candidate. No reference scores
 # are read to choose a seed, candidate or fallback.
 candidates=[i for i,r in enumerate(rows) if r['quality']['passed']];eligible=candidates or list(range(len(rows)));chosen=min(eligible,key=lambda i:rows[i].get('final_energy',{'total':float('inf')})['total']);paper=models[chosen];paper_report=rows[chosen]
 dump(bdir/'paper/candidate.json',paper);dump(bdir/'paper/checked.json',paper if paper_report['quality']['passed'] else initial)
 audit=dict(selected_seed=paper_report['seed'],selection='lowest declared energy among edge-diagnostic-passing seeds; if none pass, best-energy candidate with checked-output fallback',selected_report=paper_report,seeds=[dict(seed=r['seed'],energy=r.get('final_energy'),quality_passed=r['quality']['passed'],changed=r['changed'],seconds=r.get('seconds')) for r in rows]);dump(bdir/'paper/audit.json',audit)
 return dict(initial=dict(quality=shell(initial),diagnostics=diagnostics(initial,initial,xyz)),paper=dict(quality=paper_report['quality'],diagnostics=paper_report['diagnostics'],changed=paper_report['changed'],seed=paper_report['seed'],seed_runs=audit['seeds'],initial_energy=paper_report.get('initial_energy'),final_energy=paper_report.get('final_energy'),proposal_counts=paper_report.get('proposal_counts'),accepted_counts=paper_report.get('accepted_counts'),image_lines=paper_report.get('image_lines'),image_corners=paper_report.get('image_corners')),ours=dict(quality=ours_quality,diagnostics=diagnostics(ours,initial,xyz),changed=bool(replacement),reassigned_components=len(replacement)))

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--name',default='matched8_v2');ap.add_argument('--smoke',action='store_true');args=ap.parse_args();run=R/'runs'/args.name;assert not run.exists();run.mkdir(parents=True);config=load(CODE/'config.json')
 if args.smoke:config.update(iterations=120,seeds=config['seeds'][:1])
 raster=H/'lod2_pilot_20261017/data/imagery/naip2014_roi_rgbnir_epsg26985.tif'
 with rasterio.open(raster) as ds:rgb=np.moveaxis(ds.read([1,2,3]),0,-1);raster_transform=ds.transform;image_info=dict(path=str(raster),sha256=sha(raster),crs=str(ds.crs),pixel_size_m=float(abs(ds.transform.a)),bands=['R','G','B'],actual_optical_input=True)
 preparation=load(H/'lod2_overnight_20261020/data/preparation_manifest.json');fpmap={f['properties']['pilot_id']:f['geometry'] for f in load(preparation['groups']['global']['footprints'])['features']};ground=np.load(H/'lod2_overnight_20261020/data/prepared/ground_points.npy');front=np.load(O/'evidence/frontend_decisions.npz');prob=np.load(O/'evidence/target_probabilities.npz');old=load(C/'completion.json');selection=old['rows']
 if args.smoke:selection=[r for r in selection if r['id'].endswith(('67521425','67528254'))]
 with laspy.open(preparation['groups']['global']['shared_points']) as f:header=copy.deepcopy(f.header)
 recipe=dict(schema='matched-paper-core-v1',status='frozen_before_run',config=config,imagery=image_info,selected_ids=[x['id'] for x in selection],input_blocks=['raw','guarded'],initial_reconstruction='one shared native execution per building/block',paper_adaptation=True,original_paper_reproduced=False,ours='frozen point-MLP-guided local plane reassignment, not a new trained full correction model',new_training=False,target_GT=False,code_sha256={p.name:sha(p) for p in [CODE/'config.json',CODE/'tools/progressive.py',CODE/'tools/run_compare.py',H/'lod2_local_repair_20261022/tools/local_repair.py']});dump(run/'recipe.json',recipe);rows=[]
 for record in selection:
  bid=record['id'];d=np.load(C/'buildings'/bid/'decisions.npz');xyz=d['original_XYZ'];ids=d['source_indices'];idx=np.searchsorted(front['source_indices'],ids);assert np.array_equal(front['source_indices'][idx],ids);score=prob['point'][idx,0];fp=fpmap[bid];x0,y0,x1,y1=shape(fp).bounds;g=ground[(ground[:,0]>=x0-12)&(ground[:,0]<=x1+12)&(ground[:,1]>=y0-12)&(ground[:,1]<=y1+12)];before=array_sha(xyz)
  win=rasterio.windows.from_bounds(x0-5,y0-5,x1+5,y1+5,raster_transform);r0=max(0,int(np.floor(win.row_off)));c0=max(0,int(np.floor(win.col_off)));r1=min(rgb.shape[0],int(np.ceil(win.row_off+win.height)));c1=min(rgb.shape[1],int(np.ceil(win.col_off+win.width)));window=rasterio.windows.Window(c0,r0,c1-c0,r1-r0);features=image_features(rgb[r0:r1,c0:c1],rasterio.windows.transform(window,raster_transform),min_length=config['minimum_line_length_m'])
  initial_cache={}
  for block,keep in [('raw',np.ones(len(xyz),bool)),('guarded',d['guarded_keep'])]:
   bdir=run/'buildings'/bid/block;bdir.mkdir(parents=True);key=array_sha(ids[keep]);reused=key in initial_cache
   if reused:
    cached_dir,receipt=initial_cache[key];shutil.copytree(cached_dir,bdir/'initial');dump(bdir/'initial/reused_execution.json',dict(source_directory=str(cached_dir),reason='identical selected original indices; reuse one execution to avoid native reconstruction randomness'))
   else:
    receipt=W.native(bdir,'initial',bid,xyz,np.flatnonzero(keep),fp,g,header,preparation['groups']['global']['parameters']);initial_cache[key]=(bdir/'initial',receipt)
   initial=receipt['model'];bundle=dict(id=bid,block=block,original_XYZ_sha256=before,all_source_indices_sha256=array_sha(ids),shared_selected_source_indices_sha256=array_sha(ids[keep]),shared_point_count=int(keep.sum()),shared_footprint_sha256=hashlib.sha256(json.dumps(fp,sort_keys=True).encode()).hexdigest(),shared_initial_model_sha256=sha(bdir/'initial/models.json'),NAIP_sha256=image_info['sha256'],same_pointset_native_execution_reused=reused,both_arms_receive_identical_input=True,point_coordinates_modified=False,target_roof_labels_available=False);dump(bdir/'shared_input.json',bundle)
   result=run_arm(bdir,initial,xyz,features,config,score,keep);assert array_sha(xyz)==before;row=dict(id=bid,block=block,input=bundle,methods=result);rows.append(row);dump(bdir/'summary.json',row);print('PAIR',bid,block,'paper_changed',result['paper']['changed'],'ours_changed',result['ours']['changed'],'paper_shell',result['paper']['quality']['passed'],'ours_shell',result['ours']['quality']['passed'],flush=True)
 dump(run/'completion.json',dict(status='complete',buildings=len(selection),paired_settings=len(rows),recipe=recipe,rows=rows,independent_US_GT=False,truth_used_for_real_selection=False,original_paper_reproduced=False,core_idea_adaptation_implemented=True,new_training=False,all_inputs_matched=True));dump(R/'reports/latest_run.json',load(run/'completion.json'));print('COMPLETE',run,flush=True)
if __name__=='__main__':main()
