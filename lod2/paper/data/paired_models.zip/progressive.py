"""Executable NAIP core adaptation of Jung/Sohn 2019, not exact reproduction.

Fixed roof planes; actual image line/corner proposal kernels; an MDL-inspired
boundary/homogeneity/complexity energy and annealed Metropolis optimization.
No target roof labels, semantic DL scores or reference mesh enter this arm.
"""
import copy,math,time
from collections import Counter,defaultdict
import numpy as np
import shapely
from shapely import intersects_xy
from shapely.geometry import Polygon,LineString,Point,MultiPoint
from shapely.ops import unary_union
from shapely.affinity import translate
from scipy.spatial import cKDTree,Delaunay
from skimage.color import rgb2gray
from skimage.feature import canny,corner_harris,corner_peaks
from skimage.transform import probabilistic_hough_line


def angle(v):return math.atan2(v[1],v[0])%np.pi

def angle_distance(a,b):return abs((a-b+np.pi/2)%np.pi-np.pi/2)

def line_intersection(a,v,b,w):
    cross=v[0]*w[1]-v[1]*w[0]
    if abs(cross)<1e-7:return None
    d=b-a;t=(d[0]*w[1]-d[1]*w[0])/cross
    return a+t*v

def clean_ring(xy,tolerance=.001):
    pts=[]
    for q in xy:
        q=np.round(np.asarray(q,float),3)
        if not pts or np.linalg.norm(q-pts[-1])>tolerance*.5:pts.append(q)
    if len(pts)>1 and np.linalg.norm(pts[0]-pts[-1])<tolerance:pts.pop()
    return np.asarray(pts)

def image_features(rgb,transform,seed=20261022,min_length=3.):
    gray=rgb2gray(rgb[...,:3]);edges=canny(gray,sigma=.8,low_threshold=.04,high_threshold=.12)
    pixel=math.sqrt(abs(transform.a*transform.e-transform.b*transform.d))
    lines=probabilistic_hough_line(edges,threshold=5,line_length=max(3,round(min_length/pixel)),line_gap=1,theta=np.linspace(-np.pi/2,np.pi/2,360,endpoint=False),seed=seed)
    def world(xy):
        a=np.asarray(xy,float)+.5;return np.c_[transform.a*a[:,0]+transform.b*a[:,1]+transform.c,transform.d*a[:,0]+transform.e*a[:,1]+transform.f]
    image_lines=[]
    for a,b in lines:
        q=world([a,b]);length=float(np.linalg.norm(q[1]-q[0]))
        if length>=min_length:image_lines.append(dict(xy=q,length=length,theta=angle(q[1]-q[0])))
    peaks=corner_peaks(corner_harris(gray,sigma=1),min_distance=2,threshold_rel=.03,num_peaks=2500,exclude_border=False)
    corners=world(peaks[:,::-1]) if len(peaks) else np.empty((0,2))
    return dict(lines=image_lines,corners=corners,edge_pixels=int(edges.sum()),pixel_size_m=pixel)

def local_cues(features,footprint,origin,config):
    clip=footprint.buffer(config['cue_distance_m']+2);lines=[]
    for l in features['lines']:
        if LineString(l['xy']).intersects(clip):lines.append(dict(l,xy=l['xy']-origin))
    lines=sorted(lines,key=lambda x:-x['length'])[:config['maximum_image_lines_per_building']]
    n=config['compass_directions'];step=np.pi/n;compass=[]
    for k in range(n):
        group=[l for l in lines if int(np.floor((l['theta']+step/2)%np.pi/step))%n==k]
        if group:
            z=sum(l['length']*np.exp(2j*l['theta']) for l in group);compass.append(float((np.angle(z)/2)%np.pi))
        else:compass.append(float(k*step))
    quant=[];seen=set()
    for l in lines:
        th=min(compass,key=lambda a:angle_distance(a,l['theta']));v=np.array([np.cos(th),np.sin(th)]);normal=np.array([-v[1],v[0]]);xy=l['xy'];rho=float(xy.mean(0)@normal);rho=round(rho/config['rho_quantization_m'])*config['rho_quantization_m'];u=xy@v # endpoints preserve the detected segment length
        xy=np.outer(u,v)+rho*normal;key=(round(th,4),round(rho,3),round(float(u.min()),1),round(float(u.max()),1))
        if key not in seen:quant.append(dict(xy=xy,length=float(abs(u[1]-u[0])),theta=th));seen.add(key)
    corners=[]
    for c in features['corners']:
        if not clip.covers(Point(c)):continue
        c=c-origin;arms=[]
        for l in quant:
            if LineString(l['xy']).distance(Point(c))<=1.5:
                if all(angle_distance(l['theta'],a)>.25 for a in arms):arms.append(l['theta'])
        if len(arms)>=2:corners.append(dict(xy=c,arms=arms))
    return dict(lines=quant,corners=corners,compass=compass,pixel_size_m=features['pixel_size_m'])

def state_from_model(model,origin):
    faces=[]
    for si,s in enumerate(model['surfaces']):
        if s['type']!='RoofSurface':continue
        xyz=np.asarray(s['rings'][0],float);xyz=xyz[:-1] if np.array_equal(xyz[0],xyz[-1]) else xyz
        center=xyz.mean(0);normal=np.linalg.svd(xyz-center,full_matrices=False)[2][-1];normal*=1 if normal[2]>0 else -1
        if normal[2]<.05:continue
        rings=[clean_ring(np.asarray(r)[:,:2]-origin) for r in s['rings']];poly=Polygon(rings[0],rings[1:])
        if poly.is_valid and poly.area>1e-5:faces.append(dict(source_index=si,rings=rings,center=center,normal=normal,initial_polygon=poly))
    # Add every collinear shared XY node to both roof rings to preserve T-junctions.
    nodes=np.unique(np.concatenate([r for f in faces for r in f['rings']]),axis=0)
    for face in faces:
        rr=[]
        for ring in face['rings']:
            out=[]
            for a,b in zip(ring,np.roll(ring,-1,axis=0)):
                v=b-a;l=v@v;t=((nodes-a)@v)/l;dist=np.linalg.norm(nodes-a-t[:,None]*v,axis=1);ix=np.flatnonzero((t>=-1e-8)&(t<1-1e-8)&(dist<1e-6));out.extend(nodes[ix[np.argsort(t[ix])]])
            rr.append(np.asarray(out))
        face['rings']=rr
    return faces

def polygon(face):return Polygon(face['rings'][0],face['rings'][1:])

def observed_boundary(xy):
    if len(xy)<5:return xy
    try:
        # Density-adaptive alpha boundary; no roof labels or truth geometry.
        near=cKDTree(xy).query(xy,k=2)[0][:,1];radius=max(1.5,3*float(np.median(near)))
        t=Delaunay(xy);tri=xy[t.simplices];aa=np.linalg.norm(tri[:,1]-tri[:,2],axis=1);bb=np.linalg.norm(tri[:,0]-tri[:,2],axis=1);cc=np.linalg.norm(tri[:,0]-tri[:,1],axis=1);cross=np.abs(np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]));r=aa*bb*cc/np.maximum(2*cross,1e-9);chosen=t.simplices[r<=radius]
        counts=Counter(tuple(sorted((int(a),int(b)))) for row in chosen for a,b in zip(row,np.roll(row,-1)))
        ids=np.unique([i for e,c in counts.items() if c==1 for i in e]);return xy[ids] if len(ids)>=3 else xy
    except Exception:return xy

def bind_observations(faces,xyz,origin,config):
    xy=xyz[:,:2]-origin;dist=np.full((len(xyz),len(faces)),np.inf)
    for j,f in enumerate(faces):
        p=f['initial_polygon'].buffer(config['cue_distance_m']);valid=intersects_xy(p,xy[:,0],xy[:,1]);dd=np.abs((xyz-f['center'])@f['normal']);dist[valid&(dd<=.3),j]=dd[valid&(dd<=.3)]
    assignment=dist.argmin(1);assigned=np.isfinite(dist.min(1));bound=[]
    for j,f in enumerate(faces):
        target=xy[assigned&(assignment==j)];boundary=observed_boundary(target)
        if len(boundary)>128:boundary=boundary[np.linspace(0,len(boundary)-1,128,dtype=int)]
        nearby=intersects_xy(f['initial_polygon'].buffer(2),xy[:,0],xy[:,1]);other=xy[assigned&(assignment!=j)&nearby]
        if len(other)>128:other=other[np.linspace(0,len(other)-1,128,dtype=int)]
        # Interior support participates only in the inside/outside penalty.
        if len(target)>256:target=target[np.linspace(0,len(target)-1,256,dtype=int)]
        bound.append(dict(boundary=boundary,target=target,other=other))
    return bound

def complexity(faces):
    vertices=0;directions=set();angle_penalty=0.;angle_count=0
    for f in faces:
        for ring in f['rings']:
            vertices+=len(ring);vectors=np.roll(ring,-1,axis=0)-ring;length=np.linalg.norm(vectors,axis=1);directions.update(int(round(angle(v)/(np.pi/36)))%36 for v,l in zip(vectors,length) if l>.05)
            before=-np.roll(vectors,1,axis=0);cos=np.sum(before*vectors,axis=1)/np.maximum(np.linalg.norm(before,axis=1)*length,1e-9);aa=np.arccos(np.clip(cos,-1,1));deviation=np.minimum(abs(aa-np.pi/2),abs(aa-np.pi));angle_penalty+=float(np.sum((deviation/(np.pi/2))**2+2*(aa<np.pi/6)));angle_count+=len(aa)
    return np.log2(vertices+1)+np.log2(len(directions)+1)+(angle_penalty/max(1,angle_count))*4

def energy(faces,bound,config):
    fit=0.;count=0
    for f,obs in zip(faces,bound):
        p=polygon(f);b=obs['boundary'];target=obs['target'];other=obs['other']
        if len(b):
            distance=shapely.distance(p.boundary,shapely.points(b));fit+=float(np.sum(np.minimum(distance,3.)**2));count+=len(b)
        if len(target):
            outside=~intersects_xy(p.buffer(config['boundary_fit_tolerance_m']),target[:,0],target[:,1]);fit+=float(outside.sum())*config['homogeneity_penalty_m']**2;count+=len(target)
        if len(other):
            inside=intersects_xy(p.buffer(-config['boundary_fit_tolerance_m']),other[:,0],other[:,1]);fit+=float(inside.sum())*config['homogeneity_penalty_m']**2;count+=len(other)
    closeness=fit/max(count,1)/(config['boundary_sigma_m']**2*2*np.log(2));comp=complexity(faces);return dict(total=float(closeness+config['complexity_weight']*comp),closeness=float(closeness),complexity=float(comp),observations=int(count))

def edge_catalog(faces,config):
    lookup={}
    for fi,f in enumerate(faces):
        for ri,ring in enumerate(f['rings']):
            for k,(a,b) in enumerate(zip(ring,np.roll(ring,-1,axis=0))):
                if np.linalg.norm(b-a)<config['minimum_edge_length_m']:continue
                key=tuple(sorted((tuple(a),tuple(b))))
                if key not in lookup:lookup[key]=dict(a=a,b=b,face=fi,ring=ri,k=k)
    return list(lookup.values())

def changed_faces(state,a,b,replacement,move):
    new=[];affected=[]
    for i,f in enumerate(state):
        rings=[];changed=False
        for ring in f['rings']:
            rr=[]
            for x,y in zip(ring,np.roll(ring,-1,axis=0)):
                if move:
                    z=move[0] if np.linalg.norm(x-a)<1e-7 else move[1] if np.linalg.norm(x-b)<1e-7 else x
                    if np.linalg.norm(z-x)>1e-8:changed=True
                    rr.append(z)
                elif np.linalg.norm(x-a)<1e-7 and np.linalg.norm(y-b)<1e-7:
                    rr.extend(replacement[:-1]);changed=True
                elif np.linalg.norm(x-b)<1e-7 and np.linalg.norm(y-a)<1e-7:
                    rr.extend(replacement[:0:-1]);changed=True
                else:rr.append(x)
            rings.append(clean_ring(rr))
        new.append(dict(f,rings=rings) if changed else f)
        if changed:affected.append(i)
    return new,affected

def valid_state(new,old,affected,initial_union,initial_holes,config):
    if not affected:return False
    for i in affected:
        f=new[i]
        if any(len(r)<3 for r in f['rings']):return False
        p=polygon(f);area=f['initial_polygon'].area
        if not p.is_valid or not config['minimum_face_area_ratio']*area<=p.area<=config['maximum_face_area_ratio']*area:return False
        if p.boundary.hausdorff_distance(f['initial_polygon'].boundary)>config['max_boundary_displacement_m']+.001:return False
    polygons=[polygon(f) for f in new]
    union=unary_union(polygons)
    if union.geom_type!='Polygon':return False
    if sum(p.area for p in polygons)-union.area>1e-5:return False
    if len(union.interiors)!=initial_holes:return False
    return True

def generate_proposal(state,edge,cue,cues,rng,kernel,config):
    a,b=edge['a'],edge['b'];v=b-a;length=np.linalg.norm(v);unit=v/length;xy=cue['xy'].copy();linevec=xy[1]-xy[0]
    if linevec@v<0:xy=xy[::-1];linevec=-linevec
    if kernel=='Q1_line':
        ring=state[edge['face']]['rings'][edge['ring']];k=edge['k'];pre=ring[k-1];post=ring[(k+2)%len(ring)]
        va=a-pre;vb=post-b;perpendicular=np.array([-v[1],v[0]])
        if abs(np.cross(va,linevec))<.05*np.linalg.norm(va)*np.linalg.norm(linevec):va=perpendicular
        if abs(np.cross(vb,linevec))<.05*np.linalg.norm(vb)*np.linalg.norm(linevec):vb=perpendicular
        aa=line_intersection(xy[0],linevec,a,va);bb=line_intersection(xy[0],linevec,b,vb)
        if aa is None or bb is None:return None
        if max(np.linalg.norm(aa-a),np.linalg.norm(bb-b))>config['cue_distance_m'] or np.linalg.norm(bb-aa)<.5:return None
        return changed_faces(state,a,b,None,[np.round(aa,3),np.round(bb,3)])
    anchors=xy.copy();hit=[];corner_used=False
    for anchor in anchors:
        possible=[th for th in cues['compass'] if angle_distance(th,cue['theta'])>.2]
        if kernel=='Q3_corner':
            available=[c for c in cues['corners'] if np.linalg.norm(c['xy']-anchor)<=config['cue_distance_m']]
            if available:
                corner=min(available,key=lambda c:np.linalg.norm(c['xy']-anchor));arms=[th for th in corner['arms'] if angle_distance(th,cue['theta'])>.2]
                if arms:possible=arms;corner_used=True
        feasible=[]
        for th in possible:
            u=np.array([np.cos(th),np.sin(th)]);h=line_intersection(anchor,u,a,v)
            if h is None:continue
            t=float((h-a)@v/(v@v))
            if -.02<=t<=1.02 and np.linalg.norm(h-anchor)<=config['cue_distance_m']:feasible.append(h)
        if not feasible:return None
        hit.append(feasible[int(rng.integers(len(feasible)))])
    if kernel=='Q3_corner' and not corner_used:return None
    if (hit[1]-hit[0])@v<=.1:return None
    sequence=clean_ring([a,hit[0],anchors[0],anchors[1],hit[1],b])
    if len(sequence)<4 or not LineString(sequence).is_simple:return None
    return changed_faces(state,a,b,sequence,None)

def refine(model,xyz,features,config,seed):
    start=time.monotonic();footprint=shapely.geometry.shape(model['footprint']);origin=np.asarray(footprint.centroid.coords[0]);state=state_from_model(model,origin);initial=copy.deepcopy(state);cues=local_cues(features,footprint,origin,config)
    if not state:return copy.deepcopy(model),dict(status='no_roof_faces',seed=seed)
    bound=bind_observations(state,xyz,origin,config);current=energy(state,bound,config);initial_energy=dict(current);best_energy=dict(current);best=copy.deepcopy(state);union=unary_union([polygon(f) for f in initial]);holes=len(union.interiors) if union.geom_type=='Polygon' else 0
    if union.geom_type!='Polygon':return copy.deepcopy(model),dict(status='unsupported_initial_roof_domain',seed=seed)
    rng=np.random.default_rng(seed);counts=Counter();accepted=Counter();trace=[];edits=[];catalog=edge_catalog(state,config)
    for it in range(config['iterations']):
        if not catalog or not cues['lines']:break
        edge=catalog[int(rng.integers(len(catalog)))];a,b=edge['a'],edge['b'];v=b-a;line=LineString([a,b]);theta=angle(v)
        candidates=[l for l in cues['lines'] if angle_distance(theta,l['theta'])<=np.deg2rad(config['angle_tolerance_deg']) and line.distance(LineString(l['xy']))<=config['cue_distance_m']]
        if not candidates:counts['no_image_pair']+=1;continue
        cue=candidates[int(rng.integers(len(candidates)))];kernel=str(rng.choice(['Q1_line','Q2_compass','Q3_corner']));counts[kernel]+=1
        proposal=generate_proposal(state,edge,cue,cues,rng,kernel,config)
        if proposal is None:counts['invalid_proposal']+=1;continue
        new,affected=proposal
        if not valid_state(new,state,affected,union,holes,config):counts['invalid_partition']+=1;continue
        proposed=energy(new,bound,config);temperature=config['temperature_initial']*(config['temperature_final']/config['temperature_initial'])**(it/max(1,config['iterations']-1));delta=proposed['total']-current['total']
        # This is an adapted annealed Metropolis heuristic, not exact original
        # asymmetric-kernel probability accounting or stationary posterior sampling.
        if delta<=0 or rng.random()<np.exp(-min(700,delta/max(temperature,1e-12))):
            state=new;current=proposed;accepted[kernel]+=1;catalog=edge_catalog(state,config)
            if current['total']<best_energy['total']-1e-10:
                best=copy.deepcopy(state);best_energy=dict(current);edits.append(dict(iteration=it,kernel=kernel,affected_faces=[state[i]['source_index'] for i in affected],energy=dict(current)))
        if it%100==0:trace.append(dict(iteration=it,temperature=temperature,current=current['total'],best=best_energy['total']))
    result=copy.deepcopy(model);surfaces=[]
    for f in best:
        rr=[]
        for r in f['rings']:
            q=r+origin;z=f['center'][2]-((q-f['center'][:2])@f['normal'][:2])/f['normal'][2];xyzring=np.c_[q,z];rr.append(np.vstack([xyzring,xyzring[0]]).tolist())
        surfaces.append(dict(type='RoofSurface',rings=rr,source_surface_index=f['source_index'],generated_progressive_boundary=True))
    result['surfaces']=surfaces;roof_domain=unary_union([polygon(f) for f in best]);result['footprint']=shapely.geometry.mapping(translate(roof_domain,xoff=origin[0],yoff=origin[1]))
    report=dict(status='complete',seed=seed,seconds=time.monotonic()-start,initial_energy=initial_energy,final_energy=best_energy,proposal_counts=dict(counts),accepted_counts=dict(accepted),best_edits=edits,trace=trace,initial_planes=len(initial),final_planes=len(best),fixed_plane_parameters=True,shared_partition_valid=True,image_lines=len(cues['lines']),image_corners=len(cues['corners']),compass_angles_deg=np.rad2deg(cues['compass']).tolist(),origin_xy=origin.tolist(),optical_features_actual=True,DL_scores_input=False,original_XYZ_modified=False,
        image_cues=dict(lines=[dict(xy=(l['xy']+origin).tolist(),theta=l['theta']) for l in cues['lines']],corners=[dict(xy=(c['xy']+origin).tolist(),arms=c['arms']) for c in cues['corners']]))
    return (result if edits else copy.deepcopy(model)),report
