"""Independent analytic shape checks; synthetic RGB/XYZ are shared by both arms."""
from pathlib import Path
import sys,os,copy,json,hashlib,subprocess,importlib.util
import numpy as np
import shapely
from shapely.geometry import box,Polygon,mapping
from shapely.affinity import translate,rotate
from affine import Affine
from progressive import image_features,refine
H=Path('/nfs/home/yfeng21');R=Path('/lustre/isaac24/scratch/yfeng21/lod2_paper_compare_20261022');RUN=R/'runs/mechanism12_v2'
def mod(n,p):s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def dump(p,d):p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
L=mod('paper_mechanism_local',H/'lod2_local_repair_20261022/tools/local_repair.py');F=mod('paper_mechanism_features',H/'lod2_tree_20261020/tools/features.py');config=json.loads((H/'lod2_paper_compare_20261022/config.json').read_text())
def model(polys,heights,bid):
 surfaces=[]
 for p,z in zip(polys,heights):
  rings=[np.c_[np.asarray(r.coords),np.full(len(r.coords),z)].tolist() for r in [p.exterior,*p.interiors]];surfaces.append(dict(type='RoofSurface',rings=rings))
 union=shapely.union_all(polys);return dict(pilot_id=bid,surfaces=surfaces,footprint=mapping(union),ground_z=0.,status='success',lod='2.2',lod_class='analytic_fixture')
def score(m,truth):
 pp=[p['polygon'] for p in L.patches(m)];tt=[p['polygon'] for p in L.patches(truth)];p=shapely.union_all(pp);t=shapely.union_all(tt);return dict(footprint_IoU=float(p.intersection(t).area/p.union(t).area),boundary_Hausdorff_m=float(p.boundary.hausdorff_distance(t.boundary)),roof_planes=len(pp))
def main():
 assert not RUN.exists();RUN.mkdir(parents=True);prepared=[];features=[];original=[]
 for seed in range(3):
  for case in ['boundary_shift','orientation','corner_deformation','true_step_control']:
   rng=np.random.default_rng(40400+seed);rect=box(0,0,20,12)
   if case=='true_step_control':polys=[box(0,0,12,12),box(12,0,20,12)];heights=[12.,9.];corrupt=polys
   else:
    p=Polygon([(0,0),(20,0),(20,7),(13,7),(13,12),(0,12)]) if case=='corner_deformation' else rect;polys=[p];heights=[12.]
    if case=='boundary_shift':corrupt=[translate(p,xoff=1.,yoff=.7)]
    elif case=='orientation':corrupt=[rotate(p,5,origin='centroid')]
    else:
     q=np.asarray(p.exterior.coords);q[2:4,1]-=1.4;corrupt=[Polygon(q)]
   bid=f'analytic-{case}-{seed}';truth=model(polys,heights,bid);initial=model(corrupt,heights,bid)
   # Render only an optical observation. No roof vertices are handed to feature
   # extraction or the refinement functions as ground-truth labels.
   transform=Affine(1,0,-6,0,-1,20);xx,yy=np.meshgrid(np.arange(34)+.5-6,20-(np.arange(28)+.5));rgb=np.empty((28,34,3),np.uint8);rgb[:]=[75,105,65]
   xyz=[]
   for j,(p,z) in enumerate(zip(polys,heights)):
    inside=shapely.intersects_xy(p,xx,yy);rgb[inside]=[180-j*35,180-j*35,175-j*35];xy=rng.uniform([-1,-1],[21,13],(4000,2));xy=xy[shapely.intersects_xy(p,xy[:,0],xy[:,1])];xyz.append(np.c_[xy,np.full(len(xy),z)+rng.normal(0,.035,len(xy))])
   rgb=np.clip(rgb.astype(float)+rng.normal(0,1,rgb.shape),0,255).astype(np.uint8);xyz=np.concatenate(xyz);gxy=rng.uniform([-5,-5],[25,18],(400,2));context=np.vstack([xyz,np.c_[gxy,np.zeros(len(gxy))]]);feat,_=F.geometry_features(xyz,context,np.ones(len(xyz)),np.ones(len(xyz)));features.append(feat);prepared.append((bid,case,seed,initial,truth,xyz,rgb,transform));original.append(dict(start=sum(len(f) for f in features[:-1]),count=len(feat)))
 a=np.concatenate(features);fp=RUN/'features.npz';np.savez_compressed(fp,geometry=a,optical=np.zeros((len(a),8),np.float32),optical_valid=np.zeros(len(a),bool));pred=RUN/'frozen_probabilities.npz';env=dict(os.environ);env.pop('PYTHONPATH',None);env.update(OPENBLAS_NUM_THREADS='1',CUDA_VISIBLE_DEVICES='')
 with (RUN/'inference.log').open('w') as log:subprocess.run(['/sw/isaac/applications/conda_envs/Pytorch_Jupyter_OOD_251/bin/python',str(H/'lod2_workflow_20261022/tools/infer_semantics.py'),'--features',str(fp),'--output',str(pred)],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=300)
 pp=np.load(pred)['point'][:,0];rows=[]
 for pos,(bid,case,seed,initial,truth,xyz,rgb,transform) in zip(original,prepared):
  feature=image_features(rgb,transform,min_length=config['minimum_line_length_m']);candidate,report=refine(initial,xyz,feature,config,config['seeds'][seed]);replace,review=L.propose(initial,xyz,np.ones(len(xyz),bool),pp[pos['start']:pos['start']+len(xyz)]);ours=L.stitch(initial,replace) if replace else copy.deepcopy(initial);row=dict(id=bid,case=case,seed=seed,initial=score(initial,truth),paper=score(candidate,truth),ours=score(ours,truth),paper_changed=bool(report['best_edits']),image_lines=report['image_lines'],image_corners=report['image_corners'],proposal_counts=report['proposal_counts'],accepted_counts=report['accepted_counts'],paper_energy_before=report['initial_energy'],paper_energy_after=report['final_energy']);rows.append(row);bd=RUN/bid;dump(bd/'truth_for_scoring_only.json',truth);dump(bd/'initial.json',initial);dump(bd/'paper.json',candidate);dump(bd/'ours.json',ours);dump(bd/'report.json',report);np.savez_compressed(bd/'shared_inputs.npz',original_XYZ=xyz,RGB=rgb,point_score=pp[pos['start']:pos['start']+len(xyz)],transform=np.asarray(transform));print('MECHANISM',json.dumps(row),flush=True)
 summaries=[]
 for case in ['boundary_shift','orientation','corner_deformation','true_step_control']:
  rr=[r for r in rows if r['case']==case];summaries.append(dict(case=case,n=len(rr),methods={m:dict(mean_footprint_IoU=float(np.mean([r[m]['footprint_IoU'] for r in rr])),mean_boundary_Hausdorff_m=float(np.mean([r[m]['boundary_Hausdorff_m'] for r in rr]))) for m in ['initial','paper','ours']}))
 dump(RUN/'completion.json',dict(status='complete',synthetic_RGB_and_XYZ=True,real_roof_accuracy=False,truth_not_given_to_either_arm=True,rows=rows,summary=summaries));print('COMPLETE',RUN,flush=True)
if __name__=='__main__':main()
