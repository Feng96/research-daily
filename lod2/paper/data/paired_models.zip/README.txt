Paired NAIP adaptation of Jung & Sohn (2019), not exact paper reproduction.

Both arms use the same source IDs/XYZ and initial model in each setting.
original_observations contains original_XYZ, source_indices and frozen shared
masks. derived_inputs contains point roof probabilities for the existing DL arm;
they are predictions, not roof GT. The paper arm does not read those scores.
The shared NAIP TIFF is the exact original four-band crop; paper cues use RGB.
The common initial canonical model is sufficient to replay either backend.
Candidate and quality-checked outputs are separate; failed candidates do not
replace the common initial geometry in checked output.

Unzip on Lustre. Use the runtime versions in runtime.json. A bounded replay:
PYTHONPATH=. python replay_backend.py --data . \
 --building usbf-v1-dc-row84575-osm-67521488 --input raw --method paper \
 --seed 20261023 --output /lustre/isaac24/scratch/yfeng21/lod2_paper_replay/example

Use --method ours for frozen-score local reassignment. No old project checkout,
3DBAG reference data or neural training is required for these backend replays.
The original full orchestration script additionally invokes the locally installed
Roofer to create initial models. Ground/reference and footprint context are
recorded in those initial models and receipts. Real US roof GT is absent.

PROTOCOL.md and recipe.json describe the deviations and development selection.
The synthetic mechanism results are separate from real observational diagnostics.
