"""Exact common edge diagnostic copied from the existing pilot evaluator."""
import math,collections
import numpy as np

def open_ring(ring):
    points=np.asarray(ring,dtype=float)
    if points.ndim!=2 or points.shape[1]!=3:
        raise ValueError('Every surface ring must contain 3D XYZ coordinates')
    if not np.isfinite(points).all():
        raise ValueError('Nonfinite surface coordinates')
    if len(points)>1 and np.linalg.norm(points[0]-points[-1])<1e-8:
        points=points[:-1]
    return points

def edge_statistics(surfaces,tolerance=0.001):
    """Node collinear edges at every existing 3D vertex before incidence counts.

    Counts establish boundary-edge incidence, not self-intersection freedom,
    manifold vertex links, legal CityJSON semantics, or complete solid validity.
    """
    raw_edges=[];vertices=[];discarded=0
    for surface in surfaces:
        for ring in surface.get('rings',[]):
            rr=open_ring(ring)
            if len(rr)<2:continue
            for a,b in zip(rr,np.roll(rr,-1,axis=0)):
                if np.linalg.norm(b-a)<=tolerance/10:
                    discarded+=1;continue
                raw_edges.append((a,b))
                vertices.extend((a,b))
    empty=dict(edge_tolerance_m=tolerance,raw_ring_edges=len(raw_edges),noded_unique_edges=0,
               boundary_edges=0,nonmanifold_edges=0,orientation_inconsistent_edges=0,
               edges_with_two_incidences=0,all_edges_have_two_incidences=False,
               degenerate_edges_discarded=discarded)
    if not raw_edges:return empty
    # Quantization is explicit and reproducible. No source model is mutated.
    nodes=np.unique(np.rint(np.asarray(vertices)/tolerance).astype(np.int64),axis=0)
    xyz=nodes.astype(float)*tolerance
    edge_counts=collections.Counter();directions=collections.Counter()
    for a,b in raw_edges:
        vector=b-a;length2=float(vector@vector)
        tt=((xyz-a)@vector)/length2
        distance=np.linalg.norm(xyz-(a+tt[:,None]*vector),axis=1)
        keep=(tt>=-tolerance/math.sqrt(length2))&(tt<=1+tolerance/math.sqrt(length2))&(distance<=tolerance*1.01)
        ids=np.flatnonzero(keep)
        ids=ids[np.argsort(tt[ids])]
        for i,j in zip(ids[:-1],ids[1:]):
            if i==j:continue
            u,v=tuple(nodes[i]),tuple(nodes[j])
            key=(u,v) if u<v else (v,u)
            edge_counts[key]+=1
            directions[key]+=1 if u<v else -1
    counts=list(edge_counts.values())
    empty.update(noded_unique_edges=len(counts),boundary_edges=sum(n==1 for n in counts),
                 nonmanifold_edges=sum(n>2 for n in counts),edges_with_two_incidences=sum(n==2 for n in counts),
                 orientation_inconsistent_edges=sum(n==2 and directions[k]!=0 for k,n in edge_counts.items()),
                 all_edges_have_two_incidences=bool(counts) and all(n==2 for n in counts))
    return empty
