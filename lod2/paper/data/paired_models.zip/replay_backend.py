"""Replay either paired backend from the exported ZIP, without old project paths."""
from pathlib import Path
import argparse,json,copy
import numpy as np
import rasterio
from shapely.geometry import shape
from progressive import image_features,refine
from local_repair import propose,stitch
from shared_edge_check import edge_statistics

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--data',type=Path,required=True);ap.add_argument('--building',required=True);ap.add_argument('--input',choices=['raw','guarded'],default='raw');ap.add_argument('--method',choices=['paper','ours'],default='paper');ap.add_argument('--seed',type=int,default=20261023);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();root=a.data;bd=root/a.building/a.input
 initial=json.loads((bd/'initial/models.json').read_text())['buildings'][0];raw=np.load(root/'original_observations'/f'{a.building}.npz');xyz=raw['original_XYZ'];keep=raw['guarded_keep'] if a.input=='guarded' else np.ones(len(xyz),bool);config=json.loads((root/'config.json').read_text())
 if a.method=='paper':
  x0,y0,x1,y1=shape(initial['footprint']).bounds
  with rasterio.open(root/'shared_inputs/naip2014_roi_rgbnir_epsg26985.tif') as ds:
   w=rasterio.windows.from_bounds(x0-5,y0-5,x1+5,y1+5,ds.transform);r0=max(0,int(np.floor(w.row_off)));c0=max(0,int(np.floor(w.col_off)));r1=min(ds.height,int(np.ceil(w.row_off+w.height)));c1=min(ds.width,int(np.ceil(w.col_off+w.width)));window=rasterio.windows.Window(c0,r0,c1-c0,r1-r0);rgb=np.moveaxis(ds.read([1,2,3],window=window),0,-1);features=image_features(rgb,ds.window_transform(window),min_length=config['minimum_line_length_m'])
  candidate,report=refine(initial,xyz[keep],features,config,a.seed)
  if report.get('best_edits'):
   source_faces=[s.get('source_surface_index') for s in candidate['surfaces'] if s['type']=='RoofSurface'];candidate=stitch(candidate,{})
   for face in candidate['surfaces']:
    if face['type']=='RoofSurface':face['source_surface_index']=source_faces[face['source_surface_index']]
  else:candidate=copy.deepcopy(initial)
 else:
  score=np.load(root/'derived_inputs'/f'{a.building}.npz')['point_roof_probability'];replacement,review=propose(initial,xyz,keep,score);candidate=stitch(initial,replacement) if replacement else copy.deepcopy(initial);report=dict(replacement_surfaces=list(replacement),surface_review=review)
 t=edge_statistics(candidate['surfaces']);ok=t['all_edges_have_two_incidences'] and t['orientation_inconsistent_edges']==0;report.update(quality=t,quality_passed=bool(ok));a.output.mkdir(parents=True,exist_ok=True)
 for name,value in [('candidate.json',candidate),('checked.json',candidate if ok else initial),('report.json',report)]:
  (a.output/name).write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
 print(json.dumps(dict(output=str(a.output),method=a.method,quality_passed=bool(ok))))
if __name__=='__main__':main()
