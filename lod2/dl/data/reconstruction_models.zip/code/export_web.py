"""Export source evidence and matched US diagnostics, never invent local GT."""
from pathlib import Path
import copy,gzip,hashlib,importlib.util,json,os,shutil,zipfile
os.environ.setdefault('MPLCONFIGDIR','/lustre/isaac24/scratch/yfeng21/lod2_dl_round_20261026/cache/matplotlib')
import numpy as np
from scipy.spatial import cKDTree
from shapely import intersects_xy
from shapely.geometry import shape
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

H=Path('/nfs/home/yfeng21');R=Path('/lustre/isaac24/scratch/yfeng21/lod2_dl_round_20261026')
P=R/'public';A=H/'lod2_experiment_atlas/public';C=H/'lod2_dl_round_20261026';OUT=P/'dl/data'
RUN=R/'runs/reconstruction24_v1'
ALIAS={'linear':'linear','point':'point_mlp','fusion':'fusion_mlp','context':'local_context','context_fusion':'context_fusion','gated':'gated_fusion'}
LABELS={'raw':'原始候选点','legacy_guarded':'历史保护规则','linear':'线性基线','point':'点云 MLP','fusion':'特征融合 MLP','context':'局部邻域网络','context_fusion':'邻域＋光学融合','gated':'邻域＋可靠性门控','point_mlp':'点云 MLP','fusion_mlp':'特征融合 MLP','local_context':'局部邻域网络','gated_fusion':'邻域＋可靠性门控'}
METHODS=list(ALIAS.values())
def load(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,v):p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def ungz(p):return json.loads(gzip.decompress(Path(p).read_bytes()))
def gz(p,v):p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(gzip.compress(json.dumps(v,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode(),mtime=0))
def mod(n,p):s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def aggregate(rows):
    keys=['roof_retention','tree8_rejection','mean_iou','vegetation_or_fence_hedge_rejection','fence_hedge4_rejection']
    return {k:{'mean':float(np.mean([r[k] for r in rows])),'std':float(np.std([r[k] for r in rows]))} for k in keys}

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    final=load(R/'reports/final_metrics.json');freeze=load(R/'reports/training_freeze.json');native=load(RUN/'completion.json')
    assert final['status']=='complete' and native['status']=='complete'
    assert load(R/'reports/manager_training_audit.json')['status']=='training_receipts_passed'
    source=[]
    for method in METHODS:
        rr=[final['official_source_reference'][f'{method}_seed{s}'] for s in freeze['config']['seeds']]
        conditions={condition:aggregate([r[condition]['full_scene_with_point_fallback'] for r in rr]) for condition in rr[0]}
        source.append({'method':method,'clean':conditions['clean'],'conditions':conditions,
            'common_clean':aggregate([r['clean']['common_original_optical_coverage'] for r in rr])})
    lookup={r['method']:r for r in source}
    findings=[
        '光学融合值得继续：相同光学覆盖区域中，树木点剔除率从点云 MLP 的 %.2f%% 提高到融合 MLP 的 %.2f%%；这是源域参考结果。'%(100*lookup['point_mlp']['common_clean']['tree8_rejection']['mean'],100*lookup['fusion_mlp']['common_clean']['tree8_rejection']['mean']),
        '暂未证明门控有效：相对采用相同增强的邻域融合，门控的树木点剔除均值仅增加 %.2f 个百分点，mIoU反而下降；三个种子的变化不能作为独立样本显著性检验。'%(100*(lookup['gated_fusion']['common_clean']['tree8_rejection']['mean']-lookup['context_fusion']['common_clean']['tree8_rejection']['mean'])),
        '真正的瓶颈是跨区可靠性：验证区的99.5%%屋顶保留目标没有稳定迁移；完整源测试场景中，这轮方法的保留率为 %.2f%%–%.2f%%。'%(100*min(r['clean']['roof_retention']['mean'] for r in source),100*max(r['clean']['roof_retention']['mean'] for r in source)),
        '门控平均权重在干净、1米错位、2米错位条件下几乎不变。需要重新检查它学到的是可靠性，还是一个近似固定的光学权重。'
    ]
    summary={'schema':'lod2-dl-neighborhood-v1','status':'complete','building_count':native['requested_buildings'],
        'labels':LABELS,'source_summary':source,'reconstruction_summary':[{'method':k,**v,'shell_passed':v['shell_diagnostic_passed']} for k,v in native['summary'].items()],
        'training_records':freeze['config']['training_records'],'validation_records':freeze['config']['validation_records'],
        'source_test_records':411722,'target_records':82140,'source_test_historically_evaluated':True,
        'model_count':len(freeze['models']),'target_buildings':120,'findings':findings,
        'independent_US_GT':False,'reconstruction_seed':20261026,'source_full_metrics':final,
        'reconstruction_rows':native['rows'],'original_inputs_unchanged':native['original_inputs_unchanged']}
    spatial=R/'reports/spatial_web_summary.json'
    if spatial.exists():
        s=load(spatial);summary['spatialSummary']=s
        all_ret=[v['full_with_point_fallback']['roof_retention']['min'] for v in s['perMethod'].values()]
        summary['spatialFinding']='独立评价区的最低屋顶保留率为 %.2f%%。校准区达到99.5%%不能保证换区后仍然满足；需要把跨区风险作为下一轮重点。'%(100*min(all_ret))
    dump(OUT/'summary.json',summary)
    old=ungz(A/'data/tree.json.gz');helpers=mod('dl_web_frame',H/'lod2_optimization_20261019/tools/prepare_viewer_data.py');frame=helpers.LocalFrame(old['anchor'])
    exp=mod('dl_web_mesh',H/'lod2_experiment_atlas/tools/export_chapters.py');atlas={b['id']:b for b in old['buildings']}
    data={k:copy.deepcopy(old[k]) for k in ['schema','anchor','anchorMercator','meterInMercatorCoordinateUnits','localAxes','bounds','naip']}
    groups=native['methods'];data.update(chapter='dl',title='邻域与光学可靠性',groupOrder=groups,groupLabels={k:LABELS[k] for k in groups},baselineGroup='raw',groups={},buildingCount=24,buildings=[])
    products={g:{b['pilot_id']:b for b in load(RUN/'products'/f'{g}.json')['buildings']} for g in groups}
    predictions={g:np.load(R/'runs'/f'{m}_seed20261026/target_predictions.npz') for g,m in ALIAS.items()}
    old_prediction=np.load(H/'lod2_tree_20261020/data/target_predictions.npz')
    prepared=load(H/'lod2_overnight_20261020/data/prepared/buildings.json')['buildings'];original={b['pilot_id']:b for b in prepared}
    raw=np.load(H/'lod2_pilot_20261017/data/lidar/roi_points.npz')['points'];tree=cKDTree(raw[:,:2]);checks=[]
    for row in native['buildings']:
        bid=row['id'];b=copy.deepcopy(atlas[bid]);b['groups']={};b['dl']=row
        dec=np.load(RUN/'buildings'/bid/'decisions.npz');ids=dec['source_indices'];xyz=dec['original_XYZ'];assert np.array_equal(raw[ids],xyz)
        for g in groups:
            model=products[g][bid];mesh=exp.mesh_for_source(model,b['ground_z'],helpers,frame);fp=helpers.transform_geometry(model['footprint'],frame)
            mesh.update(lodClass='原生 LoD2' if row['methods'][g]['native_lod2'] else row['methods'][g]['status'],footprintGeometryLngLat=fp,footprintLngLat=fp['coordinates'][0],metrics={})
            if not row['methods'][g]['shell_diagnostic']:mesh.setdefault('previewWarnings',[]).append('边检查未通过；保留本方法实际结果，未以原始组替换')
            b['groups'][g]=mesh
        data['buildings'].append(b)
        base_path=A/'data/points'/f'{bid}.json.gz';cloud=ungz(base_path)
        crop=shape(original[bid]['footprint']).buffer(5);x0,y0,x1,y1=crop.bounds;center=np.array([(x0+x1)/2,(y0+y1)/2]);radius=np.linalg.norm(np.array([x1,y1])-center)+1e-5
        local=np.sort(np.asarray(tree.query_ball_point(center,radius),np.int64));local=local[intersects_xy(crop,raw[local,0],raw[local,1])]
        assert len(local)==len(cloud['flags'])
        assert np.array_equal(frame.xyz(raw[local],b['ground_z']).round(3).ravel(),np.asarray(cloud['positions']))
        where=np.searchsorted(local,ids);assert np.all(where<len(local)) and np.array_equal(local[where],ids)
        trains={g:where[dec[g+'_keep']].tolist() for g in groups};scores={}
        for g,p in predictions.items():
            ix=np.searchsorted(p['source_indices'],ids);assert np.array_equal(p['source_indices'][ix],ids)
            assert np.array_equal(~p['reject'][ix],dec[g+'_keep'])
            scores[g]=p['probabilities'][ix,1].round(5).astype(float).tolist()
        ix=np.searchsorted(old_prediction['source_indices'],ids);scores['legacy_guarded']=old_prediction['point'][ix,1].round(5).astype(float).tolist();scores['raw']=scores['legacy_guarded']
        overlay={'id':bid,'sourceIndices':local.tolist(),'original_payload_sha256':sha(base_path),
            'coordinate_contract':'coordinates reused byte-for-byte from existing immutable point payload; source indices reconstructed from original sorted crop and equality-checked',
            'trainSets':trains,'groupToTrainSet':{f'dl/{g}':g for g in groups},'groupToScoreModel':{f'dl/{g}':g for g in groups},
            'trainMemberships':{f'dl/{g}':{'sourceRecordCount':len(trains[g]),'matchingMethod':'exact immutable original source_indices'} for g in groups},
            'candidateLocalIndices':where.tolist(),'vegetation_scores':scores}
        gz(OUT/'points'/f'{bid}.json.gz',overlay)
        checks.append({'id':bid,'raw_count':len(local),'candidate_count':len(ids),'source_indices_exact':True,'old_observed_coordinates_identical':True,'methods':{g:len(trains[g]) for g in groups}})
    gz(OUT/'viewer.json.gz',data)
    for src,dest in [(R/'reports/training_freeze.json','training_freeze.json'),(R/'reports/manager_review.json','manager_review.json'),(R/'reports/manager_findings.json','manager_findings.json'),(R/'reports/manager_training_audit.json','manager_training_audit.json'),(R/'reports/manager_reconstruction_audit.json','manager_reconstruction_audit.json'),(C/'config.json','config.json')]:shutil.copy2(src,OUT/dest)
    if spatial.exists():
        for name in ['spatial_web_summary.json','spatial_validation_summary.json']:
            shutil.copy2(R/'reports'/name,OUT/name)
        for name in ['all_fold_training_freeze.json','spatial_design_freeze.json']:
            shutil.copy2(R/'spatial_validation/reports'/name,OUT/name)
        if (R/'reports/manager_spatial_audit.json').exists():shutil.copy2(R/'reports/manager_spatial_audit.json',OUT/'manager_spatial_audit.json')
        for name in ['spatial_folds.png','spatial_tradeoff.png']:
            if (R/'reports'/name).exists():shutil.copy2(R/'reports'/name,OUT/name)
    fig,axes=plt.subplots(2,2,figsize=(11,7),sharex=True);x=np.arange(len(source));names=['Linear','Point MLP','Fusion MLP','Context','Context fusion','Gated fusion']
    for col,scope in enumerate(['common_clean','clean']):
        for row,key in enumerate(['roof_retention','tree8_rejection']):
            ax=axes[row,col];means=[100*r[scope][key]['mean'] for r in source];errs=[100*r[scope][key]['std'] for r in source]
            ax.bar(x,means,yerr=errs,color=['#94a59a','#647c76','#418873','#6c839d','#837da0','#b18463'],capsize=3)
            if row==0:ax.axhline(99.5,color='#aa4a46',ls='--',lw=1);ax.set_ylim(95,100.2)
            else:ax.set_ylim(0,100)
            ax.set_ylabel(('Roof retention' if row==0 else 'Tree rejection')+' (%)');ax.set_title(('Common optical coverage' if col==0 else 'Full scene + declared fallback') if row==0 else '')
            ax.set_xticks(x,names,rotation=30,ha='right');ax.spines[['right','top']].set_visible(False)
    fig.suptitle('Official source reference: mean and population SD across 3 seeds; no US accuracy claim',fontsize=11);fig.tight_layout();fig.savefig(OUT/'source_metrics.png',dpi=150);plt.close(fig)
    with zipfile.ZipFile(OUT/'reconstruction_models.zip','w',zipfile.ZIP_DEFLATED) as z:
        for p in (RUN/'products').glob('*.json'):z.write(p,'models/'+p.name)
        for b in native['buildings']:z.write(RUN/'buildings'/b['id']/'decisions.npz','decisions/'+b['id']+'.npz')
        for p in [RUN/'completion.json',RUN/'recipe.json',C/'config.json',C/'README.md',R/'reports/training_freeze.json',R/'reports/manager_findings.json',R/'reports/data_audit.json']:
            z.write(p,('reconstruction_' if p.name in ['completion.json','recipe.json'] else '')+p.name)
        for p in (C/'tools').glob('*.py'):z.write(p,'code/'+p.name)
        for model in R.glob('runs/*_seed*/model.pt'):z.write(model,'weights/'+model.parent.name+'.pt')
        for report in R.glob('runs/*_seed*/training.json'):z.write(report,'training/'+report.parent.name+'.json')
        z.write(R/'data/normalization.npz','normalization.npz')
        if spatial.exists():
            for name in ['spatial_web_summary.json','spatial_validation_summary.json']:
                z.write(R/'reports'/name,name)
            for name in ['all_fold_training_freeze.json','spatial_design_freeze.json']:
                z.write(R/'spatial_validation/reports'/name,name)
            for model in R.glob('spatial_validation/folds/*/runs/*/model.pt'):
                z.write(model,'spatial_weights/'+str(model.relative_to(R/'spatial_validation/folds')))
            for report in R.glob('spatial_validation/folds/*/runs/*/training.json'):
                z.write(report,'spatial_training/'+str(report.relative_to(R/'spatial_validation/folds')))
    dump(R/'reports/web_export.json',{'passed':True,'cases':checks,'source_metrics_do_not_measure_US_accuracy':True,'original_XYZ_payloads_reused':True,'eight_meshes_per_building':True,'new_bytes':sum(p.stat().st_size for p in OUT.rglob('*') if p.is_file())})
    print(json.dumps({'public':str(P),'cases':len(checks),'groups':len(groups),'bytes':sum(p.stat().st_size for p in OUT.rglob('*') if p.is_file())}))

if __name__=='__main__':main()
