"""Compare frozen semantic rejection masks through one fixed native Roofer backend.

This stage measures input decisions, native outputs and geometry diagnostics;
there is no independent DC semantic/roof truth and no mesh correction/completion.
"""
from __future__ import annotations

import argparse
import copy
import datetime as dt
import hashlib
import importlib.util
import json
import os
import shutil
import sys
import time
import traceback
from collections import Counter
from pathlib import Path

import laspy
import numpy as np
from pyproj import Transformer
from shapely.geometry import shape


HOME = Path('/nfs/home/yfeng21')
CODE = HOME / 'lod2_dl_round_20261026'
ROOT = Path('/lustre/isaac24/scratch/yfeng21/lod2_dl_round_20261026')
TREE = HOME / 'lod2_tree_20261020'
PREVIOUS = HOME / 'lod2_overnight_20261020'
WORKFLOW = Path('/lustre/isaac24/scratch/yfeng21/lod2_workflow_20261022/runs/smoke8_v1')
CANOPY = Path('/lustre/isaac24/scratch/yfeng21/lod2_canopy_20261022/runs/probe8_v1')
METHOD_ALIASES = {'linear': 'linear', 'point': 'point_mlp', 'fusion': 'fusion_mlp',
                  'context': 'local_context', 'context_fusion': 'context_fusion',
                  'gated': 'gated_fusion'}
READS = {}


def utc():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def sha(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()


def array_sha(value):
    return hashlib.sha256(np.ascontiguousarray(value).tobytes()).hexdigest()


def bind(path):
    path = Path(path)
    READS[str(path)] = sha(path)
    return path


def load(path):
    return json.loads(bind(path).read_text())


def dump(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + '.partial')
    temporary.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
    temporary.replace(path)


def module(name, path):
    path = bind(path)
    specification = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(result)
    return result


W = module('round_fixed_native_wrapper', HOME / 'lod2_workflow_20261022/tools/run_workflow.py')
P = module('round_frozen_plane_protection', HOME / 'lod2_canopy_20261022/tools/run_probe.py')


def align_ids(all_ids, ids):
    position = np.searchsorted(all_ids, ids)
    assert np.all(position < len(all_ids))
    assert np.array_equal(all_ids[position], ids), 'Original source ID alignment failed'
    return position


def old_guarded(identity, ids, xyz, optical_valid, old_probabilities, old_ids, old_recipe, canopy_config):
    saved = CANOPY / 'buildings' / identity / 'decisions.npz'
    if saved.exists():
        with np.load(bind(saved)) as previous:
            assert np.array_equal(previous['source_indices'], ids)
            assert np.array_equal(previous['original_XYZ'], xyz)
            mask = previous['guarded_keep'].copy()
            protected = previous['plane_protected'].copy()
        return mask, {'provenance': 'exact_frozen_eight_case_guarded_keep', 'path': str(saved),
                      'plane_protected_points': int(protected.sum()), 'rule_extension': False}
    position = align_ids(old_ids, ids)
    point, image, fusion = (old_probabilities[k][position] for k in ['point', 'image', 'fusion'])
    uncertain = ~optical_valid | (point.argmax(1) != image.argmax(1))
    baseline_keep = (fusion[:, 1] < old_recipe['frontend_vegetation_cutoff']) | uncertain
    protected, planes = P.protect_observed_planes(xyz, point[:, 0], canopy_config['planes'])
    override = point[:, 1] > canopy_config['calibration']['point_override_threshold']
    mask = baseline_keep & (~override | protected)
    return mask, {'provenance': 'frozen_old_guarded_rules_extended_to_additional_building',
        'rule_extension': True, 'new_calibration': False,
        'base_removed': int((~baseline_keep).sum()), 'uncertain_retained_by_base': int(uncertain.sum()),
        'strong_point_override_proposed': int((override & baseline_keep).sum()),
        'strong_point_override_protected': int((override & baseline_keep & protected).sum()),
        'strong_point_override_accepted': int((override & baseline_keep & ~protected).sum()),
        'plane_protected_points': int(protected.sum()), 'observed_planes': planes,
        'fusion_cutoff': old_recipe['frontend_vegetation_cutoff'],
        'point_override_threshold': canopy_config['calibration']['point_override_threshold'],
        'point_override_comparison': 'strict_greater_than',
        'limitation': 'Same frozen prior decisions, thresholds and protection algorithm; not an already-existing result for these16 cases.'}


def failed_native(arm, identity, footprint, points, selected, error):
    initial = arm / 'initial'
    initial.mkdir(exist_ok=True)
    model = {'pilot_id': identity, 'status': 'failed', 'ground_z': None,
             'footprint': footprint, 'surfaces': [], 'lod': None, 'lod_class': 'failed',
             'reason': 'native_wrapper_exception', 'error': str(error)}
    dump(initial / 'models.json', {'method': 'roofer', 'crs': 'EPSG:26985', 'buildings': [model]})
    topology = W.G.edge_statistics([])
    receipt = {'id': identity, 'status': 'native_wrapper_exception',
        'returncode': None, 'seconds': None, 'roof_points': len(selected),
        'source_indices_sha256': array_sha(selected.astype('<i8')),
        'model_sha256': sha(initial / 'models.json'), 'topology': topology,
        'native_record': {'pilot_id': identity, 'has_geometry': False, 'lod2_success': False,
                           'lod1_fallback': False, 'status': 'wrapper_exception'},
        'model': model, 'error_type': type(error).__name__, 'error': str(error),
        'traceback': traceback.format_exc(), 'raw_substituted': False}
    dump(initial / 'receipt.json', receipt)
    return receipt


def model_diagnostics(receipt):
    model, record = receipt['model'], receipt['native_record']
    roof_faces = [surface for surface in model['surfaces'] if surface.get('type') == 'RoofSurface']
    vertices = [point for surface in roof_faces for ring in surface.get('rings', []) for point in ring]
    height = np.asarray(vertices, float)[:, 2] if vertices else np.empty(0)
    ground = model.get('ground_z')
    topology = receipt['topology']
    shell = bool(record.get('lod2_success') and topology.get('all_edges_have_two_incidences')
                 and topology.get('orientation_inconsistent_edges') == 0)
    execution_ok = receipt.get('status') == 'native_execution' and receipt.get('returncode') == 0
    status = ('native_LoD2' if record.get('lod2_success') else
              'LoD1_fallback' if record.get('lod1_fallback') else 'no_geometry')
    if not execution_ok:
        status = receipt.get('status', 'native_execution_failure') + ':' + status
    return {'status': status, 'native_lod2': bool(record.get('lod2_success')),
        'native_execution_ok': execution_ok, 'native_returncode': receipt.get('returncode'),
        'lod1_fallback': bool(record.get('lod1_fallback')), 'has_geometry': bool(model['surfaces']),
        'shell_diagnostic': shell, 'closed_solid_certified': False,
        'roof_surfaces': len(roof_faces), 'total_surfaces': len(model['surfaces']),
        'maximum_roof_z_m': float(height.max()) if len(height) else None,
        'minimum_roof_z_m': float(height.min()) if len(height) else None,
        'maximum_height_above_native_ground_m': float(height.max() - ground) if len(height) and ground is not None else None,
        'native_ground_z_m': ground,
        'boundary_edges': topology.get('boundary_edges'),
        'nonmanifold_edges': topology.get('nonmanifold_edges'),
        'orientation_inconsistent_edges': topology.get('orientation_inconsistent_edges'),
        'topology': topology, 'diagnostics_are_not_accuracy': True}


def prediction_inputs(root, methods, seed):
    learned = {}
    if any(method in METHOD_ALIASES for method in methods):
        freeze = load(root / 'reports/training_freeze.json')
        assert not freeze['config'].get('smoke', False), 'Cannot use smoke training as production evidence'
        assert freeze['config']['test_used_for_training_selection'] is False
        frozen_pairs = {(x['method'], int(x['seed'])): x for x in freeze['models']}
        for method in methods:
            if method not in METHOD_ALIASES:
                continue
            actual = METHOD_ALIASES[method]
            assert (actual, seed) in frozen_pairs
            checkpoint = frozen_pairs[(actual, seed)]
            assert sha(bind(checkpoint['checkpoint'])) == checkpoint['checkpoint_sha256']
            path = root / 'runs' / f'{actual}_seed{seed}' / 'target_predictions.npz'
            with np.load(bind(path)) as prediction:
                learned[method] = {key: prediction[key].copy() for key in prediction.files}
            learned[method]['provenance'] = {'predictions': str(path), 'actual_method': actual,
                'seed': seed, 'checkpoint': checkpoint['checkpoint'],
                'checkpoint_sha256': checkpoint['checkpoint_sha256'],
                'prediction_sha256': READS[str(path)],
                'decision_policy': 'use frozen model reject array directly, with its declared missing-optical fallback'}
    return learned


def progress(root, run, rows, planned, phase, started, **extra):
    value = {'phase': phase, 'status': phase, 'run_directory': str(run), 'updated_utc': utc(),
             'completed_cases': len(rows), 'planned_cases': planned,
             'elapsed_seconds': time.time() - started, **extra}
    dump(root / 'reports/reconstruction_status.json', value)
    dump(run / 'progress.json', value)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--run-name', default='reconstruction24_v1')
    parser.add_argument('--smoke', action='store_true')
    parser.add_argument('--resume', action='store_true')
    parser.add_argument('--max-wall-seconds', type=int, default=10800)
    args = parser.parse_args()
    assert args.root.resolve().is_relative_to(Path('/lustre/isaac24/scratch/yfeng21'))
    assert Path(args.run_name).name == args.run_name
    started = time.time()
    config = load(CODE / 'config.json')
    selection, methods = config['reconstruction_buildings'], config['reconstruction_methods']
    if args.smoke:
        selection = [next(x for x in selection if x['id'].endswith('67528254')),
                     next(x for x in selection if x['id'].endswith('67521493'))]
        methods = ['raw', 'legacy_guarded']
        if args.run_name == 'reconstruction24_v1':
            raise ValueError('Use a separate --run-name for smoke output')
    run = args.root / 'runs' / args.run_name
    if run.exists() and not args.resume:
        raise ValueError('Output exists; use a new run name or explicit --resume')
    run.mkdir(parents=True, exist_ok=True)
    preparation = load(PREVIOUS / 'data/preparation_manifest.json')
    parameters = preparation['groups']['global']['parameters']
    footprints = load(preparation['groups']['global']['footprints'])
    footprint_map = {str(x['properties']['pilot_id']): x['geometry'] for x in footprints['features']}
    old_recipe, canopy_config = load(WORKFLOW / 'recipe.json'), load(CANOPY / 'config.json')
    with np.load(bind(TREE / 'data/target.npz')) as target:
        all_ids, xyz_all, optical_valid = target['source_indices'], target['xyz'], target['optical_valid']
    with np.load(bind(TREE / 'data/target_predictions.npz')) as prediction:
        old_ids = prediction['source_indices']
        old_probabilities = {key: prediction[key] for key in ['point', 'image', 'fusion']}
    assert np.all(np.diff(all_ids) > 0) and np.all(np.diff(old_ids) > 0)
    learned = prediction_inputs(args.root, methods, int(config['seed_for_reconstruction']))
    ground_all = np.load(bind(PREVIOUS / 'data/prepared/ground_points.npy'))
    with laspy.open(bind(preparation['groups']['global']['shared_points'])) as source:
        header = copy.deepcopy(source.header)
    recipe = {'status': 'frozen_before_reconstruction', 'created_utc': utc(),
        'run_name': args.run_name, 'smoke': args.smoke, 'buildings': selection, 'methods': methods,
        'method_aliases': METHOD_ALIASES, 'seed': config['seed_for_reconstruction'],
        'selection': config['selection'], 'config_sha256': sha(CODE / 'config.json'),
        'runner_sha256': sha(Path(__file__)), 'native_parameters': parameters,
        'native_timeout_seconds': 120, 'actual_native_jobs': 1, 'ground_buffer_m': 12,
        'same_selected_IDs_reuse_exact_native_execution': True,
        'roof_filtering': 'Learned methods use their frozen reject array; no local threshold calibration.',
        'legacy_guarded': 'Exact frozen masks for eight focus cases; frozen rules with old probabilities expanded to16 ID-selected cases.',
        'raw_XYZ_immutable': True, 'new_backend_correction': False, 'post_trim': False,
        'occluded_roof_completion': False, 'target_GT_available': False,
        'native_closure_and_height_are_not_accuracy': True,
        'wall_budget_seconds': args.max_wall_seconds, 'input_sha256': dict(READS),
        'warning': 'Native fallback/failure is retained; a failed filtered arm is never replaced with the raw arm.'}
    recipe_path = run / 'recipe.json'
    if args.resume and recipe_path.exists():
        original_recipe = json.loads(recipe_path.read_text())
        for key in ['config_sha256', 'runner_sha256', 'methods', 'seed', 'buildings']:
            assert recipe[key] == original_recipe[key], 'Resume recipe changed: ' + key
    else:
        dump(recipe_path, recipe)
    rows, completed_buildings = [], []
    products = {method: [] for method in methods}
    planned = len(selection) * len(methods)
    progress(args.root, run, rows, planned, 'reconstructing', started)
    conversion = Transformer.from_crs('EPSG:26985', 'EPSG:4326', always_xy=True)
    try:
        for selected in selection:
            identity = selected['id']
            with np.load(bind(PREVIOUS / 'data/variants/global/buildings' / f'{identity}.npz')) as candidates:
                ids = candidates['source_indices']
            position = align_ids(all_ids, ids)
            xyz = xyz_all[position]
            source_hash, xyz_hash = array_sha(ids), array_sha(xyz)
            footprint = footprint_map[identity]
            x0, y0, x1, y1 = shape(footprint).bounds
            ground = ground_all[(ground_all[:, 0] >= x0 - 12) & (ground_all[:, 0] <= x1 + 12)
                & (ground_all[:, 1] >= y0 - 12) & (ground_all[:, 1] <= y1 + 12)]
            assert len(ground) > 0
            masks, evidence = {'raw': np.ones(len(ids), bool)}, {'raw': {'provenance': 'all_original_candidate_returns'}}
            if 'legacy_guarded' in methods:
                masks['legacy_guarded'], evidence['legacy_guarded'] = old_guarded(identity, ids, xyz,
                    optical_valid[position], old_probabilities, old_ids, old_recipe, canopy_config)
            for method, prediction in learned.items():
                where = align_ids(prediction['source_indices'], ids)
                masks[method] = ~prediction['reject'][where].astype(bool)
                evidence[method] = prediction['provenance']
            directory = run / 'buildings' / identity
            directory.mkdir(parents=True, exist_ok=True)
            decisions_path = directory / 'decisions.npz'
            if not decisions_path.exists():
                np.savez_compressed(decisions_path, source_indices=ids, original_XYZ=xyz,
                    **{method + '_keep': masks[method] for method in methods})
            else:
                with np.load(decisions_path) as previous:
                    assert np.array_equal(previous['source_indices'], ids)
                    assert np.array_equal(previous['original_XYZ'], xyz)
                    for method in methods:
                        assert np.array_equal(previous[method + '_keep'], masks[method])
            native_cache = {}
            per_building = []
            for method in methods:
                if time.time() - started > args.max_wall_seconds:
                    raise TimeoutError('Declared reconstruction wall budget exhausted')
                arm = directory / method
                arm.mkdir(exist_ok=True)
                mask = masks[method]
                chosen = np.flatnonzero(mask)
                selected_hash = array_sha(ids[mask])
                mask_hash = array_sha(mask)
                completion_path = arm / 'completion.json'
                if args.resume and completion_path.exists():
                    result = json.loads(completion_path.read_text())
                    assert result['selected_source_indices_sha256'] == selected_hash
                    assert result['keep_sha256'] == mask_hash
                    receipt = json.loads((arm / 'initial/receipt.json').read_text())
                    assert sha(arm / 'initial/models.json') == receipt['model_sha256']
                    native_cache.setdefault(selected_hash, (arm / 'initial', receipt))
                else:
                    if (arm / 'initial').exists():
                        raise RuntimeError('Partial native output exists; preserve it and choose a fresh run: ' + str(arm))
                    np.savez_compressed(arm / 'decisions.npz', source_indices=ids, original_XYZ=xyz,
                        keep=mask, reject=~mask, selected_source_indices=ids[mask])
                    reuse = selected_hash in native_cache
                    wall_start = time.time()
                    if reuse:
                        cached, receipt = native_cache[selected_hash]
                        shutil.copytree(cached, arm / 'initial', copy_function=os.link)
                        dump(arm / 'initial/reused_execution.json', {'source_directory': str(cached),
                            'reason': 'identical selected source IDs with the same building/footprint/ground/settings',
                            'source_model_sha256': receipt['model_sha256'],
                            'large_native_artifacts_hardlinked_within_Lustre': True})
                    else:
                        try:
                            receipt = W.native(arm, 'initial', identity, xyz, chosen, footprint,
                                               ground, header, parameters)
                        except Exception as error:
                            receipt = failed_native(arm, identity, footprint, xyz, chosen, error)
                        native_cache[selected_hash] = (arm / 'initial', receipt)
                    result = {'id': identity, 'method': method, 'actual_model_method': METHOD_ALIASES.get(method),
                        'cohort': selected['cohort'], 'phase': 'complete',
                        'original_points': len(ids), 'kept_points': int(mask.sum()),
                        'removed_points': int((~mask).sum()), 'removed_fraction': float((~mask).mean()),
                        'original_XYZ_sha256': xyz_hash, 'source_indices_sha256': source_hash,
                        'selected_source_indices_sha256': selected_hash, 'keep_sha256': mask_hash,
                        'ground_points': len(ground), 'ground_sha256': array_sha(ground),
                        'footprint_sha256': hashlib.sha256(json.dumps(footprint, sort_keys=True).encode()).hexdigest(),
                        'same_mask_native_execution_reused': reuse,
                        'native_execution_seconds': receipt.get('seconds'),
                        'incremental_arm_seconds': time.time() - wall_start,
                        'model_sha256': sha(arm / 'initial/models.json'),
                        'model_path': str(arm / 'initial/models.json'), 'provenance': evidence[method],
                        'post_trim_points': 0, 'raw_substituted': False,
                        'new_backend_correction': False, 'independent_target_GT': False,
                        **model_diagnostics(receipt)}
                    dump(completion_path, result)
                rows.append(result)
                per_building.append(result)
                product_model = copy.deepcopy(receipt['model'])
                product_model['round_method'] = method
                product_model['round_diagnostic_status'] = result['status']
                products[method].append(product_model)
                progress(args.root, run, rows, planned, 'reconstructing', started,
                    current_building=identity, current_method=method,
                    native_executions=sum(not x['same_mask_native_execution_reused'] for x in rows),
                    most_recent_case=result)
                print('RECONSTRUCT', len(rows), '/', planned, identity, method,
                      'removed', result['removed_points'], result['status'], 'shell', result['shell_diagnostic'],
                      'reused', result['same_mask_native_execution_reused'], flush=True)
            assert array_sha(xyz) == xyz_hash and array_sha(ids) == source_hash
            longitude, latitude = conversion.transform(shape(footprint).centroid.x, shape(footprint).centroid.y)
            building_summary = {'id': identity, 'cohort': selected['cohort'],
                'coordinates_lnglat': [longitude, latitude], 'original_points': len(ids),
                'decisions_npz': str(decisions_path), 'methods': {row['method']: row for row in per_building}}
            dump(directory / 'completion.json', building_summary)
            completed_buildings.append(building_summary)
        for path, before in READS.items():
            assert sha(path) == before, 'Immutable old input changed: ' + path
        for method in methods:
            dump(run / 'products' / f'{method}.json', {'method': method, 'crs': 'EPSG:26985',
                 'buildings': products[method], 'independent_target_GT': False})
        aggregate = {}
        for method in methods:
            subset = [row for row in rows if row['method'] == method]
            aggregate[method] = {'buildings': len(subset), 'removed_points': sum(x['removed_points'] for x in subset),
                'native_lod2': sum(x['native_lod2'] for x in subset),
                'native_execution_ok': sum(x['native_execution_ok'] for x in subset),
                'lod1_fallback': sum(x['lod1_fallback'] for x in subset),
                'has_geometry': sum(x['has_geometry'] for x in subset),
                'shell_diagnostic_passed': sum(x['shell_diagnostic'] for x in subset),
                'status_counts': dict(Counter(x['status'] for x in subset)),
                'same_mask_native_reuses': sum(x['same_mask_native_execution_reused'] for x in subset)}
        completion = {'status': 'complete', 'created_utc': utc(), 'smoke': args.smoke,
            'run_directory': str(run), 'requested_buildings': len(selection), 'methods': methods,
            'completed_cases': len(rows), 'planned_cases': planned, 'elapsed_seconds': time.time() - started,
            'recipe': recipe, 'summary': aggregate, 'buildings': completed_buildings, 'rows': rows,
            'input_sha256': READS, 'original_inputs_unchanged': True,
            'target_semantic_accuracy_available': False, 'target_roof_accuracy_available': False,
            'full_occlusion_completion': False, 'post_reconstruction_correction': False,
            'limitations': ['24 selected buildings are engineering diagnostics, not representative national sampling.',
                'Frozen old guarded masks cover8 focus cases;16 additional cases use frozen-rule extension.',
                'Source semantic rejection thresholds are not calibrated on independently labeled DC data.',
                'Native LoD2, edge incidence, point removal and maximum height do not measure roof accuracy.',
                'Removing points supplies no new evidence beneath completely occluding canopy.']}
        dump(run / 'completion.json', completion)
        progress(args.root, run, rows, planned, 'complete', started,
                 completion=str(run / 'completion.json'), summary=aggregate)
        print('COMPLETE', run, 'cases', len(rows), 'seconds', time.time() - started, flush=True)
    except BaseException as error:
        progress(args.root, run, rows, planned, 'failed', started, error_type=type(error).__name__,
                 error=str(error), traceback=traceback.format_exc())
        raise


if __name__ == '__main__':
    main()
