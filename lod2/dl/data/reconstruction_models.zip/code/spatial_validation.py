"""Four predeclared spatial re-holdouts inside source_train only.

This stage never opens source_test or target. All 48 checkpoints/calibrations
are frozen before held-out evaluation labels are used to compute any score.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import time
from pathlib import Path

import numpy as np
import torch
from scipy.spatial import cKDTree

import train_models as frozen_components
from prepare_data import neighborhoods

ROOT = Path('/lustre/isaac24/scratch/yfeng21/lod2_dl_round_20261026/spatial_validation')
SOURCE = Path('/nfs/home/yfeng21/lod2_tree_20261020/data/source_train.npz')
METHODS = ['point_mlp', 'fusion_mlp', 'context_fusion', 'gated_fusion']
SEEDS = [20261026, 20261027, 20261028]
PARTS = ['train', 'calibration', 'evaluation']


def receipt(path):
    return {'path': str(path), 'sha256': frozen_components.digest(path), 'bytes': Path(path).stat().st_size}


def gap(xyz, left, right):
    if not len(left) or not len(right):
        return None
    tree = cKDTree(xyz[left, :2])
    distances, _ = tree.query(xyz[right, :2], k=1, workers=2)
    return float(distances.min())


def make_splits(xyz):
    mx, my = np.median(xyz[:, :2], axis=0)
    high_x, high_y = xyz[:, 0] >= mx, xyz[:, 1] >= my
    quadrant = high_x.astype(np.int8) + 2 * high_y.astype(np.int8)
    plans = []
    for fold in range(4):
        holdout = quadrant == fold
        axis = fold % 2  # fixed before looking at semantic labels or outcomes
        cut = float(np.median(xyz[holdout, axis]))
        dx = np.maximum((mx - xyz[:, 0]) if fold & 1 else (xyz[:, 0] - mx), 0)
        dy = np.maximum((my - xyz[:, 1]) if fold & 2 else (xyz[:, 1] - my), 0)
        distance_to_holdout_rectangle = np.sqrt(dx * dx + dy * dy)
        train = (~holdout) & (distance_to_holdout_rectangle >= 5.)
        calibration = holdout & (xyz[:, axis] <= cut - 2.5)
        evaluation = holdout & (xyz[:, axis] >= cut + 2.5)
        split = np.full(len(xyz), 3, np.int8)
        split[train], split[calibration], split[evaluation] = 0, 1, 2
        plans.append({'fold': fold, 'split': split, 'split_axis': 'xy'[axis],
                      'calibration_evaluation_cut_m': cut, 'quadrant_median_xy_m': [float(mx), float(my)]})
    return plans


class FoldScene(frozen_components.Scene):
    """Same frozen feature/model interface, with a new split and masked eval labels."""
    def __init__(self, raw, plan, fold_root, normalization, device, reveal_evaluation=False):
        self.name = 'source_train'
        self.source_path = SOURCE
        self.xyz = raw['xyz']
        self.valid_np = raw['optical_valid'].astype(bool)
        self.ids = np.arange(len(self.xyz))
        self.split = plan['split']
        gm, gs, om, osd = [normalization[key] for key in ['gm', 'gs', 'om', 'os']]
        self.g = torch.as_tensor(np.clip((raw['geometry'] - gm) / gs, -12, 12), dtype=torch.float32, device=device)
        self.o = torch.as_tensor(np.clip((raw['optical'] - om) / osd, -12, 12), dtype=torch.float32, device=device)
        self.available = torch.as_tensor(self.valid_np[:, None], dtype=torch.float32, device=device)
        visible = (self.split <= 1) | (reveal_evaluation & (self.split == 2))
        self.labels_np = np.full(len(self.xyz), -100, np.int64)
        self.labels_np[visible] = raw['labels'][visible]
        self.original_labels = np.full(len(self.xyz), -100, np.int64)
        self.original_labels[visible] = raw['original_labels'][visible]
        self.labels = torch.as_tensor(self.labels_np, dtype=torch.long, device=device)
        neighbors = np.load(fold_root / 'data/source_train_neighbors.npz')
        self.neighbors = torch.as_tensor(neighbors['indices'].astype(np.int64), device=device)
        self.relative = torch.as_tensor(neighbors['relative_xyz'], dtype=torch.float32, device=device)
        self.neighbor_valid = torch.as_tensor(neighbors['valid'], dtype=torch.bool, device=device)
        self.device = device
        self.shifts = self.shift_valid = None


def wilson(successes, total):
    if not total:
        return None
    p, z = successes / total, 1.959963984540054
    denominator = 1 + z * z / total
    center = (p + z * z / (2 * total)) / denominator
    half = z * math.sqrt(p * (1 - p) / total + z * z / (4 * total * total)) / denominator
    return [center - half, center + half]


def evaluate_fold(scene, metadata, frozen, config, fold_root):
    ids = np.flatnonzero(scene.split == 2)
    labels, original = scene.labels_np[ids], scene.original_labels[ids]
    common = scene.valid_np[ids]
    fallback = {}
    for seed in SEEDS:
        point = next(run for run in frozen if run['method'] == 'point_mlp' and run['seed'] == seed)
        model, checkpoint = frozen_components.load_model(point['checkpoint'], scene.device)
        logits = frozen_components.predict(model, scene, ids, config['inference_batch_size'])
        calibration = checkpoint['calibration_full']
        fallback[seed] = (frozen_components.softmax(logits / calibration['temperature']), calibration['threshold'])
        del model
    outputs = []
    for run in frozen:
        method, seed = run['method'], run['seed']
        model, checkpoint = frozen_components.load_model(run['checkpoint'], scene.device)
        logits = frozen_components.predict(model, scene, ids, config['inference_batch_size'])
        cal_common, cal_full = checkpoint['calibration_common'], checkpoint['calibration_full']
        probabilities_common = frozen_components.softmax(logits / cal_common['temperature'])
        probabilities_full = frozen_components.softmax(logits / cal_full['temperature'])
        thresholds = np.full(len(ids), cal_full['threshold'])
        if method in frozen_components.OPTICAL:
            probabilities_full[~common] = fallback[seed][0][~common]
            thresholds[~common] = fallback[seed][1]
        reject_common = probabilities_common[:, 1] >= cal_common['threshold']
        reject_full = probabilities_full[:, 1] >= thresholds
        metrics_common = frozen_components.classification_metrics(labels[common], probabilities_common[common],
                                                                  reject_common[common], original[common])
        metrics_full = frozen_components.classification_metrics(labels, probabilities_full, reject_full, original)
        count_roof = int((labels == 0).sum())
        retained_roof = int((~reject_full[labels == 0]).sum())
        output = fold_root / 'runs' / f'{method}_seed{seed}' / 'spatial_evaluation.npz'
        np.savez_compressed(output, source_rows=ids, probabilities=probabilities_full.astype(np.float32),
                            reject=reject_full, probabilities_common=probabilities_common.astype(np.float32),
                            optical_valid=common)
        report = {'fold': metadata['fold'], 'method': method, 'seed': seed,
                  'evaluation_records': len(ids), 'evaluation_tree8_records': int((original == 8).sum()),
                  'evaluation_roof_records': count_roof,
                  'common_optical': metrics_common, 'full_with_point_fallback': metrics_full,
                  'calibration_roof_records': cal_common['calibration_roof_records'],
                  'calibration_roof_retention': cal_common['validation_roof_retention'],
                  'calibration_false_rejection_target': .005,
                  'calibration_roof_retention_discreteness': 1. / cal_common['calibration_roof_records'],
                  'pointwise_binomial_wilson95_roof_retention': wilson(retained_roof, count_roof),
                  'CI_limitation': 'Pointwise binomial interval assumes independent returns; spatially correlated roof points violate this. It is not a building-level or geographic confidence interval.',
                  'checkpoint_sha256': run['checkpoint_sha256'], 'evaluation_output': receipt(output)}
        outputs.append(report)
        del model
    return outputs


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--prepare-only', action='store_true')
    args = parser.parse_args()
    root = args.root
    started = time.time()
    for directory in ['data', 'reports', 'folds', 'logs']:
        (root / directory).mkdir(parents=True, exist_ok=True)
    torch.set_num_threads(4)
    torch.backends.cuda.matmul.allow_tf32 = True
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    if not args.prepare_only and device.type != 'cuda':
        raise RuntimeError('Production spatial training requires GPU allocation')
    source_hash = frozen_components.digest(SOURCE)
    with np.load(SOURCE) as data:
        # The file contains labels, but evaluation labels are masked in FoldScene
        # and no evaluation scores/counts by class are computed before freeze.
        raw = {key: data[key] for key in ['xyz', 'geometry', 'optical', 'optical_valid', 'labels', 'original_labels']}
    plans = make_splits(raw['xyz'])
    design = {'created_utc': frozen_components.utc(), 'stage': 'source_train_spatial_reholdout_v1',
        'source': receipt(SOURCE), 'source_test_opened': False, 'target_opened': False,
        'historical_points_were_used_in_earlier_training': True,
        'methods': METHODS, 'seeds': SEEDS, 'folds': [],
        'split_recipe': 'Four XY median quadrants. Hold out each quadrant; training other three quadrants is at least5m from its rectangle. Holdout is cut by x for folds0/2 and y for folds1/3; calibration belowmedian-2.5m, evaluation abovemedian+2.5m.',
        'neighbor_recipe': 'K16 within5m, same train/calibration/evaluation/embargo group; no labels in neighborhood or shift lookup.',
        'maximum_training_rows': 200000, 'epochs': 40, 'patience': 6, 'minimum_epochs': 8,
        'minimum_train_rows': 10000, 'minimum_calibration_rows': 5000,
        'minimum_evaluation_rows': 5000, 'minimum_calibration_roofs': 1000,
        'minimum_evaluation_tree8_for_scoring': 100,
        'normalization': 'Perfold train-only, same sampled training rows across methods and random seeds.',
        'holdout_policy': 'Every fold checkpoint/calibration must be frozen before any evaluation score is computed.',
        'legacy_geometry_caveat': 'Existing geometric descriptors use fullscene unlabeled XYZ; new learned-neighbor aggregation is split-local. This is not a completely transductive-free recomputation of descriptors.',
        'confidence_interval_caveat': 'Return-level binomial CIs are illustrative only because points on roofs/trees are correlated; geographic sample size is four folds of one scene.',
        'spatial_script': receipt(Path(__file__)),
        'frozen_training_component': receipt(Path(frozen_components.__file__)),
        'frozen_neighbor_component': receipt(Path(__file__).with_name('prepare_data.py')),
        'slurm_job_id': os.environ.get('SLURM_JOB_ID'), 'slurm_step_id': os.environ.get('SLURM_STEP_ID')}
    # Declare all geometric splits/IDs before training, without evaluation scores.
    for plan in plans:
        fold = plan['fold']
        split = plan['split']
        fold_root = root / 'folds' / f'fold{fold}'
        for directory in ['data', 'reports', 'runs']:
            (fold_root / directory).mkdir(parents=True, exist_ok=True)
        ids = {name: np.flatnonzero(split == code) for code, name in enumerate(PARTS)}
        train_ids = np.random.default_rng(20261026 + fold).permutation(ids['train'][raw['optical_valid'][ids['train']]])[:200000]
        calibration_ids = ids['calibration'][raw['optical_valid'][ids['calibration']]]
        np.savez_compressed(fold_root / 'data/rows.npz', split=split, training=train_ids,
                            calibration=calibration_ids, calibration_full=ids['calibration'], evaluation=ids['evaluation'])
        gap_a = gap(raw['xyz'], ids['train'], ids['calibration'])
        gap_b = gap(raw['xyz'], ids['train'], ids['evaluation'])
        gap_c = gap(raw['xyz'], ids['calibration'], ids['evaluation'])
        assert min(gap_a, gap_b, gap_c) >= 5. - 1e-6
        cal_roof_count = int((raw['labels'][calibration_ids] == 0).sum())
        enough = len(train_ids) >= 10000 and len(calibration_ids) >= 5000 and len(ids['evaluation']) >= 5000 and cal_roof_count >= 1000
        metadata = {key: value for key, value in plan.items() if key != 'split'}
        metadata.update({'training_rows': len(train_ids), 'calibration_rows': len(calibration_ids),
            'calibration_roof_records': cal_roof_count, 'evaluation_rows': len(ids['evaluation']),
            'row_hashes': {name: frozen_components.array_digest(rows) for name, rows in ids.items()},
            'selected_train_ids_sha256': frozen_components.array_digest(train_ids),
            'selected_calibration_ids_sha256': frozen_components.array_digest(calibration_ids),
            'minimum_xy_gaps_m': {'train_calibration': gap_a, 'train_evaluation': gap_b, 'calibration_evaluation': gap_c},
            'row_intersections': {'train_calibration': 0, 'train_evaluation': 0, 'calibration_evaluation': 0},
            'eligible': bool(enough), 'skip_reason': None if enough else 'Predeclared minimum train/calibration/evaluation/calibration-roof sample count not met'})
        design['folds'].append(metadata)
    design_path = root / 'reports/spatial_design_freeze.json'
    frozen_components.write_json(design_path, design)
    frozen_components.write_json(root / 'reports/spatial_status.json', {'phase': 'preparing_neighborhoods', 'updated_utc': frozen_components.utc()})
    if not all(fold['eligible'] for fold in design['folds']):
        frozen_components.write_json(root / 'reports/spatial_validation_summary.json', {'status': 'skipped_insufficient_predeclared_samples', 'design': design})
        return
    for plan in plans:
        fold_root = root / 'folds' / f"fold{plan['fold']}"
        destination = fold_root / 'data/source_train_neighbors.npz'
        if destination.exists():
            raise RuntimeError(f'Refusing to reuse unverified previous fold neighborhoods: {destination}')
        indices, relative, valid, groups = neighborhoods(raw['xyz'], plan['split'], 16, 5.)
        np.savez_compressed(destination, indices=indices, relative_xyz=relative, valid=valid, k=16, radius_m=5.)
        frozen_components.write_json(fold_root / 'reports/neighbor_audit.json', {'groups': groups,
            'new_neighbors_cross_split': False, 'labels_used': False, 'output': receipt(destination)})
        del indices, relative, valid
        print('Prepared fold', plan['fold'], flush=True)
    if args.prepare_only:
        return
    frozen = []
    normalization_by_fold = {}
    configs = {}
    for plan, metadata in zip(plans, design['folds']):
        fold = plan['fold']
        fold_root = root / 'folds' / f'fold{fold}'
        rows = np.load(fold_root / 'data/rows.npz')
        train_ids, calibration_ids, calibration_full_ids = rows['training'], rows['calibration'], rows['calibration_full']
        normalization = {'gm': raw['geometry'][train_ids].mean(0),
            'gs': np.maximum(raw['geometry'][train_ids].std(0), .03),
            'om': raw['optical'][train_ids].mean(0), 'os': np.maximum(raw['optical'][train_ids].std(0), .03)}
        normalization_by_fold[fold] = normalization
        normalization_path = fold_root / 'data/normalization.npz'
        np.savez(normalization_path, **normalization)
        config = {'created_utc': frozen_components.utc(), 'fold': fold, 'methods': METHODS, 'seeds': SEEDS,
            'epochs': 40, 'minimum_epochs': 8, 'patience': 6, 'batch_size': 2048,
            'inference_batch_size': 4096, 'learning_rate': .001,
            'training_records': len(train_ids), 'validation_records': len(calibration_ids),
            'train_ids_sha256': frozen_components.array_digest(train_ids),
            'validation_ids_sha256': frozen_components.array_digest(calibration_ids),
            'normalization_sha256': frozen_components.digest(normalization_path),
            'source_train_sha256': source_hash, 'script_sha256': design['spatial_script']['sha256'],
            'training_component_sha256': design['frozen_training_component']['sha256'],
            'spatial_design_sha256': frozen_components.digest(design_path),
            'augmentation_isolation': 'context_fusion/gated_fusion use same per-seed independent augmentation RNG and row order',
            'gate_supervision': 'Source three-class CE only; no direct gate labels',
            'source_test_opened': False, 'target_opened': False}
        configs[fold] = config
        frozen_components.write_json(fold_root / 'reports/training_design.json', config)
        scene = FoldScene(raw, plan, fold_root, normalization, device)
        assert np.all(scene.labels_np[plan['split'] == 2] == -100)
        scene.prepare_shifts(fold_root)
        for seed in SEEDS:
            for method in METHODS:
                frozen_components.write_json(root / 'reports/spatial_status.json', {'phase': 'training', 'fold': fold,
                    'seed': seed, 'method': method, 'completed_models': len(frozen), 'total_models': 48,
                    'updated_utc': frozen_components.utc()})
                report = frozen_components.train_one(method, seed, scene, train_ids, calibration_ids,
                    calibration_full_ids, config, fold_root,
                    {'started_utc': design['created_utc'], 'total_models': 12}, started + 3600)
                report['fold'] = fold
                frozen.append(report)
        del scene
        torch.cuda.empty_cache()
    assert len(frozen) == 48
    assert frozen_components.digest(SOURCE) == source_hash
    assert frozen_components.digest(__file__) == design['spatial_script']['sha256']
    assert frozen_components.digest(Path(frozen_components.__file__)) == design['frozen_training_component']['sha256']
    freeze_path = root / 'reports/all_fold_training_freeze.json'
    frozen_components.write_json(freeze_path, {'freeze_utc': frozen_components.utc(), 'models': frozen,
        'spatial_design_sha256': frozen_components.digest(design_path),
        'evaluation_scores_computed_before_freeze': False, 'source_test_opened': False, 'target_opened': False})
    evaluation_started = frozen_components.utc()
    outputs = []
    for plan, metadata in zip(plans, design['folds']):
        fold = plan['fold']
        fold_root = root / 'folds' / f'fold{fold}'
        scene = FoldScene(raw, plan, fold_root, normalization_by_fold[fold], device, reveal_evaluation=True)
        tree_count = int((scene.original_labels[plan['split'] == 2] == 8).sum())
        if tree_count < 100:
            outputs.append({'fold': fold, 'status': 'skipped_insufficient_tree8_evaluation_count', 'tree8_records': tree_count})
        else:
            outputs.extend(evaluate_fold(scene, metadata, [run for run in frozen if run['fold'] == fold], configs[fold], fold_root))
        del scene
        torch.cuda.empty_cache()
    summaries = {}
    valid_outputs = [row for row in outputs if 'method' in row]
    for method in METHODS:
        selected = [row for row in valid_outputs if row['method'] == method]
        values = {}
        for scope in ['common_optical', 'full_with_point_fallback']:
            values[scope] = {}
            for metric in ['roof_retention', 'tree8_rejection', 'mean_iou']:
                scores = [row[scope][metric] for row in selected]
                values[scope][metric] = {'unweighted_fold_seed_mean': float(np.mean(scores)) if scores else None,
                                        'fold_seed_std': float(np.std(scores)) if scores else None, 'values': scores}
        values['evaluation_roof_retention_below_995_cases'] = sum(row['full_with_point_fallback']['roof_retention'] < .995 for row in selected)
        values['evaluated_fold_seed_cases'] = len(selected)
        summaries[method] = values
    paired = {}
    for scope in ['common_optical', 'full_with_point_fallback']:
        paired[scope] = {}
        for metric in ['roof_retention', 'tree8_rejection', 'mean_iou']:
            differences = []
            for row in valid_outputs:
                if row['method'] != 'gated_fusion':
                    continue
                control = next(other for other in valid_outputs if other['fold'] == row['fold']
                    and other['seed'] == row['seed'] and other['method'] == 'context_fusion')
                differences.append({'fold': row['fold'], 'seed': row['seed'],
                                    'delta': row[scope][metric] - control[scope][metric]})
            paired[scope][metric] = {'mean_delta': float(np.mean([row['delta'] for row in differences])) if differences else None,
                                    'paired_values': differences,
                                    'inference_limit': 'Correlated seeds/folds are descriptive repeats, not independent geographic samples.'}
    summary = {'status': 'complete', 'completed_utc': frozen_components.utc(),
        'elapsed_seconds': time.time() - started, 'source_test_opened': False, 'target_opened': False,
        'spatial_design': receipt(design_path), 'all_fold_training_freeze': receipt(freeze_path),
        'all_models_frozen_utc': json.loads(freeze_path.read_text())['freeze_utc'],
        'evaluation_started_utc': evaluation_started, 'models': len(frozen),
        'source_train_sha256_unchanged': frozen_components.digest(SOURCE) == source_hash,
        'folds': design['folds'], 'results': outputs, 'method_summary': summaries,
        'paired_gate_minus_context_fusion': paired,
        'limitations': ['This is a new split in an already used source scene, not newly acquired blind validation data.',
            'Four folds from one city do not establish US generalization.',
            'Point labels do not validate LoD2 geometry or occluded roof completion.',
            'The 99.5 percent constraint is calibrated locally and may fail on a spatially distinct half-quadrant.',
            'Legacy geometric features use fullscene label-free XYZ context.',
            'Perpoint binomial confidence intervals ignore spatial dependence; no building-level independent sample count is available.']}
    frozen_components.write_json(root / 'reports/spatial_validation_summary.json', summary)
    frozen_components.write_json(root.parent / 'reports/spatial_validation_summary.json', summary)
    frozen_components.write_json(root / 'reports/spatial_status.json', {'phase': 'complete',
        'updated_utc': frozen_components.utc(), 'completed_models': 48, 'elapsed_seconds': time.time() - started})
    print('SPATIAL VALIDATION COMPLETE', time.time() - started, flush=True)


if __name__ == '__main__':
    main()
