"""Audit immutable pilot inputs and prepare label-free, split-local neighborhoods.

Runs on a Slurm compute step; outputs are restricted to this round's Lustre tree.
The original NPZ feature arrays are referenced in-place, never copied or changed.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
from scipy.spatial import cKDTree


SOURCE = Path('/nfs/home/yfeng21/lod2_tree_20261020/data')
OUTPUT = Path('/lustre/isaac24/scratch/yfeng21/lod2_dl_round_20261026')
CLASS_NAMES = ['roof', 'vegetation_or_fence_hedge', 'other']
OFFICIAL_NAMES = ['powerline', 'low_vegetation', 'impervious_surfaces', 'car',
                  'fence_hedge', 'roof', 'facade', 'shrub', 'tree']
FOCUS_OSM = ['67521488', '67521431', '67521425', '67521385', '67521498',
             '67521381', '66347628', '67528254']


def digest(path: Path) -> str:
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()


def atomic_json(path: Path, value: dict) -> None:
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def file_receipt(path: Path) -> dict:
    return {'path': str(path), 'physical_path': str(path.resolve()),
            'bytes': path.stat().st_size, 'sha256': digest(path)}


def neighborhoods(xyz: np.ndarray, split: np.ndarray, k: int, radius: float):
    count = len(xyz)
    indices = np.repeat(np.arange(count, dtype=np.int32)[:, None], k, axis=1)
    relative = np.zeros((count, k, 3), np.float32)
    valid = np.zeros((count, k), bool)
    valid[:, 0] = True
    summaries = {}
    for group in np.unique(split):
        members = np.flatnonzero(split == group)
        tree = cKDTree(xyz[members])
        actual_k = min(k, len(members))
        for start in range(0, len(members), 16384):
            centers = members[start:start + 16384]
            distances, nearest = tree.query(xyz[centers], k=actual_k, workers=2)
            if actual_k == 1:
                distances, nearest = distances[:, None], nearest[:, None]
            global_nearest = members[nearest]
            # Remove exactly the central row, not other returns with identical XYZ.
            # Stable sorting retains KD-tree distance order for all other returns.
            is_center = global_nearest == centers[:, None]
            order = np.argsort(is_center, axis=1, kind='stable')
            candidate = np.take_along_axis(global_nearest, order, axis=1)[:, :k - 1]
            candidate_distance = np.take_along_axis(distances, order, axis=1)[:, :k - 1]
            usable = (candidate != centers[:, None]) & (candidate_distance <= radius)
            width = candidate.shape[1]
            padded = np.where(usable, candidate, centers[:, None]).astype(np.int32)
            indices[centers, 1:1 + width] = padded
            valid[centers, 1:1 + width] = usable
            relative[centers, 1:1 + width] = (xyz[padded] - xyz[centers, None]).astype(np.float32)
        summaries[str(int(group))] = {
            'records': int(len(members)),
            'mean_valid_neighbors_including_center': float(valid[members].sum(1).mean()),
            'only_center': int((valid[members].sum(1) == 1).sum()),
        }
    assert np.array_equal(indices[:, 0], np.arange(count))
    assert np.all(split[indices] == split[:, None]), 'Neighborhood crossed a supervised split'
    assert np.max(np.linalg.norm(relative, axis=-1)) <= radius + 1e-5
    assert np.isfinite(relative).all()
    assert np.all(relative[~valid] == 0)
    return indices, relative, valid, summaries


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, default=OUTPUT)
    parser.add_argument('--k', type=int, default=16)
    parser.add_argument('--radius-m', type=float, default=5.)
    args = parser.parse_args()
    if not str(args.output.resolve()).startswith('/lustre/isaac24/scratch/yfeng21/'):
        raise ValueError('Large preparation outputs must remain on Lustre')
    if args.k < 2 or args.radius_m <= 0:
        raise ValueError('Invalid neighborhood size')
    started = time.time()
    data_dir, reports_dir = args.output / 'data', args.output / 'reports'
    data_dir.mkdir(parents=True, exist_ok=True)
    reports_dir.mkdir(parents=True, exist_ok=True)
    source_audit = json.loads((SOURCE.parent / 'reports/feature_preparation.json').read_text())
    manifest = {
        'version': 'split-local-neighbors-v1', 'created_utc': datetime.now(timezone.utc).isoformat(),
        'k': args.k, 'radius_m': args.radius_m,
        'neighbor_schema': {
            'indices': 'int32 [N,K], global row index into original dataset NPZ; first column is center',
            'relative_xyz': 'float32 [N,K,3] in meters; subtract original center XYZ; divide by5m in model if desired',
            'valid': 'bool [N,K], valid observed neighbors within radius; invalid slots padded with center',
            'radius_m': 'float32 scalar', 'k': 'int32 scalar',
        },
        'class_names': CLASS_NAMES,
        'official_label_mapping': {'roof': [5], 'vegetation_or_fence_hedge': [1, 4, 7, 8],
                                   'other': [0, 2, 3, 6]},
        'datasets': {},
        'context_policy': 'New learned-neighborhood inputs use same-split source-train points; source-test scene independent; target all frozen unlabeled candidate points.',
        'legacy_feature_context_caveat': 'Existing handcrafted geometry34 uses all unlabeled points in each source scene, including validation/embargo XYZ. It uses no semantic labels. New learned neighborhoods are split-local but this is not a complete recomputation of legacy descriptors.',
        'test_policy': 'Freeze model/checkpoint/temperature/threshold/selection using source train+validation only; source_test labels are evaluation-only. Source_test split field is legacy and must not make additional training rows. This official test was evaluated in the historical20261020 experiment and is not a newly unseen dataset.',
        'source_optical_channels': ['Red', 'Green', 'NIR'],
        'blue_channel_available_in_shared_training': False,
        'optical_features_resolution_m': 1.,
        'target_semantic_or_roof_gt': None,
        'source_label_reference': 'https://isprs.org/resources/datasets/benchmarks/UrbanSemLab/3d-semantic-labeling.aspx',
        'source_label_reference_local': str(SOURCE / 'external/readme.txt'),
        'source_optical_missing_policy': 'Retain explicit optical_valid flags; optical zeros are not evidence of roof/vegetation.',
        'neighbor_model_input_dimensions': {'center_geometry': 34, 'center_optical': 8,
                                             'neighbor_geometry_and_relative_xyz': 37},
        'script_sha256': digest(Path(__file__)),
    }
    audit = {'status': 'running', 'started_utc': manifest['created_utc'], 'datasets': {},
             'raw_xyz_changed': False, 'labels_used_to_build_neighborhoods': False,
             'new_learned_neighbor_cross_split_pairs': 0, 'target_gt_available': False,
             'historical_source_feature_audit': source_audit,
             'official_label_names': dict(enumerate(OFFICIAL_NAMES)),
             'important_semantic_limit': 'The shared positive nuisance class includes Fence/Hedge as well as vegetation. Report tree(label8) separately; merged-class rejection is not canopy-only accuracy.'}
    atomic_json(reports_dir / 'data_audit.json', audit)
    original_receipts = {}
    for name in ['source_train', 'source_test', 'target']:
        source_path = SOURCE / f'{name}.npz'
        before = file_receipt(source_path)
        original_receipts[name] = before
        with np.load(source_path) as loaded:
            xyz = loaded['xyz']
            geometry = loaded['geometry']
            optical = loaded['optical']
            optical_valid = loaded['optical_valid']
            assert geometry.shape == (len(xyz), 34)
            assert optical.shape == (len(xyz), 8)
            assert np.isfinite(xyz).all() and np.isfinite(geometry).all() and np.isfinite(optical).all()
            group = loaded['split'] if name == 'source_train' else np.zeros(len(xyz), np.int8)
            details = {'input': before, 'records': int(len(xyz)),
                       'geometry_shape': list(geometry.shape), 'optical_shape': list(optical.shape),
                       'optical_valid_records': int(optical_valid.sum()),
                       'xyz_sha256': hashlib.sha256(np.ascontiguousarray(xyz).tobytes()).hexdigest(),
                       'xyz_dtype': str(xyz.dtype),
                       'fields': list(loaded.files),
                       'supervision': 'official_source_labels' if name != 'target' else 'none'}
            if name != 'target':
                labels, original = loaded['labels'], loaded['original_labels']
                expected = np.where(original == 5, 0, np.where(np.isin(original, [1, 4, 7, 8]), 1, 2))
                assert np.array_equal(labels, expected), 'Legacy three-class label mapping changed'
                details['class_histogram'] = np.bincount(labels, minlength=3).tolist()
                details['official_class_histogram'] = np.bincount(original.astype(int), minlength=9).tolist()
                details['split_rows'] = {}
                for code in np.unique(group):
                    chosen = group == code
                    details['split_rows'][str(int(code))] = {
                        'records': int(chosen.sum()), 'optical_valid_records': int((chosen & optical_valid).sum()),
                        'class_histogram': np.bincount(labels[chosen], minlength=3).tolist(),
                        'all_row_ids_int64_sha256': hashlib.sha256(np.flatnonzero(chosen).astype(np.int64).tobytes()).hexdigest(),
                        'optical_valid_row_ids_int64_sha256': hashlib.sha256(np.flatnonzero(chosen & optical_valid).astype(np.int64).tobytes()).hexdigest(),
                    }
                if name == 'source_train':
                    train_max, val_min = float(xyz[group == 0, 0].max()), float(xyz[group == 1, 0].min())
                    details['spatial_guard'] = {'train_x_max': train_max, 'validation_x_min': val_min,
                                                'gap_m': val_min - train_max, 'embargo_split': 2}
                    assert val_min - train_max >= 5. - 1e-6
            else:
                source_indices = loaded['source_indices']
                assert len(np.unique(source_indices)) == len(source_indices)
                details['source_indices_sha256'] = hashlib.sha256(source_indices.tobytes()).hexdigest()
                original_path = Path('/nfs/home/yfeng21/lod2_pilot_20261017/data/lidar/roi_points.npz')
                with np.load(original_path) as raw:
                    assert np.array_equal(xyz, raw['points'][source_indices]), 'Target XYZ/source ID mismatch'
                details['original_lidar'] = file_receipt(original_path)
                details['xyz_exactly_equal_original_source_id_lookup'] = True
            print('Preparing', name, len(xyz), 'points', flush=True)
            indices, relative, valid, groups = neighborhoods(xyz, group, args.k, args.radius_m)
            output_path = data_dir / f'{name}_neighbors.npz'
            np.savez_compressed(output_path, indices=indices, relative_xyz=relative, valid=valid,
                                radius_m=np.float32(args.radius_m), k=np.int32(args.k))
            details['neighbor_groups'] = groups
            details['neighbors'] = file_receipt(output_path)
            manifest['datasets'][name] = {'features_npz': str(source_path),
                                           'neighbors_npz': str(output_path),
                                           'records': len(xyz), 'input_sha256': before['sha256'],
                                           'neighbor_sha256': details['neighbors']['sha256']}
            audit['datasets'][name] = details
            assert digest(source_path) == before['sha256'], 'Original NPZ was mutated'
            atomic_json(reports_dir / 'data_audit.json', audit)
            print('Finished', name, 'compressed bytes', output_path.stat().st_size, flush=True)
    buildings_path = SOURCE / 'target_buildings.json'
    buildings = json.loads(buildings_path.read_text())
    assert isinstance(buildings, list)
    with np.load(SOURCE / 'target.npz') as target:
        ids = target['source_indices']
        lookup = {int(identifier): position for position, identifier in enumerate(ids)}
        building_rows = []
        for entry in buildings:
            building_ids = np.asarray(entry['global_indices'], dtype=np.int64)
            rows = [lookup[int(identifier)] for identifier in building_ids]
            building_rows.append({'id': entry['id'], 'cohort': entry.get('cohort'),
                                  'target_rows': rows, 'source_indices': building_ids.tolist(),
                                  'focus': entry['id'].split('-')[-1] in FOCUS_OSM})
        union = np.unique(np.concatenate([np.asarray(x['source_indices']) for x in building_rows]))
        assert np.array_equal(union, np.sort(ids))
    target_buildings_path = data_dir / 'target_buildings.json'
    atomic_json(target_buildings_path, {'buildings': building_rows,
                'membership_policy': 'Global registered frozen candidate returns; original source IDs retained.',
                'input': file_receipt(buildings_path)})
    manifest['target_buildings'] = str(target_buildings_path)
    audit['target_buildings'] = {'count': len(building_rows),
                                 'focus_count': sum(row['focus'] for row in building_rows),
                                 'manifest': file_receipt(target_buildings_path)}
    assert audit['target_buildings']['focus_count'] == 8
    manifest_path = data_dir / 'prepared_manifest.json'
    atomic_json(manifest_path, manifest)
    audit['status'] = 'complete'
    audit['elapsed_seconds'] = time.time() - started
    audit['prepared_manifest'] = file_receipt(manifest_path)
    audit['finished_utc'] = datetime.now(timezone.utc).isoformat()
    audit['slurm_job_id'] = os.environ.get('SLURM_JOB_ID')
    audit['slurm_step_id'] = os.environ.get('SLURM_STEP_ID')
    atomic_json(reports_dir / 'data_audit.json', audit)
    print('Data audit complete:', manifest_path, 'seconds', audit['elapsed_seconds'], flush=True)


if __name__ == '__main__':
    main()
