#!/usr/bin/env python3
"""Independent post-freeze split, checkpoint and saved-prediction spatial audit."""
from __future__ import annotations
import datetime as dt
import hashlib
import json
from pathlib import Path
import numpy as np
from scipy.spatial import cKDTree

ROOT=Path('/lustre/isaac24/scratch/yfeng21/lod2_dl_round_20261026')
SPATIAL=ROOT/'spatial_validation'
SOURCE=Path('/nfs/home/yfeng21/lod2_tree_20261020/data/source_train.npz')


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        while block:=f.read(8*1024*1024): h.update(block)
    return h.hexdigest()


def array_sha(value):
    return hashlib.sha256(np.ascontiguousarray(value).tobytes()).hexdigest()


def main():
    summary=json.loads((SPATIAL/'reports/spatial_validation_summary.json').read_text())
    assert summary['status']=='complete'
    design_path=SPATIAL/'reports/spatial_design_freeze.json'
    design=json.loads(design_path.read_text())
    freeze_path=SPATIAL/'reports/all_fold_training_freeze.json'
    freeze=json.loads(freeze_path.read_text())
    assert summary['all_fold_training_freeze']['sha256']==sha(freeze_path)
    assert freeze['spatial_design_sha256']==sha(design_path)
    assert dt.datetime.fromisoformat(summary['evaluation_started_utc'])>=dt.datetime.fromisoformat(freeze['freeze_utc'])
    assert freeze['evaluation_scores_computed_before_freeze'] is False
    assert not freeze['source_test_opened'] and not freeze['target_opened']
    assert sha(SOURCE)==design['source']['sha256']
    expected={(f,m,s)for f in range(4)for m in design['methods']for s in design['seeds']}
    models={(m['fold'],m['method'],m['seed']):m for m in freeze['models']}
    assert set(models)==expected and len(freeze['models'])==48
    raw=np.load(SOURCE)
    xyz,labels,original=raw['xyz'],raw['labels'],raw['original_labels']
    fold_checks=[]
    for fold in range(4):
        directory=SPATIAL/'folds'/f'fold{fold}'
        rows=np.load(directory/'data/rows.npz')
        split=rows['split']
        parts=[rows[k]for k in ['training','calibration','evaluation']]
        for i in range(3):
            for j in range(i+1,3):
                assert np.intersect1d(parts[i],parts[j]).size==0
                distances=cKDTree(xyz[parts[i],:2]).query(xyz[parts[j],:2],k=1,workers=1)[0]
                assert distances.min()>=5-1e-6
        assert all(np.all(split[part]==code)for code,part in enumerate(parts))
        metadata=design['folds'][fold]
        assert array_sha(parts[0])==metadata['selected_train_ids_sha256']
        assert array_sha(parts[1])==metadata['selected_calibration_ids_sha256']
        normalization=np.load(directory/'data/normalization.npz')
        for key,computed in {
            'gm':raw['geometry'][parts[0]].mean(0),
            'gs':np.maximum(raw['geometry'][parts[0]].std(0),.03),
            'om':raw['optical'][parts[0]].mean(0),
            'os':np.maximum(raw['optical'][parts[0]].std(0),.03),
        }.items():
            assert np.array_equal(normalization[key],computed)
        neighbors=np.load(directory/'data/source_train_neighbors.npz')
        assert set(neighbors.files)=={'indices','relative_xyz','valid','k','radius_m'}
        idx=neighbors['indices']
        assert np.all(split[idx]==split[:,None])
        for method in design['methods']:
            for seed in design['seeds']:
                run=models[(fold,method,seed)]
                assert sha(run['checkpoint'])==run['checkpoint_sha256']
                assert run['train_ids_sha256']==metadata['selected_train_ids_sha256']
                assert run['validation_ids_sha256']==metadata['selected_calibration_ids_sha256']
                assert run['normalization_sha256']==sha(directory/'data/normalization.npz')
        fold_checks.append({'fold':fold,'ids_disjoint':True,'minimum_XY_gaps_at_least5m':True,
            'normalization_recomputed_from_training_only':True,'all_new_neighbor_pairs_same_split':True,
            'no_labels_in_new_neighbor_artifact':True,'all12_checkpoint_hashes_verified':True})
    scoring=[]
    for result in summary['results']:
        if 'method' not in result: continue
        fold,method,seed=result['fold'],result['method'],result['seed']
        model=models[(fold,method,seed)]
        prediction=np.load(result['evaluation_output']['path'])
        assert sha(result['evaluation_output']['path'])==result['evaluation_output']['sha256']
        ids=prediction['source_rows']
        keep=~prediction['reject']
        assert np.array_equal(ids,np.load(SPATIAL/'folds'/f'fold{fold}'/'data/rows.npz')['evaluation'])
        roof_retention=float(keep[labels[ids]==0].mean())
        tree_rejection=float((~keep)[original[ids]==8].mean())
        report=result['full_with_point_fallback']
        assert abs(report['roof_retention']-roof_retention)<1e-12
        assert abs(report['tree8_rejection']-tree_rejection)<1e-12
        threshold=np.full(len(ids),model['calibration_full']['threshold'])
        if method in {'fusion_mlp','context_fusion','gated_fusion'}:
            threshold[~prediction['optical_valid']]=models[(fold,'point_mlp',seed)]['calibration_full']['threshold']
        assert np.array_equal(prediction['probabilities'][:,1]>=threshold,~keep)
        scoring.append({'fold':fold,'method':method,'seed':seed,'roof_and_tree_metrics_recomputed':True,
                        'frozen_threshold_reject_exact':True})
    report={'status':'passed','recorded_utc':dt.datetime.now(dt.timezone.utc).isoformat(),
        'all48_checkpoint_hashes_verified':True,'all_fold_checkpoints_frozen_before_evaluation':True,
        'source_train_unchanged':True,'official_source_test_or_target_opened_by_this_audit':False,
        'fold_checks':fold_checks,'prediction_score_checks':scoring,'evaluated_run_count':len(scoring),
        'scope':'Independent split/normalization/neighborhood/checkpoint/saved prediction checks; four folds remain one historical source scene'}
    destination=ROOT/'reports/manager_spatial_audit.json'
    temporary=destination.with_suffix('.json.tmp')
    temporary.write_text(json.dumps(report,indent=2)+'\n')
    temporary.replace(destination)
    print(json.dumps({'status':'passed','models':48,'evaluated_run_count':len(scoring)}))


if __name__=='__main__': main()
