"""Summarize frozen results without ranking/selecting models on the test set."""
import hashlib
import json
from pathlib import Path
import numpy as np

ROOT = Path('/lustre/isaac24/scratch/yfeng21/lod2_dl_round_20261026')
SOURCE = Path('/nfs/home/yfeng21/lod2_tree_20261020/data')


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def save(name, data):
    path = ROOT / name
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(data, indent=2, allow_nan=False))
    temporary.replace(path)


def main():
    freeze = json.loads((ROOT / 'reports/training_freeze.json').read_text())
    final = json.loads((ROOT / 'reports/final_metrics.json').read_text())
    source = np.load(SOURCE / 'target.npz')
    checks = {
        'freeze_precedes_this_round_test_evaluation': freeze['freeze_utc'] < final['test_evaluation_started_utc'],
        'final_binds_freeze_sha256': final['training_freeze_sha256'] == sha(ROOT / 'reports/training_freeze.json'),
        'unchanged_source_train': freeze['config']['source_train_sha256'] == sha(SOURCE / 'source_train.npz'),
        'unchanged_source_test': final['source_test_sha256'] == sha(SOURCE / 'source_test.npz'),
        'unchanged_target': final['target_input_sha256'] == sha(SOURCE / 'target.npz'),
        'unchanged_training_script': freeze['config']['script_sha256'] == sha(Path(__file__).with_name('train_models.py')),
        'normalization_bound': freeze['train_only_normalization_sha256'] == sha(ROOT / 'data/normalization.npz'),
    }
    rows = np.load(ROOT / 'data/selected_rows.npz')
    checks['shared_train_rows'] = hashlib.sha256(rows['train_ids'].tobytes()).hexdigest() == freeze['train_ids_sha256']
    checks['shared_validation_rows'] = hashlib.sha256(rows['validation_ids'].tobytes()).hexdigest() == freeze['validation_ids_sha256']
    artifacts, summary = [], {}
    for run in freeze['models']:
        method, seed = run['method'], run['seed']
        path = ROOT / 'runs' / f'{method}_seed{seed}' / 'target_predictions.npz'
        data = np.load(path)
        assert run['checkpoint_sha256'] == sha(run['checkpoint'])
        assert np.array_equal(data['source_indices'], source['source_indices'])
        probabilities = data['probabilities']
        assert probabilities.shape == (len(source['source_indices']), 3)
        assert np.isfinite(probabilities).all() and (probabilities >= 0).all()
        assert np.max(np.abs(probabilities.sum(1) - 1)) < 1e-5
        available = data['optical_available']
        thresholds = np.full(len(available), float(data['native_threshold']))
        if method in {'fusion_mlp', 'context_fusion', 'gated_fusion'}:
            thresholds[~available] = float(data['fallback_threshold'])
        assert np.array_equal(data['reject'], probabilities[:, 1] >= thresholds)
        stored = final['target_diagnostics'][f'{method}_seed{seed}']['clean']
        assert stored['output_sha256'] == sha(path)
        artifacts.append({'method': method, 'seed': seed, 'path': str(path),
            'sha256': sha(path), 'records': len(available), 'rejected': int(data['reject'].sum()),
            'native_threshold': float(data['native_threshold']),
            'fallback_threshold': float(data['fallback_threshold'])})
    for method in freeze['config']['methods']:
        report = {}
        for scope in ['common_original_optical_coverage', 'full_scene_with_point_fallback']:
            measures = {}
            for metric in ['roof_retention', 'tree8_rejection', 'fence_hedge4_rejection',
                           'vegetation_or_fence_hedge_rejection', 'mean_iou', 'accuracy']:
                values = [final['official_source_reference'][f'{method}_seed{seed}']['clean'][scope][metric]
                          for seed in freeze['config']['seeds']]
                measures[metric] = {'mean': float(np.mean(values)), 'seed_std': float(np.std(values)), 'values': values}
            report[scope] = measures
        report['fixed_seed_deployment'] = next(x for x in artifacts if x['method'] == method and x['seed'] == 20261026)
        summary[method] = report
    checks['all_checkpoints_and_target_artifacts_bound'] = len(artifacts) == len(freeze['models']) == 18
    assert all(checks.values()), checks
    save('reports/training_audit.json', {'status': 'passed', 'checks': checks, 'artifact_count': len(artifacts),
        'source_test_historically_evaluated': True, 'target_has_independent_GT': False,
        'source_test_was_not_used_for_checkpoint_or_threshold_selection_this_round': True})
    save('data/target_prediction_manifest.json', {'schema': {'source_indices': 'N int64 original 3DEP return ID',
        'probabilities': 'N x 3 float32: roof, vegetation_or_fence_hedge, other',
        'reject': 'N bool, source-validation-calibrated decisions; do not recalibrate on target',
        'native_threshold': 'scalar float', 'fallback_threshold': 'scalar float, point_mlp same seed',
        'optical_available': 'N bool', 'gate': 'N float32; learned only in gated_fusion'},
        'fixed_reconstruction_seed': 20261026, 'artifacts': artifacts})
    save('reports/method_summary.json', {'methods': summary,
        'statistics': 'mean and population standard deviation across 3 fixed random seeds; not geographic confidence intervals',
        'no_model_selected_from_source_test_or_target': True,
        'interpretation': ['Point descriptors plus optical features substantially improve source tree rejection at high roof retention.',
            'The gated module has a small mean gain over matched context_fusion, within seed variability; no demonstrated gate benefit.',
            'Clean/shift gate means are nearly unchanged, so actual observation reliability has not been demonstrated.',
            'A validation roof-retention constraint of 99.5 percent does not guarantee that retention on the spatially distinct reference test.',
            'The official source test was already evaluated in earlier work. This round freezes all model decisions before reading it.',
            'DC point removal counts are diagnostics and do not establish tree-removal or roof accuracy.']})
    print('Training audit passed; 18 target files bound to immutable source IDs.')


if __name__ == '__main__':
    main()
