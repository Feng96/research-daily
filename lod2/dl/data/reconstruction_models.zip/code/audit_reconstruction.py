#!/usr/bin/env python3
"""Independent identity/membership audit for the completed24x8 reconstruction."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import numpy as np

ROOT = Path('/lustre/isaac24/scratch/yfeng21/lod2_dl_round_20261026')
HOME = Path('/nfs/home/yfeng21')
RUN = ROOT/'runs/reconstruction24_v1'
ALIASES = {'linear':'linear', 'point':'point_mlp', 'fusion':'fusion_mlp',
           'context':'local_context', 'context_fusion':'context_fusion', 'gated':'gated_fusion'}


def sha(value):
    return hashlib.sha256(np.ascontiguousarray(value).tobytes()).hexdigest()


def file_sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    completion = json.loads((RUN/'completion.json').read_text())
    target = np.load(HOME/'lod2_tree_20261020/data/target.npz')
    raw = np.load(HOME/'lod2_pilot_20261017/data/lidar/roi_points.npz')
    target_ids, target_xyz = target['source_indices'], target['xyz']
    assert np.array_equal(target_xyz, raw['points'][target_ids])
    seed = completion['recipe']['seed']
    predictions = {}
    for short, method in ALIASES.items():
        path = ROOT/'runs'/f'{method}_seed{seed}'/'target_predictions.npz'
        data = np.load(path)
        assert np.array_equal(data['source_indices'], target_ids)
        predictions[short] = data['reject']
    checks, failed_shells, reused, exact_legacy, extended_legacy = [], [], 0, 0, 0
    for building in completion['buildings']:
        identity = building['id']
        directory = RUN/'buildings'/identity
        data = np.load(directory/'decisions.npz')
        ids, xyz = data['source_indices'], data['original_XYZ']
        rows = np.searchsorted(target_ids, ids)
        assert np.array_equal(target_ids[rows], ids)
        assert np.array_equal(xyz, target_xyz[rows])
        native_by_mask = {}
        common_ground, common_footprint = set(), set()
        for method in completion['methods']:
            result = building['methods'][method]
            keep = data[method+'_keep']
            arm = directory/method
            arm_data = np.load(arm/'decisions.npz')
            assert np.array_equal(arm_data['source_indices'], ids)
            assert np.array_equal(arm_data['original_XYZ'], xyz)
            assert np.array_equal(arm_data['keep'], keep)
            assert np.array_equal(arm_data['reject'], ~keep)
            assert np.array_equal(arm_data['selected_source_indices'], ids[keep])
            assert result['original_XYZ_sha256'] == sha(xyz)
            assert result['source_indices_sha256'] == sha(ids)
            assert result['selected_source_indices_sha256'] == sha(ids[keep])
            assert result['keep_sha256'] == sha(keep)
            assert result['removed_points'] == int((~keep).sum())
            assert result['kept_points'] == int(keep.sum())
            if method == 'raw':
                assert keep.all()
            elif method in ALIASES:
                assert np.array_equal(~keep, predictions[method][rows])
            else:
                old = Path('/lustre/isaac24/scratch/yfeng21/lod2_canopy_20261022/runs/probe8_v1/buildings')/identity/'decisions.npz'
                if old.exists():
                    assert np.array_equal(keep, np.load(old)['guarded_keep'])
                    assert result['provenance']['rule_extension'] is False
                    exact_legacy += 1
                else:
                    assert result['provenance']['rule_extension'] is True
                    assert result['provenance']['new_calibration'] is False
                    extended_legacy += 1
            model_path = arm/'initial/models.json'
            assert file_sha(model_path) == result['model_sha256']
            receipt = json.loads((arm/'initial/receipt.json').read_text())
            assert file_sha(model_path) == receipt['model_sha256']
            model = json.loads(model_path.read_text())['buildings'][0]
            assert sum(s['type']=='RoofSurface' for s in model['surfaces']) == result['roof_surfaces']
            key = result['selected_source_indices_sha256']
            if key in native_by_mask:
                assert native_by_mask[key] == result['model_sha256']
            native_by_mask[key] = result['model_sha256']
            reused += int(result['same_mask_native_execution_reused'])
            common_ground.add(result['ground_sha256'])
            common_footprint.add(result['footprint_sha256'])
            assert result['raw_substituted'] is False
            assert result['post_trim_points'] == 0
            if not result['shell_diagnostic']:
                failed_shells.append({'id':identity, 'method':method,
                    'boundary_edges':result['boundary_edges'], 'nonmanifold_edges':result['nonmanifold_edges'],
                    'model_preserved':True})
            checks.append({'id':identity,'method':method,'immutable_XYZ_and_source_IDs':True,
                           'exact_frozen_decisions':True, 'model_hash_verified':True})
        assert len(common_ground) == len(common_footprint) == 1
    assert len(checks) == completion['completed_cases'] == completion['planned_cases'] == 192
    assert len(completion['buildings']) == 24
    assert exact_legacy == 8 and extended_legacy == 16
    report = {'status':'passed','checks':checks,'case_count':len(checks),
        'same_mask_exact_model_reuses':reused,'legacy8_masks_exact':exact_legacy,
        'legacy16_frozen_rule_extensions':extended_legacy,'shell_failures_preserved':failed_shells,
        'raw_substitution_count':0,'source_xyz_exact_raw_returns':True,
        'completion_sha256':file_sha(RUN/'completion.json'),
        'scope':'Identity, frozen decisions, matched inputs and artifact provenance; no target roof accuracy or certified solid validation'}
    path = ROOT/'reports/manager_reconstruction_audit.json'
    temporary = path.with_suffix('.json.tmp')
    temporary.write_text(json.dumps(report,indent=2)+'\n')
    temporary.replace(path)
    print(json.dumps({k:report[k]for k in ['status','case_count','same_mask_exact_model_reuses','shell_failures_preserved']}))


if __name__ == '__main__':
    main()
