"""Validate a non-destructive, prefix-scoped Pages release against a fresh head."""
from pathlib import Path
from html.parser import HTMLParser
import hashlib,importlib.util,json,os,subprocess,time,urllib.parse

R=Path('/lustre/isaac24/scratch/yfeng21/lod2_dl_round_20261026');P=R/'public'
S=Path('/nfs/home/yfeng21/lod2_paper_compare_20261022/tools/verify_release.py')
spec=importlib.util.spec_from_file_location('known_git_tree_verifier',S);helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)

def get(path):
    return json.loads(subprocess.check_output(['curl','-4','--fail','--silent','--show-error','--max-time','40','https://api.github.com/repos/Feng96/research-daily'+path]))
def obj(data):return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
class Links(HTMLParser):
    def __init__(self):super().__init__();self.urls=[];self.base='./'
    def handle_starttag(self,tag,attrs):
        if tag=='base':self.base=dict(attrs).get('href','./')
        for k,v in attrs:
            if k in ['src','href'] and v:self.urls.append(v)

def main():
    initial=R/'reports/publication_inventory.json'
    previous=json.loads(initial.read_text()) if initial.exists() else None
    head=get('/commits/main?lod2release='+str(time.time_ns()));tree=get('/git/trees/'+head['commit']['tree']['sha']+'?recursive=1');assert not tree['truncated']
    leaves={x['path']:(x['mode'],x['sha']) for x in tree['tree'] if x['type']!='tree'}
    assert helper.tree_sha(leaves)==head['commit']['tree']['sha']
    previous_leaves={x['path']:x['sha'] for x in previous.get('existing_tree',[]) if x['type']!='tree'} if previous else {}
    for path,(_,sha) in leaves.items():
        if path.startswith('lod2/'):
            assert (P/path[5:]).is_file(),'Missing linked historical asset: '+path
            if path in previous_leaves and previous_leaves[path]!=sha:
                assert obj((P/path[5:]).read_bytes())==sha,'Concurrent LoD2 edit requires merge: '+path
    changes=[];unchanged=0;checked=0
    for base,dirs,files in os.walk(P,followlinks=True):
        for name in files:
            file=Path(base)/name;path='lod2/'+file.relative_to(P).as_posix();b=file.read_bytes();sha=obj(b)
            if leaves.get(path,('',None))[1]==sha:unchanged+=1;continue
            if path in leaves:assert path.endswith('.html') or path in ['lod2/site-nav.js','lod2/viewer/app.js','lod2/viewer/point_clouds.js'],path
            else:assert path.startswith('lod2/dl/'),path
            changes.append({'path':path,'file':str(file),'sha':sha,'bytes':len(b)});leaves[path]=('100644',sha)
            if name.endswith('.html'):
                links=Links();links.feed(b.decode())
                for url in links.urls:
                    u=urllib.parse.urlparse(url)
                    if u.scheme or u.netloc or not u.path or u.path.startswith('/'):continue
                    target=Path(os.path.normpath(file.parent/links.base/urllib.parse.unquote(u.path)))
                    if not target.is_relative_to(P):continue
                    if target.is_dir():target=target/'index.html'
                    assert target.is_file(),str(file)+': '+url;checked+=1
    report={'parent_sha':head['sha'],'base_tree_sha':head['commit']['tree']['sha'],'expected_tree_sha':helper.tree_sha(leaves),
        'changes':changes,'unchanged_lod2_files':unchanged,'existing_tree':tree['tree'],'outside_lod2_prefix_unchanged':True,'static_links_checked':checked}
    initial.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ['existing_tree','changes']}|{'changed_files':len(changes),'changed_bytes':sum(x['bytes']for x in changes)}))

if __name__=='__main__':main()
