"""Stage the new chapter on Lustre; preserve all historical datasets by links."""
from pathlib import Path
import os, re, shutil, json

H=Path('/nfs/home/yfeng21')
R=Path('/lustre/isaac24/scratch/yfeng21/lod2_dl_round_20261026')
A=H/'lod2_experiment_atlas/public'
P=R/'public'
CODE=Path(__file__).parent
VERSION='20261026-dl'

def materialize(p):
    if p.is_symlink():
        src=p.resolve();p.unlink();p.mkdir()
        for c in src.iterdir():(p/c.name).symlink_to(c,target_is_directory=c.is_dir())

def main():
    # A copied symlink stays a link; it does not copy input/result trees into HOME.
    if not (P/'index.html').exists():shutil.copytree(A,P,symlinks=True,dirs_exist_ok=True)
    for base,dirs,files in os.walk(A,followlinks=True):
        for f in files:
            if not f.endswith('.html'):continue
            src=Path(base)/f;rel=src.relative_to(A);node=P
            for part in rel.parts[:-1]:node=node/part;materialize(node)
            target=P/rel
            if target.is_symlink():target.unlink()
            text=src.read_text()
            text=re.sub(r'(data-lod2-site-nav src="[^"]*site-nav.js)\?[^" ]*',r'\1?v='+VERSION,text)
            target.write_text(text)
    (P/'dl').mkdir(exist_ok=True)
    for src,dest in [('dl.html','index.html'),('dl.js','dl.js'),('dl.css','dl.css')]:shutil.copy2(CODE/src,P/'dl'/dest)
    s=(A/'index.html').read_text().replace('href="./paper/" data-experiment="paper">最新：论文思想配对对照 →','href="./dl/" data-experiment="dl">最新：邻域与光学可靠性 →')
    s=s.replace('<div class="experiment-grid"><article><p class="tag">美国 · 8 栋 / 三组对照</p>', '<div class="experiment-grid"><article class="featured"><p class="tag">新实验 · 6 模型 × 3 种子 / 美国 24 栋</p><h3>邻域与光学可靠性</h3><p>带标签源域验证树木剔除与屋顶保留；美国 120 栋推理、24 栋同输入重建。保留门控无明显增益的结果。</p><a class="primary" href="./dl/" data-experiment="dl">结果 · 方法 · 影像＋点云＋屋面 →</a></article><article><p class="tag">美国 · 8 栋 / 三组对照</p>')
    s=s.replace('20261022-paper-v1',VERSION);(P/'index.html').write_text(s)
    s=(A/'site-nav.js').read_text().replace('const registry={',"const registry={dl:['邻域与光学可靠性','dl/','filter'],")
    s=s.replace("if(p.startsWith('paper/'))return 'paper';","if(p.startsWith('dl/'))return 'dl';if(p.startsWith('paper/'))return 'paper';")
    s=s.replace("if(chapter==='paper'){","if(chapter==='dl'){target.search=state.toString();target.hash='visual'}else if(chapter==='paper'){")
    (P/'site-nav.js').write_text(s)
    s=(A/'viewer/app.js').read_text().replace('20261022-paper-v1',VERSION).replace("paper:'initial'","paper:'initial',dl:'raw'")
    s=s.replace("fetch(chapter==='paper'?","fetch(chapter==='dl'?'../dl/data/viewer.json.gz':chapter==='paper'?")
    s=s.replace("paper:'论文思想 · 同输入配对对照'","paper:'论文思想 · 同输入配对对照',dl:'邻域与光学可靠性 · 24 栋'")
    s=s.replace("$('selected-height').textContent=chapter==='paper'?","$('selected-height').textContent=chapter==='dl'?'同一原始观测 · 固定几何后端 · 无本地GT':chapter==='paper'?")
    branch="""
  if(chapter==='dl'){
    const row=selected.dl;$('metric-note').textContent='筛点与重建诊断；删点和边检查不代表真实屋顶精度。青色保留、红色删除。';
    $('metrics').replaceChildren(...GROUPS.map(key=>{const m=row.methods[key],button=document.createElement('button');button.className='metric'+(key===group?' active':'');button.setAttribute('aria-pressed',String(key===group));for(const [cls,text]of [['metric-name',LABELS[key]],['metric-value','删 '+m.removed_points+' 点'],['metric-sub',m.roof_surfaces+' 片屋面 · '+(m.shell_diagnostic?'边检查通过':'边检查未通过')]]){const span=document.createElement('span');span.className=cls;span.textContent=text;button.append(span)}button.onclick=()=>setGroup(key);return button}));reportHeight();return;
  }
"""
    s=s.replace('function renderMetrics(){','function renderMetrics(){'+branch)
    s=s.replace("if(chapter==='paper'){$('chapter-detail')","if(chapter==='dl'){$('chapter-detail').textContent='24 栋 · 8 种筛点策略 · 新模型固定种子20261026 · 无本地GT';$('metric-mode').closest('label').hidden=true;document.querySelector('label[for=cohort]').hidden=true;}\n    if(chapter==='paper'){$('chapter-detail')")
    (P/'viewer/app.js').write_text(s)
    s=(A/'viewer/point_clouds.js').read_text()
    s=s.replace("'tree','workflow','canopy','repair','paper'","'tree','workflow','canopy','repair','paper','dl'").replace("'workflow','canopy','repair','paper'","'workflow','canopy','repair','paper','dl'").replace("'canopy','repair','paper'","'canopy','repair','paper','dl'")
    while "'dl','dl'" in s:s=s.replace("'dl','dl'","'dl'")
    s=s.replace("fetch((chapter==='paper'?", "fetch((chapter==='dl'?'../data/points/':chapter==='paper'?")
    # Fetch immutable old observed coordinates, then overlay this round's exact
    # source-index-based decisions/scores. No measured XYZ are duplicated.
    needle='const data=JSON.parse(text);'
    merge="""const data=JSON.parse(text);if(chapter==='dl'){
      const response=await fetch('../dl/data/points/'+encodeURIComponent(b.id)+'.json.gz');if(!response.ok)throw Error('DL decisions HTTP '+response.status);const bytes=new Uint8Array(await response.arrayBuffer());const overlay=JSON.parse(await new Response(new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'))).text());
      if(overlay.id!==data.id||overlay.sourceIndices.length!==data.flags.length)throw Error('DL source index length mismatch');data.sourceIndices=overlay.sourceIndices;data.trainSets=overlay.trainSets;data.groupToTrainSet=overlay.groupToTrainSet;data.groupToScoreModel=overlay.groupToScoreModel;data.tests={dl:[]};data.metadata.trainMemberships=overlay.trainMemberships;data.metadata.testMemberships={dl:{sourceRecordCount:0}};data.decisionMasks={};data.semanticScores={};for(const [method,values]of Object.entries(overlay.vegetation_scores)){const scores=new Float32Array(data.flags.length);scores.fill(-1);for(let i=0;i<values.length;i++)scores[overlay.candidateLocalIndices[i]]=values[i];data.semanticScores[method]=scores;}
    }"""
    assert needle in s;s=s.replace(needle,merge)
    s=s.replace("({point:'点云',image:'光学',fusion:'融合'}[scoreKind]+'模型", "(({point:'点云',image:'光学',fusion:'融合'}[scoreKind]||scoreKind)+'模型")
    (P/'viewer/point_clouds.js').write_text(s)
    p=P/'viewer/index.html';p.write_text(p.read_text().replace('20261022-paper-v1',VERSION))
    print(json.dumps({'public':str(P),'new_chapter':'dl','historical_data_linked':True}))

if __name__=='__main__':main()
