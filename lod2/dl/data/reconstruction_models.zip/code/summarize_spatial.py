"""Audit spatial stage artifacts and export compact website aggregates."""
import hashlib
import json
from pathlib import Path
import numpy as np

BASE = Path('/lustre/isaac24/scratch/yfeng21/lod2_dl_round_20261026')
ROOT = BASE / 'spatial_validation'


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def write(path, value):
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False))
    temporary.replace(path)


def stats(values):
    return {'mean': float(np.mean(values)), 'std': float(np.std(values)),
            'min': float(np.min(values)), 'max': float(np.max(values)), 'count': len(values)} if values else None


def main():
    summary = json.loads((ROOT / 'reports/spatial_validation_summary.json').read_text())
    design = json.loads((ROOT / 'reports/spatial_design_freeze.json').read_text())
    frozen = json.loads((ROOT / 'reports/all_fold_training_freeze.json').read_text())
    assert summary['status'] == 'complete'
    checks = {'all_48_models_frozen_before_evaluation': len(frozen['models']) == 48
        and frozen['freeze_utc'] < summary['evaluation_started_utc'],
        'source_train_unchanged': design['source']['sha256'] == sha(design['source']['path']),
        'frozen_components_unchanged': all(design[key]['sha256'] == sha(design[key]['path'])
            for key in ['spatial_script', 'frozen_training_component', 'frozen_neighbor_component']),
        'design_hash_bound': frozen['spatial_design_sha256'] == sha(ROOT / 'reports/spatial_design_freeze.json'),
        'official_test_and_target_not_used': not summary['source_test_opened'] and not summary['target_opened']}
    checkpoints = {(row['fold'], row['method'], row['seed']): row for row in frozen['models']}
    outcomes = [row for row in summary['results'] if 'method' in row]
    evaluated_artifacts = []
    for row in outcomes:
        key = (row['fold'], row['method'], row['seed'])
        checkpoint = checkpoints[key]
        assert checkpoint['checkpoint_sha256'] == sha(checkpoint['checkpoint'])
        assert checkpoint['calibration_common']['validation_roof_retention'] >= .995
        assert checkpoint['calibration_full']['validation_roof_retention'] >= .995
        fold_root = ROOT / 'folds' / f"fold{row['fold']}"
        selected = np.load(fold_root / 'data/rows.npz')
        assert not np.intersect1d(selected['training'], selected['calibration']).size
        assert not np.intersect1d(selected['training'], selected['evaluation']).size
        assert not np.intersect1d(selected['calibration_full'], selected['evaluation']).size
        assert checkpoint['train_ids_sha256'] == hashlib.sha256(selected['training'].tobytes()).hexdigest()
        assert checkpoint['validation_ids_sha256'] == hashlib.sha256(selected['calibration'].tobytes()).hexdigest()
        assert checkpoint['normalization_sha256'] == sha(fold_root / 'data/normalization.npz')
        artifact = row['evaluation_output']
        assert artifact['sha256'] == sha(artifact['path'])
        data = np.load(artifact['path'])
        assert np.array_equal(data['source_rows'], selected['evaluation'])
        probabilities = data['probabilities']
        assert np.isfinite(probabilities).all() and (probabilities >= 0).all()
        assert np.max(np.abs(probabilities.sum(1) - 1)) < 1e-5
        thresholds = np.full(len(probabilities), checkpoint['calibration_full']['threshold'])
        if row['method'] in {'fusion_mlp', 'context_fusion', 'gated_fusion'}:
            point = checkpoints[(row['fold'], 'point_mlp', row['seed'])]
            thresholds[~data['optical_valid']] = point['calibration_full']['threshold']
        assert np.array_equal(data['reject'], probabilities[:, 1] >= thresholds)
        evaluated_artifacts.append(artifact)
    checks['checkpoints_calibration_and_evaluation_artifacts_bound'] = len(evaluated_artifacts) == len(outcomes)
    checks['all_fold_spatial_gaps_at_least_5m'] = all(min(row['minimum_xy_gaps_m'].values()) >= 5. - 1e-6 for row in design['folds'])
    assert all(checks.values()), checks
    methods = design['methods']
    scopes = ['common_optical', 'full_with_point_fallback']
    metrics = ['roof_retention', 'tree8_rejection', 'mean_iou']
    per_method = {}
    for method in methods:
        chosen = [row for row in outcomes if row['method'] == method]
        per_method[method] = {scope: {metric: stats([row[scope][metric] for row in chosen])
            for metric in metrics} for scope in scopes}
        per_method[method]['below_calibrated_retention_target_count'] = sum(
            row['full_with_point_fallback']['roof_retention'] < .995 for row in chosen)
    per_fold = []
    for fold in design['folds']:
        output = {key: fold[key] for key in ['fold', 'training_rows', 'calibration_rows',
            'calibration_roof_records', 'evaluation_rows', 'minimum_xy_gaps_m']}
        output['methods'] = {}
        for method in methods:
            chosen = [row for row in outcomes if row['fold'] == fold['fold'] and row['method'] == method]
            output['methods'][method] = {scope: {metric: stats([row[scope][metric] for row in chosen])
                for metric in metrics} for scope in scopes}
        per_fold.append(output)
    web = {'schema_version': 1, 'status': 'complete', 'models': len(frozen['models']),
        'evaluated_fold_seed_cases': len(outcomes), 'perMethod': per_method, 'perFold': per_fold,
        'pairedGateMinusContext': summary['paired_gate_minus_context_fusion'],
        'source_test_opened': False, 'target_opened': False,
        'all_models_frozen_utc': frozen['freeze_utc'], 'evaluation_started_utc': summary['evaluation_started_utc'],
        'CI_limit': 'Pointwise binomial intervals ignore spatially correlated roof/tree returns; four folds of one scene are not four independent cities.',
        'legacy_geometry_context': 'Old geometric descriptors use fullscene unlabeled XYZ; new learned neighborhoods and normalization are fold-local.',
        'historical_scene_reuse': 'A new spatial split of a previously used scene, not newly acquired blind validation data.',
        'summary_sha256': sha(ROOT / 'reports/spatial_validation_summary.json')}
    audit = {'status': 'passed', 'checks': checks, 'model_count': len(frozen['models']),
             'evaluation_artifact_count': len(evaluated_artifacts)}
    write(ROOT / 'reports/spatial_audit.json', audit)
    write(BASE / 'reports/spatial_audit.json', audit)
    write(ROOT / 'reports/spatial_web_summary.json', web)
    write(BASE / 'reports/spatial_web_summary.json', web)
    print('Spatial validation audit passed; website aggregates exported.')


if __name__ == '__main__':
    main()
