#!/usr/bin/env python3
"""Audit this round's frozen training receipts without importing torch or labels."""
from __future__ import annotations
import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path

ROOT = Path('/lustre/isaac24/scratch/yfeng21/lod2_dl_round_20261026')


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        while data := f.read(4*1024*1024):
            h.update(data)
    return h.hexdigest()


def audit(root):
    checks = {}
    freeze_path = root/'reports/training_freeze.json'
    if not freeze_path.exists():
        return {'status': 'awaiting_training_freeze', 'checks': {}, 'errors': []}
    freeze = json.loads(freeze_path.read_text())
    config = freeze['config']
    models = freeze['models']
    expected = {(m, s) for m in config['methods'] for s in config['seeds']}
    pairs = [(m['method'], m['seed']) for m in models]
    checks['all_method_seed_pairs_once'] = set(pairs) == expected and len(pairs) == len(expected)
    checks['source_test_history_disclosed'] = freeze.get('source_test_historically_evaluated') is True
    checks['trainer_test_label_reads_after_freeze'] = freeze.get('official_test_read_in_this_run_before_freeze') is False
    checks['train_only_normalization_declared'] = config.get('train_only_normalization') is True
    checks['test_not_used_for_training_selection'] = config.get('test_used_for_training_selection') is False
    checks['neighborhood_labels_excluded'] = config.get('context', {}).get('labels_in_features') is False
    checks['new_neighborhoods_split_local'] = config.get('context', {}).get('new_neighbors_cross_split') is False
    checks['shared_optical_bands_correct'] = config.get('optical_bands') == ['Red', 'Green', 'NIR']
    checks['normalization_bytes_match'] = sha(root/'data/normalization.npz') == freeze['train_only_normalization_sha256']
    by_model = {}
    for model in models:
        name = f"{model['method']}_seed{model['seed']}"
        cp = Path(model['checkpoint'])
        entry = {
            'checkpoint_under_lustre_round': str(cp.resolve()).startswith(str(root.resolve())+'/'),
            'checkpoint_bytes_match': cp.exists() and sha(cp) == model['checkpoint_sha256'],
            'same_train_ids': model['train_ids_sha256'] == freeze['train_ids_sha256'],
            'same_validation_ids': model['validation_ids_sha256'] == freeze['validation_ids_sha256'],
            'same_normalization': model['normalization_sha256'] == freeze['train_only_normalization_sha256'],
            'validation_retention_calibrated': all(model[key]['validation_roof_retention'] >= .995
                                                  for key in ['calibration_common', 'calibration_full']),
            'positive_temperatures': all(model[key]['temperature'] > 0 for key in ['calibration_common', 'calibration_full']),
        }
        if 'script_sha256' in model:
            entry['same_training_script'] = model['script_sha256'] == config['script_sha256']
        by_model[name] = entry
    checks['all_per_model_receipts_pass'] = all(all(v.values()) for v in by_model.values())
    final_path = root/'reports/final_metrics.json'
    final_evaluated = final_path.exists()
    if final_evaluated:
        final = json.loads(final_path.read_text())
        checks['metrics_bind_frozen_checkpoints'] = final['training_freeze_sha256'] == sha(freeze_path)
        checks['test_started_after_freeze'] = dt.datetime.fromisoformat(final['test_evaluation_started_utc']) >= dt.datetime.fromisoformat(freeze['freeze_utc'])
        checks['all_frozen_runs_evaluated'] = set(final['official_source_reference']) == set(by_model)
        checks['no_target_semantic_accuracy_claim'] = final.get('target_semantic_accuracy_available') is False
        checks['all_target_runs_reported'] = set(final['target_diagnostics']) == set(by_model)
        metrics = final['official_source_reference']
        checks['pure_tree_and_mixed_hedge_reported_separately'] = all(
            all(key in value['clean']['full_scene_with_point_fallback'] for key in ['tree8_rejection', 'fence_hedge4_rejection', 'roof_retention'])
            for value in metrics.values())
    errors = [key for key, passed in checks.items() if not passed]
    return {'status': 'training_receipts_passed' if not errors else 'training_receipts_failed',
            'reviewed_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
            'checks': checks, 'per_model_checks': by_model, 'errors': errors,
            'final_evaluated': final_evaluated, 'training_freeze_sha256': sha(freeze_path),
            'scope': 'Receipt consistency; code audit separately documents calibration/fallback and context limitations'}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root', type=Path, default=ROOT)
    args = ap.parse_args()
    result = audit(args.root)
    path = args.root/'reports/manager_training_audit.json'
    tmp = path.with_suffix('.json.tmp')
    tmp.write_text(json.dumps(result, indent=2)+'\n')
    tmp.replace(path)
    print(json.dumps({'status': result['status'], 'errors': result['errors']}))
    return 1 if result['errors'] else 0


if __name__ == '__main__':
    raise SystemExit(main())
