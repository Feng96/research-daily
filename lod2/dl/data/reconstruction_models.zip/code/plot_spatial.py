"""Standalone figures for the completed source-only spatial validation."""
import os
os.environ.setdefault('MPLCONFIGDIR', '/lustre/isaac24/scratch/yfeng21/lod2_dl_round_20261026/cache/matplotlib')
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

ROOT = Path('/lustre/isaac24/scratch/yfeng21/lod2_dl_round_20261026')
SPATIAL = ROOT / 'spatial_validation'


def main():
    summary = json.loads((SPATIAL / 'reports/spatial_validation_summary.json').read_text())
    xyz = np.load('/nfs/home/yfeng21/lod2_tree_20261020/data/source_train.npz')['xyz']
    origin = xyz[:, :2].min(0)
    xy = xyz[:, :2] - origin
    indices = np.random.default_rng(20261026).choice(len(xy), min(45000, len(xy)), replace=False)
    colors = ['#0072B2', '#E69F00', '#009E73', '#B8B8B8']
    labels = ['Training', 'Calibration: early stopping + threshold', 'Evaluation: scored after all models freeze', 'Embargo / excluded']
    plt.rcParams.update({'font.size': 10, 'axes.spines.top': False, 'axes.spines.right': False})
    fig, axes = plt.subplots(2, 2, figsize=(11, 9), sharex=True, sharey=True)
    extent = [float(xy[:, 0].max()), float(xy[:, 1].max())]
    for fold, ax in enumerate(axes.flat):
        rows = np.load(SPATIAL / 'folds' / f'fold{fold}' / 'data/rows.npz')
        group = rows['split'][indices]
        for code in [3, 0, 1, 2]:
            selected = indices[group == code]
            ax.scatter(xy[selected, 0], xy[selected, 1], s=1, color=colors[code], alpha=.75,
                       rasterized=True, linewidths=0)
        metadata = summary['folds'][fold]
        ax.set_title(f"Fold {fold}: calibration roofs n={metadata['calibration_roof_records']:,}")
        ax.set_xlim(-5, extent[0] + 5)
        ax.set_ylim(-5, extent[1] + 5)
        ax.set_aspect('equal', adjustable='box')
        ax.set_xlabel('Local easting (m)')
        ax.set_ylabel('Local northing (m)')
        ax.grid(alpha=.15)
    legend = [Line2D([0], [0], color=color, marker='o', linestyle='', markersize=6, label=label)
              for color, label in zip(colors, labels)]
    fig.legend(handles=legend, loc='lower center', bbox_to_anchor=(.5, .035), ncol=2, frameon=False)
    fig.suptitle('Four spatial re-holdouts within one previously used source scene', fontsize=14)
    fig.text(.5, .015, '5 m XY separation between train / calibration / evaluation. These are four folds of one scene, not four cities.',
             ha='center', fontsize=9)
    fig.tight_layout(rect=(0, .12, 1, .96))
    fig.savefig(ROOT / 'reports/spatial_folds.png', dpi=180)
    fig.savefig(ROOT / 'reports/spatial_folds.pdf')
    plt.close(fig)

    methods = ['point_mlp', 'fusion_mlp', 'context_fusion', 'gated_fusion']
    names = ['Point MLP', 'Simple optical + point fusion', 'Neighborhood + optical fusion', 'Gated neighborhood + optical fusion']
    method_colors = ['#0072B2', '#E69F00', '#009E73', '#CC79A7']
    markers = ['o', 's', '^', 'D']
    fig, ax = plt.subplots(figsize=(11, 7))
    results = [row for row in summary['results'] if 'method' in row]
    scope = 'full_with_point_fallback'
    for method, color in zip(methods, method_colors):
        for fold in range(4):
            rows = [row for row in results if row['method'] == method and row['fold'] == fold]
            xx = np.array([row[scope]['roof_retention'] * 100 for row in rows])
            yy = np.array([row[scope]['tree8_rejection'] * 100 for row in rows])
            ax.scatter(xx, yy, color=color, marker=markers[fold], alpha=.22, s=25, linewidths=0)
            ax.errorbar(xx.mean(), yy.mean(), xerr=xx.std(), yerr=yy.std(), color=color,
                        marker=markers[fold], markersize=8, linestyle='', capsize=3, elinewidth=1)
    ax.axvline(99.5, color='#6B7280', linestyle='--', linewidth=1)
    ax.set_xlabel('Retained roof-labelled returns (%)')
    ax.set_ylabel('Rejected tree-labelled returns (%)')
    ax.set_title('Source spatial evaluation: greater tree rejection can also remove true roof points', fontsize=12)
    ax.set_ylim(20, 102)
    ax.set_xlim(min(row[scope]['roof_retention'] * 100 for row in results) - .35, 100.1)
    ax.grid(alpha=.2)
    method_legend = [Line2D([0], [0], color=color, marker='o', linestyle='', markersize=7, label=name)
                     for color, name in zip(method_colors, names)]
    first = ax.legend(handles=method_legend, loc='lower left', frameon=False, fontsize=9)
    ax.add_artist(first)
    folds_legend = [Line2D([0], [0], color='#374151', marker=marker, linestyle='', markersize=6, label=f'Fold {fold}')
                   for fold, marker in enumerate(markers)]
    ax.legend(handles=folds_legend, loc='center left', bbox_to_anchor=(0, .35), frameon=False, fontsize=9)
    fig.text(.5, .02, 'Large markers: fold means across 3 seeds. Error bars: seed SD; faint points: individual runs.\n'
             'Dashed line: 99.5% calibration target, which is not guaranteed on spatial evaluation.\n'
             'One source scene; old geometric descriptors retain full-scene unlabeled XYZ context. These are point-label metrics, not LoD2 accuracy.',
             ha='center', fontsize=9)
    fig.tight_layout(rect=(0, .1, 1, 1))
    fig.savefig(ROOT / 'reports/spatial_tradeoff.png', dpi=180)
    fig.savefig(ROOT / 'reports/spatial_tradeoff.pdf')
    plt.close(fig)
    print('Saved spatial_folds.png/pdf and spatial_tradeoff.png/pdf.')


if __name__ == '__main__':
    main()
