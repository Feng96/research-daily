"""Bounded, source-supervised point semantic experiments; no roof completion.

No official-test labels are opened until every checkpoint/calibration is frozen.
The historically evaluated official test is a reference, not a new blind test.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import torch
from torch import nn

SOURCE = Path('/nfs/home/yfeng21/lod2_tree_20261020/data')
DEFAULT_ROOT = Path('/lustre/isaac24/scratch/yfeng21/lod2_dl_round_20261026')
METHODS = ['linear', 'point_mlp', 'fusion_mlp', 'local_context', 'context_fusion', 'gated_fusion']
SEEDS = [20261026, 20261027, 20261028]
OPTICAL = {'fusion_mlp', 'context_fusion', 'gated_fusion'}
CONTEXT = {'local_context', 'context_fusion', 'gated_fusion'}


def utc():
    return datetime.now(timezone.utc).isoformat()


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def array_digest(value):
    return hashlib.sha256(np.ascontiguousarray(value).tobytes()).hexdigest()


def write_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(data, indent=2, allow_nan=False))
    temporary.replace(path)


def masked_mean(values):
    return float(np.mean(values)) if len(values) else None


def softmax(logits):
    shifted = logits - logits.max(1, keepdims=True)
    exp = np.exp(shifted)
    return exp / exp.sum(1, keepdims=True)


def classification_metrics(labels, probabilities, rejected, original_labels):
    prediction = probabilities.argmax(1)
    confusion = np.bincount(3 * labels + prediction, minlength=9).reshape(3, 3)
    diagonal = np.diag(confusion)
    denominators = confusion.sum(0) + confusion.sum(1) - diagonal
    iou = np.divide(diagonal, denominators, out=np.zeros(3, float), where=denominators > 0)
    return {
        'records': len(labels), 'confusion': confusion.tolist(),
        'accuracy': float((labels == prediction).mean()),
        'class_iou': dict(zip(['roof', 'vegetation_or_fence_hedge', 'other'], iou.tolist())),
        'mean_iou': float(iou.mean()),
        'roof_retention': masked_mean(~rejected[labels == 0]),
        'vegetation_or_fence_hedge_rejection': masked_mean(rejected[labels == 1]),
        'tree8_rejection': masked_mean(rejected[original_labels == 8]),
        'fence_hedge4_rejection': masked_mean(rejected[original_labels == 4]),
        'rejection_fraction': float(rejected.mean()),
        'nll': float(-np.log(np.maximum(probabilities[np.arange(len(labels)), labels], 1e-9)).mean()),
    }


def calibrate(labels, logits):
    choices = [0.5, 0.7, 1.0, 1.3, 1.7, 2.0, 3.0]
    temperature = min(choices, key=lambda x: float(-np.log(np.maximum(
        softmax(logits / x)[np.arange(len(labels)), labels], 1e-9)).mean()))
    probabilities = softmax(logits / temperature)
    roof = probabilities[labels == 0, 1]
    assert len(roof) > 100, 'Insufficient independent validation roof points'
    # Strictly above the empirical upper .5% roof quantile, including ties.
    quantile = np.float32(np.quantile(roof, .995, method='higher'))
    threshold = max(0.7, float(np.nextafter(quantile, np.float32(np.inf))))
    rejected = probabilities[:, 1] >= threshold
    retention = float((~rejected[labels == 0]).mean())
    assert retention >= .995
    return {'temperature': temperature, 'threshold': threshold,
            'validation_roof_retention': retention,
            'no_validation_rejections': not bool(rejected.any()),
            'roof_retention_target': .995,
            'calibration_records': len(labels), 'calibration_roof_records': len(roof)}


class SemanticModel(nn.Module):
    def __init__(self, method, geometry_size=34, optical_size=8):
        super().__init__()
        self.method = method
        if method == 'linear':
            self.head = nn.Linear(geometry_size, 3)
            return
        self.geometry = nn.Sequential(nn.Linear(geometry_size, 64), nn.LayerNorm(64),
                                      nn.ReLU(), nn.Linear(64, 64), nn.ReLU())
        width = 64
        if method in CONTEXT:
            self.neighbor = nn.Sequential(nn.Linear(geometry_size + 3, 64), nn.ReLU(),
                                         nn.Linear(64, 64), nn.ReLU())
            self.aggregate = nn.Sequential(nn.Linear(128, 64), nn.ReLU())
            width += 64
        if method in OPTICAL:
            self.optical = nn.Sequential(nn.Linear(optical_size, 32), nn.ReLU(),
                                        nn.Linear(32, 32), nn.ReLU())
            if method == 'gated_fusion':
                self.gate = nn.Sequential(nn.Linear(width + 32 + 1, 32), nn.ReLU(),
                                          nn.Linear(32, 1), nn.Sigmoid())
            width += 32 + 1
        self.head = nn.Sequential(nn.Linear(width, 64), nn.ReLU(), nn.Dropout(.1), nn.Linear(64, 3))

    def forward(self, geometry, optical, available, neighbor_geometry=None,
                relative_xyz=None, neighbor_valid=None, return_gate=False):
        if self.method == 'linear':
            result = self.head(geometry)
            return (result, torch.zeros_like(available)) if return_gate else result
        geometry_embedding = self.geometry(geometry)
        base = geometry_embedding
        if self.method in CONTEXT:
            local = self.neighbor(torch.cat([neighbor_geometry, relative_xyz / 5.0], -1))
            mask = neighbor_valid.unsqueeze(-1)
            local_max = local.masked_fill(~mask, -1e4).max(1).values
            local_mean = (local * mask).sum(1) / mask.sum(1).clamp_min(1)
            context = self.aggregate(torch.cat([local_max, local_mean], 1))
            base = torch.cat([base, context], 1)
        gate = torch.zeros_like(available)
        if self.method in OPTICAL:
            optical_embedding = self.optical(optical)
            gate = available
            if self.method == 'gated_fusion':
                gate = self.gate(torch.cat([base, optical_embedding, available], 1)) * available
            base = torch.cat([base, optical_embedding * gate, available], 1)
        result = self.head(base)
        return (result, gate) if return_gate else result


class Scene:
    def __init__(self, name, root, normalization, device, include_labels=False):
        self.name = name
        self.source_path = SOURCE / (name + '.npz')
        data = np.load(self.source_path)
        self.xyz = data['xyz']
        self.geometry_raw = data['geometry']
        self.optical_raw = data['optical']
        self.valid_np = data['optical_valid'].astype(bool)
        self.ids = data['source_indices'] if 'source_indices' in data else np.arange(len(self.xyz))
        self.split = data['split'] if name == 'source_train' else np.zeros(len(self.xyz), np.int8)
        self.labels_np = data['labels'] if include_labels else None
        self.original_labels = data['original_labels'] if include_labels else None
        gm, gs, om, osd = [normalization[key] for key in ['gm', 'gs', 'om', 'os']]
        self.g = torch.as_tensor(np.clip((self.geometry_raw - gm) / gs, -12, 12), dtype=torch.float32, device=device)
        self.o = torch.as_tensor(np.clip((self.optical_raw - om) / osd, -12, 12), dtype=torch.float32, device=device)
        self.available = torch.as_tensor(self.valid_np[:, None], dtype=torch.float32, device=device)
        neighbors_path = root / 'data' / f'{name}_neighbors.npz'
        neighbors = np.load(neighbors_path)
        self.neighbors = torch.as_tensor(neighbors['indices'].astype(np.int64), device=device)
        self.relative = torch.as_tensor(neighbors['relative_xyz'], dtype=torch.float32, device=device)
        self.neighbor_valid = torch.as_tensor(neighbors['valid'], dtype=torch.bool, device=device)
        assert self.neighbors.shape[0] == len(self.xyz)
        assert torch.all(self.neighbor_valid[:, 0])
        self.labels = torch.as_tensor(self.labels_np, dtype=torch.long, device=device) if include_labels else None
        self.device = device
        self.shifts = None
        self.shift_valid = None

    def prepare_shifts(self, root):
        """A nearest-observed-pixel proxy, not exact original-raster resampling."""
        from scipy.spatial import cKDTree
        destination = root / 'data' / f'{self.name}_optical_shift_indices.npz'
        if destination.exists():
            data = np.load(destination)
            indices, valid = data['indices'], data['valid']
        else:
            offsets = [(1., 0.), (2., 0.), (0., 1.), (0., 2.)]
            indices = np.zeros((len(self.xyz), len(offsets)), np.int32)
            valid = np.zeros_like(indices, bool)
            for group in np.unique(self.split):
                rows = np.flatnonzero(self.split == group)
                tree = cKDTree(self.xyz[rows, :2])
                for column, offset in enumerate(offsets):
                    distances, nearest = tree.query(self.xyz[rows, :2] + offset, k=1, workers=2)
                    donor = rows[nearest]
                    indices[rows, column] = donor
                    valid[rows, column] = (distances <= .75) & self.valid_np[donor]
            np.savez_compressed(destination, indices=indices, valid=valid,
                                offsets_xy_m=np.asarray(offsets), maximum_donor_distance_m=.75)
        self.shifts = torch.as_tensor(indices.astype(np.int64), device=self.device)
        self.shift_valid = torch.as_tensor(valid, device=self.device)

    def batch(self, ids, method, augmentation=False, condition='clean', augmentation_generator=None):
        ids = torch.as_tensor(ids, dtype=torch.long, device=self.device)
        g, o, available = self.g[ids], self.o[ids].clone(), self.available[ids].clone()
        if method in OPTICAL:
            if augmentation:
                draw = torch.rand(len(ids), device=self.device, generator=augmentation_generator)
                dropped = draw < .2
                shifted = (draw >= .2) & (draw < .5)
                columns = torch.randint(0, 4, (len(ids),), device=self.device, generator=augmentation_generator)
                donors = self.shifts[ids, columns]
                o[shifted] = self.o[donors[shifted]]
                available[shifted, 0] = self.shift_valid[ids[shifted], columns[shifted]].float()
                available[dropped] = 0
            elif condition == 'missing_optical':
                available.zero_()
            elif condition.startswith('shift_'):
                column = 0 if condition == 'shift_1m' else 1
                donors = self.shifts[ids, column]
                o = self.o[donors]
                available[:, 0] = self.shift_valid[ids, column].float()
            o = o * available
        ng = relative = nv = None
        if method in CONTEXT:
            ng = self.g[self.neighbors[ids]]
            relative = self.relative[ids]
            nv = self.neighbor_valid[ids]
        return g, o, available, ng, relative, nv


def predict(model, scene, indices, batch_size, condition='clean', gate=False):
    model.eval()
    result, gates = [], []
    with torch.inference_mode():
        for start in range(0, len(indices), batch_size):
            ids = indices[start:start + batch_size]
            with torch.autocast(device_type=scene.device.type, dtype=torch.bfloat16,
                                enabled=scene.device.type == 'cuda'):
                output = model(*scene.batch(ids, model.method, condition=condition), return_gate=gate)
            if gate:
                values, weights = output
                gates.append(weights.float().cpu().numpy())
            else:
                values = output
            result.append(values.float().cpu().numpy())
    values = np.concatenate(result)
    return (values, np.concatenate(gates)) if gate else values


def freeze_checkpoint(model, path, config, cal_common, cal_full, best_epoch, best_loss):
    torch.save({'state_dict': {key: value.detach().cpu() for key, value in model.state_dict().items()},
                'method': model.method, 'config': config, 'calibration_common': cal_common,
                'calibration_full': cal_full, 'best_epoch': best_epoch,
                'best_validation_ce': best_loss}, path)
    return digest(path)


def load_model(path, device):
    checkpoint = torch.load(path, map_location=device, weights_only=False)
    model = SemanticModel(checkpoint['method']).to(device)
    model.load_state_dict(checkpoint['state_dict'])
    model.eval()
    return model, checkpoint


def train_one(method, seed, scene, train_ids, val_ids, val_full_ids, config, root, status, deadline):
    started = time.time()
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    rng = np.random.default_rng(seed)
    augmentation_generator = torch.Generator(device=scene.device).manual_seed(seed + 12345)
    model = SemanticModel(method).to(scene.device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=config['learning_rate'], weight_decay=1e-4)
    run = root / 'runs' / f'{method}_seed{seed}'
    run.mkdir(parents=True, exist_ok=True)
    checkpoint_path = run / 'model.pt'
    summary_path = run / 'training.json'
    best, best_loss, best_epoch, stale = None, float('inf'), 0, 0
    history = []
    for epoch in range(config['epochs']):
        if time.time() > deadline:
            raise TimeoutError('Declared total training time budget reached; no test evaluation performed')
        tick = time.time()
        model.train()
        permutation = rng.permutation(train_ids)
        losses = []
        augmented = method in {'context_fusion', 'gated_fusion'}
        for start in range(0, len(permutation), config['batch_size']):
            ids = permutation[start:start + config['batch_size']]
            optimizer.zero_grad(set_to_none=True)
            with torch.autocast(device_type=scene.device.type, dtype=torch.bfloat16,
                                enabled=scene.device.type == 'cuda'):
                values = model(*scene.batch(ids, method, augmentation=augmented,
                    augmentation_generator=augmentation_generator))
                loss = nn.functional.cross_entropy(values, scene.labels[ids])
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()
            losses.append(float(loss.detach()))
        validation_logits = predict(model, scene, val_ids, config['inference_batch_size'])
        validation_loss = float(-np.log(np.maximum(
            softmax(validation_logits)[np.arange(len(val_ids)), scene.labels_np[val_ids]], 1e-9)).mean())
        history.append({'epoch': epoch + 1, 'train_ce': float(np.mean(losses)),
                        'validation_ce': validation_loss, 'seconds': time.time() - tick})
        if validation_loss < best_loss - 1e-5:
            best_loss, best_epoch, stale = validation_loss, epoch + 1, 0
            best = {key: value.detach().cpu().clone() for key, value in model.state_dict().items()}
        else:
            stale += 1
        progress = dict(status, phase='training', method=method, seed=seed,
                        epoch=epoch + 1, best_epoch=best_epoch,
                        last_validation_ce=validation_loss, updated_utc=utc())
        write_json(root / 'reports/run_status.json', progress)
        write_json(run / 'history.json', history)
        print(f'{method} seed={seed} epoch={epoch + 1} val_ce={validation_loss:.5f} sec={time.time()-tick:.2f}', flush=True)
        if stale >= config['patience'] and epoch + 1 >= config['minimum_epochs']:
            break
    assert best is not None
    model.load_state_dict(best)
    lv = predict(model, scene, val_ids, config['inference_batch_size'])
    cal_common = calibrate(scene.labels_np[val_ids], lv)
    if len(val_ids) == len(val_full_ids) and np.array_equal(val_ids, val_full_ids):
        full_logits = lv
    else:
        full_logits = predict(model, scene, val_full_ids, config['inference_batch_size'])
    cal_full = calibrate(scene.labels_np[val_full_ids], full_logits)
    checkpoint_hash = freeze_checkpoint(model, checkpoint_path, config, cal_common, cal_full, best_epoch, best_loss)
    probabilities = softmax(lv / cal_common['temperature'])
    validation_metrics = classification_metrics(scene.labels_np[val_ids], probabilities,
        probabilities[:, 1] >= cal_common['threshold'], scene.original_labels[val_ids])
    report = {'method': method, 'seed': seed, 'status': 'frozen', 'checkpoint': str(checkpoint_path),
              'checkpoint_sha256': checkpoint_hash, 'frozen_utc': utc(),
              'train_ids_sha256': config['train_ids_sha256'],
              'validation_ids_sha256': config['validation_ids_sha256'],
              'normalization_sha256': config['normalization_sha256'],
              'script_sha256': config['script_sha256'],
              'epochs_completed': len(history), 'best_epoch': best_epoch,
              'best_validation_ce': best_loss, 'parameters': sum(x.numel() for x in model.parameters()),
              'calibration_common': cal_common, 'calibration_full': cal_full,
              'validation_common': validation_metrics,
              'augmentation': {'optical_dropout_probability': .2 if augmented else 0,
                               'optical_shift_probability': .3 if augmented else 0,
                               'shift_proxy_m': [1, 2] if augmented else []},
              'seconds': time.time() - started}
    write_json(summary_path, report)
    del model
    return report


def evaluate_scene(scene, root, frozen, config, is_target=False):
    rows = np.arange(len(scene.xyz))
    common = scene.valid_np
    report, target_arrays = {}, {}
    fallback_by_seed = {}
    for seed in config['seeds']:
        point_run = next(x for x in frozen if x['seed'] == seed and x['method'] == 'point_mlp')
        model, checkpoint = load_model(point_run['checkpoint'], scene.device)
        raw = predict(model, scene, rows, config['inference_batch_size'])
        calibration = checkpoint['calibration_full']
        fallback_by_seed[seed] = (softmax(raw / calibration['temperature']), calibration['threshold'])
        del model
    for index, item in enumerate(frozen):
        method, seed = item['method'], item['seed']
        model, checkpoint = load_model(item['checkpoint'], scene.device)
        conditions = ['clean'] if is_target or method not in OPTICAL else ['clean', 'shift_1m', 'shift_2m', 'missing_optical']
        condition_reports = {}
        for condition in conditions:
            logits, gates = predict(model, scene, rows, config['inference_batch_size'], condition, gate=True)
            calibration_common = checkpoint['calibration_common']
            calibration_full = checkpoint['calibration_full']
            common_probabilities = softmax(logits / calibration_common['temperature'])
            all_probabilities = softmax(logits / calibration_full['temperature'])
            available = scene.valid_np.copy()
            if condition == 'missing_optical':
                available[:] = False
            elif condition.startswith('shift_'):
                column = 0 if condition == 'shift_1m' else 1
                available = scene.shift_valid[:, column].cpu().numpy()
            thresholds = np.full(len(rows), calibration_full['threshold'], np.float64)
            if method in OPTICAL:
                fallback_probabilities, fallback_threshold = fallback_by_seed[seed]
                all_probabilities[~available] = fallback_probabilities[~available]
                thresholds[~available] = fallback_threshold
            rejection = all_probabilities[:, 1] >= thresholds
            if is_target:
                destination = root / 'runs' / f'{method}_seed{seed}' / 'target_predictions.npz'
                np.savez_compressed(destination, source_indices=scene.ids,
                    probabilities=all_probabilities.astype(np.float32), reject=rejection,
                    native_threshold=calibration_full['threshold'],
                    fallback_threshold=fallback_by_seed[seed][1],
                    optical_available=available, gate=gates.reshape(-1).astype(np.float32))
                target_arrays[f'{method}_seed{seed}'] = all_probabilities.astype(np.float32)
                condition_reports[condition] = {'records': len(rows), 'rejected': int(rejection.sum()),
                    'rejection_fraction': float(rejection.mean()), 'optical_coverage': float(available.mean()),
                    'output': str(destination), 'output_sha256': digest(destination),
                    'mean_gate_when_image_available': masked_mean(gates.reshape(-1)[available]),
                    'target_semantic_GT_available': False}
            else:
                common_reject = common_probabilities[:, 1] >= calibration_common['threshold']
                condition_reports[condition] = {
                    'common_original_optical_coverage': classification_metrics(scene.labels_np[common],
                        common_probabilities[common], common_reject[common], scene.original_labels[common]),
                    'full_scene_with_point_fallback': classification_metrics(scene.labels_np,
                        all_probabilities, rejection, scene.original_labels),
                    'current_optical_coverage': float(available.mean()),
                    'common_metric_uses_native_model_without_fallback': True,
                    'mean_gate_when_image_available': masked_mean(gates.reshape(-1)[available]),
                    'fallback': 'point_mlp same seed, own calibration_full temperature and threshold' if method in OPTICAL else None,
                    'shift_proxy': 'nearest point optical descriptor at XY+offset; max donor distance .75m; no original-raster resampling' if condition.startswith('shift_') else None,
                }
        report[f'{method}_seed{seed}'] = condition_reports
        del model
        write_json(root / 'reports/run_status.json', {'phase': 'target_inference' if is_target else 'source_test_evaluation',
            'completed_models': index + 1, 'total_models': len(frozen), 'updated_utc': utc(),
            'method': method, 'seed': seed})
        write_json(root / 'reports' / ('target_partial.json' if is_target else 'test_partial.json'), report)
    if is_target:
        np.savez_compressed(root / 'data/target_predictions.npz', source_indices=scene.ids, **target_arrays)
    return report


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, default=DEFAULT_ROOT)
    parser.add_argument('--methods', nargs='+', default=METHODS, choices=METHODS)
    parser.add_argument('--seeds', nargs='+', type=int, default=SEEDS)
    parser.add_argument('--epochs', type=int, default=40)
    parser.add_argument('--batch-size', type=int, default=2048)
    parser.add_argument('--inference-batch-size', type=int, default=4096)
    parser.add_argument('--max-train', type=int, default=200000)
    parser.add_argument('--max-wall-seconds', type=int, default=14400)
    parser.add_argument('--smoke', action='store_true')
    parser.add_argument('--resume', action='store_true')
    args = parser.parse_args()
    started = time.time()
    root = args.root
    for directory in ['data', 'runs', 'reports', 'cache']:
        (root / directory).mkdir(parents=True, exist_ok=True)
    torch.set_num_threads(4)
    torch.backends.cuda.matmul.allow_tf32 = True
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    if not args.smoke and device.type != 'cuda':
        raise RuntimeError('Production round requires the declared GPU allocation; CPU smoke only is allowed')
    raw = np.load(SOURCE / 'source_train.npz')
    common = raw['optical_valid'].astype(bool)
    split = raw['split']
    rng = np.random.default_rng(20261026)
    train_ids = np.flatnonzero((split == 0) & common)
    train_ids = rng.permutation(train_ids)[:args.max_train if not args.smoke else 4096]
    val_ids = np.flatnonzero((split == 1) & common)
    val_full_ids = np.flatnonzero(split == 1)
    if args.smoke:
        # Do not evaluate official test, and keep smoke outputs outside production root.
        val_ids = rng.permutation(val_ids)[:4096]
        val_full_ids = val_ids
        args.epochs, args.seeds = 2, args.seeds[:1]
    geometry, optical = raw['geometry'], raw['optical']
    norm = {'gm': geometry[train_ids].mean(0), 'gs': np.maximum(geometry[train_ids].std(0), .03),
            'om': optical[train_ids].mean(0), 'os': np.maximum(optical[train_ids].std(0), .03)}
    normalization_path = root / 'data/normalization.npz'
    if args.resume and normalization_path.exists():
        previous_norm = np.load(normalization_path)
        assert all(np.array_equal(norm[key], previous_norm[key]) for key in norm)
    else:
        np.savez(normalization_path, **norm)
    config = {'created_utc': utc(), 'methods': args.methods, 'seeds': args.seeds,
        'epochs': args.epochs, 'minimum_epochs': 8 if not args.smoke else 2,
        'patience': 6, 'batch_size': args.batch_size, 'inference_batch_size': args.inference_batch_size,
        'learning_rate': .001, 'training_records': len(train_ids), 'validation_records': len(val_ids),
        'validation_full_records': len(val_full_ids), 'train_ids_sha256': array_digest(train_ids),
        'validation_ids_sha256': array_digest(val_ids), 'normalization_sha256': digest(normalization_path),
        'train_only_normalization': True, 'source_train_sha256': digest(SOURCE / 'source_train.npz'),
        'script_sha256': digest(__file__), 'feature_source': 'existing frozen 34 label-free geometric and 8 optical descriptors',
        'optical_bands': ['Red', 'Green', 'NIR'], 'blue_band_available': False,
        'optical_pixel_size_m': 1., 'device': str(device),
        'gpu_name': torch.cuda.get_device_name(0) if device.type == 'cuda' else None,
        'slurm_job_id': os.environ.get('SLURM_JOB_ID'),
        'slurm_step_id': os.environ.get('SLURM_STEP_ID'),
        'context': {'k': 16, 'radius_m': 5, 'labels_in_features': False,
                    'new_neighbors_cross_split': False,
                    'existing_geometry_descriptors_use_full_unlabeled_scene': True},
        'class_mapping': {'roof': [5], 'vegetation_or_fence_hedge': [1, 4, 7, 8], 'other': [0, 2, 3, 6]},
        'source_test_historically_evaluated': True, 'test_used_for_training_selection': False,
        'target_labels_available': False, 'roof_retention_validation_target': .995,
        'augmentation_isolation': 'context_fusion and gated_fusion use the same per-seed separate augmentation RNG and same sample order: .2 dropout/.3 shift; gate is the architecture ablation',
        'gate_supervision': 'three-class source-label cross-entropy only; no direct gate labels and no real temporal-change supervision',
        'smoke': args.smoke, 'wall_budget_seconds': args.max_wall_seconds}
    np.savez(root / 'data/selected_rows.npz', train_ids=train_ids, validation_ids=val_ids, validation_full_ids=val_full_ids)
    write_json(root / 'reports/training_design.json', config)
    del raw, geometry, optical
    scene = Scene('source_train', root, norm, device, include_labels=True)
    scene.prepare_shifts(root)
    status = {'started_utc': config['created_utc'], 'phase': 'prepared', 'total_models': len(args.methods) * len(args.seeds),
              'pid': os.getpid(), 'device': str(device), 'gpu_name': config['gpu_name'], 'updated_utc': utc()}
    write_json(root / 'reports/run_status.json', status)
    frozen = []
    try:
        for seed in args.seeds:
            for method in args.methods:
                path = root / 'runs' / f'{method}_seed{seed}' / 'training.json'
                if args.resume and path.exists():
                    run = json.loads(path.read_text())
                    assert run['checkpoint_sha256'] == digest(run['checkpoint'])
                    assert run['train_ids_sha256'] == config['train_ids_sha256']
                    assert run['validation_ids_sha256'] == config['validation_ids_sha256']
                    assert run['normalization_sha256'] == config['normalization_sha256']
                    assert run['script_sha256'] == config['script_sha256']
                    previous = torch.load(run['checkpoint'], map_location='cpu', weights_only=False)['config']
                    for setting in ['methods', 'seeds', 'epochs', 'minimum_epochs', 'patience', 'batch_size',
                                    'learning_rate', 'source_train_sha256', 'augmentation_isolation']:
                        assert previous[setting] == config[setting], f'Resume design mismatch: {setting}'
                else:
                    run = train_one(method, seed, scene, train_ids, val_ids, val_full_ids, config, root, status,
                                    started + args.max_wall_seconds)
                frozen.append(run)
                write_json(root / 'reports/training_progress.json', {'models': frozen, 'total_models': status['total_models'],
                                                                       'updated_utc': utc()})
        assert digest(SOURCE / 'source_train.npz') == config['source_train_sha256']
        assert digest(__file__) == config['script_sha256']
        freeze = {'freeze_utc': utc(), 'config': config, 'models': frozen,
                  'train_ids_sha256': config['train_ids_sha256'],
                  'validation_ids_sha256': config['validation_ids_sha256'],
                  'train_only_normalization_sha256': config['normalization_sha256'],
                  'source_test_historically_evaluated': True,
                  'official_test_read_in_this_run_before_freeze': False}
        write_json(root / 'reports/training_freeze.json', freeze)
        del scene
        if device.type == 'cuda':
            torch.cuda.empty_cache()
        if args.smoke:
            write_json(root / 'reports/smoke_complete.json', {'status': 'passed', 'models': len(frozen),
                'official_test_evaluated': False, 'elapsed_seconds': time.time() - started})
            return
        test_started = utc()
        test = Scene('source_test', root, norm, device, include_labels=True)
        test.prepare_shifts(root)
        source_metrics = evaluate_scene(test, root, frozen, config)
        source_input_hash = digest(SOURCE / 'source_test.npz')
        del test
        if device.type == 'cuda':
            torch.cuda.empty_cache()
        target = Scene('target', root, norm, device, include_labels=False)
        target_metrics = evaluate_scene(target, root, frozen, config, is_target=True)
        target_hash = digest(SOURCE / 'target.npz')
        final = {'status': 'complete', 'completed_utc': utc(), 'training_freeze_sha256': digest(root / 'reports/training_freeze.json'),
                 'test_evaluation_started_utc': test_started, 'source_test_historically_evaluated': True,
                 'source_test_sha256': source_input_hash, 'target_input_sha256': target_hash,
                 'official_source_reference': source_metrics, 'target_diagnostics': target_metrics,
                 'target_semantic_accuracy_available': False, 'elapsed_seconds': time.time() - started,
                 'limitations': ['Per-point semantics only; no learned roof-plane correction or occlusion completion',
                    'No independent target-domain semantic or LoD2 reference labels',
                    'Engineered geometric descriptors predate this round and use unlabeled full-scene context',
                    'Shift conditions use nearest-point descriptors as a raster misregistration proxy',
                    'Source validation is one contiguous region; results need additional geographic validation']}
        write_json(root / 'reports/final_metrics.json', final)
        write_json(root / 'reports/run_status.json', {'phase': 'complete', 'completed_models': len(frozen),
                    'total_models': len(frozen), 'updated_utc': utc(), 'elapsed_seconds': time.time() - started})
        print('COMPLETE', time.time() - started, flush=True)
    except BaseException as error:
        write_json(root / 'reports/run_status.json', {'phase': 'failed', 'updated_utc': utc(),
            'error_type': type(error).__name__, 'error': str(error), 'completed_models': len(frozen),
            'total_models': status['total_models'], 'elapsed_seconds': time.time() - started})
        raise


if __name__ == '__main__':
    main()
