#!/usr/bin/env python3
"""Bounded stdlib-only supervisor. It never trains, changes code, or cancels jobs."""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

from audit_training import audit as audit_training_receipts

CODE = Path(__file__).resolve().parents[1]
ROOT = Path('/lustre/isaac24/scratch/yfeng21/lod2_dl_round_20261026')
PLAN = CODE / 'manager_plan.json'
OLD = Path('/nfs/home/yfeng21/lod2_tree_20261020')
INPUTS = [
    OLD/'data/source_train.npz', OLD/'data/source_test.npz',
    OLD/'data/target.npz', OLD/'data/target_buildings.json',
    Path('/nfs/home/yfeng21/lod2_pilot_20261017/data/lidar/roi_points.npz'),
    Path('/nfs/home/yfeng21/lod2_pilot_20261017/data/imagery/naip2014_roi_rgbnir_epsg26985.tif'),
]


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        while data := f.read(8*1024*1024):
            h.update(data)
    return h.hexdigest()


def atomic_json(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(obj, indent=2) + '\n')
    os.replace(tmp, path)


def read_json(path, issues):
    try:
        return json.loads(path.read_text())
    except (OSError, ValueError) as e:
        issues.append({'severity': 'error', 'code': 'invalid_json', 'path': str(path), 'detail': str(e)})
        return None


def immutable_receipt(root):
    path = root/'reports/manager_input_freeze.json'
    if path.exists():
        return json.loads(path.read_text())
    records = []
    for p in INPUTS:
        q = p.resolve()
        records.append({'path': str(p), 'resolved_path': str(q), 'bytes': q.stat().st_size,
                        'mtime_ns': q.stat().st_mtime_ns, 'sha256': digest(q)})
    receipt = {'recorded_utc': now(), 'round': root.name,
               'description': 'Byte receipts only; source test labels are not loaded by this supervisor',
               'inputs': records}
    atomic_json(path, receipt)
    return receipt


def inspect(root, jobs, verify_bytes=False):
    issues = []
    plan = json.loads(PLAN.read_text())
    if not str(root.resolve()).startswith('/lustre/isaac24/scratch/yfeng21/'):
        raise RuntimeError('Artifacts must resolve under user Lustre scratch')
    receipt = immutable_receipt(root)
    source_freeze = root/'reports/manager_source_freeze.json'
    source_checks = []
    if source_freeze.exists():
        for record in json.loads(source_freeze.read_text())['files']:
            p = Path(record['path'])
            passed = p.exists() and digest(p) == record['sha256']
            source_checks.append({'path': str(p), 'unchanged': passed})
            if not passed:
                issues.append({'severity': 'error', 'code': 'frozen_source_changed', 'path': str(p)})
    checked = []
    for record in receipt['inputs']:
        p = Path(record['path'])
        try:
            st = p.stat()
            same_stat = st.st_size == record['bytes'] and st.st_mtime_ns == record['mtime_ns']
            same_hash = digest(p) == record['sha256'] if verify_bytes or not same_stat else None
            passed = same_hash if same_hash is not None else same_stat
            checked.append({'path': str(p), 'same_size_mtime': same_stat, 'sha256_rechecked': same_hash,
                            'unchanged': bool(passed)})
            if not passed:
                issues.append({'severity': 'error', 'code': 'immutable_input_changed', 'path': str(p)})
        except OSError as e:
            issues.append({'severity': 'error', 'code': 'immutable_input_missing', 'path': str(p), 'detail': str(e)})

    files = {}
    paths = set(root.glob('reports/*.json'))
    paths.update(root.glob('runs/*/progress.json'))
    paths.update(root.glob('runs/*/status.json'))
    newest_progress = None
    for p in sorted(paths):
        if p.name.startswith('manager_') or p.name == 'supervisor_status.json':
            continue
        value = read_json(p, issues)
        files[str(p.relative_to(root))] = {'mtime_utc': dt.datetime.fromtimestamp(p.stat().st_mtime, dt.timezone.utc).isoformat(),
                                        'bytes': p.stat().st_size, 'status': value.get('status') if isinstance(value, dict) else None}
        if any(x in p.name for x in ('status', 'progress', 'metrics', 'completion')):
            newest_progress = max(newest_progress or 0, p.stat().st_mtime)
        if isinstance(value, dict):
            for key in ('test_labels_used_to_tune', 'target_metrics_used_to_tune', 'target_domain_supervision'):
                if value.get(key) is True:
                    issues.append({'severity': 'error', 'code': 'scientific_gate_violation', 'path': str(p), 'field': key})

    try:
        training_audit = audit_training_receipts(root)
        atomic_json(root/'reports/manager_training_audit.json', training_audit)
        for detail in training_audit['errors']:
            issues.append({'severity': 'error', 'code': 'training_receipt_violation', 'detail': detail})
    except (OSError, ValueError, KeyError) as e:
        training_audit = {'status': 'audit_error', 'error': str(e)}
        issues.append({'severity': 'error', 'code': 'training_receipt_audit_error', 'detail': str(e)})

    state_path = root/'reports/run_status.json'
    if state_path.exists():
        state = read_json(state_path, issues)
        if isinstance(state, dict) and state.get('phase') == 'failed':
            issues.append({'severity': 'error', 'code': 'training_failed', 'detail': state.get('error', 'See run_status.json')})

    checkpoints = [{'path': str(p.relative_to(root)), 'bytes': p.stat().st_size,
                    'mtime_utc': dt.datetime.fromtimestamp(p.stat().st_mtime, dt.timezone.utc).isoformat()}
                   for suffix in ('*.pt', '*.pth') for p in (root/'runs').glob('**/'+suffix)]
    age = (time.time()-newest_progress)/60 if newest_progress else None
    if age is not None and age > plan['supervision']['stale_after_minutes']:
        issues.append({'severity': 'warning', 'code': 'stale_progress', 'minutes': round(age, 2)})

    scheduler = {}
    for jid in jobs:
        if not jid.isdigit():
            raise ValueError('Only explicit numeric scheduler job IDs are supported')
        try:
            r = subprocess.run(['scontrol', 'show', 'job', jid, '-o'], capture_output=True, text=True, timeout=20)
            scheduler[jid] = {'returncode': r.returncode, 'output': r.stdout.strip(), 'error': r.stderr.strip()}
        except (OSError, subprocess.TimeoutExpired) as e:
            scheduler[jid] = {'error': str(e)}

    errors = sum(i['severity'] == 'error' for i in issues)
    warnings = sum(i['severity'] == 'warning' for i in issues)
    result = {
        'recorded_utc': now(), 'status': 'review_failed' if errors else 'monitoring',
        'supervisor': 'bounded independent stdlib observer; no autonomous code edits or job cancellation',
        'plan_sha256': digest(PLAN), 'immutable_inputs': checked,
        'frozen_source_checks': source_checks, 'training_receipt_audit': training_audit,
        'progress_files': files, 'checkpoint_count': len(checkpoints), 'checkpoints': checkpoints,
        'newest_progress_age_minutes': age, 'scheduler': scheduler,
        'issues': issues, 'error_count': errors, 'warning_count': warnings,
        'scientific_limits': plan['data_provenance'],
        'pending_scientific_review': [
            'Shared train/val hashes and train-only normalization need explicit training receipts',
            'All checkpoint/threshold freezes must precede this-round test metrics',
            'Context labels must never be inputs; source class4 is mixed fence/hedge',
            'No independent DC tree/roof accuracy or complete occluded-roof claim',
            'Negative results and seed variation remain visible'
        ]
    }
    atomic_json(root/'reports/manager_review.json', result)
    with (root/'reports/supervisor_events.jsonl').open('a') as f:
        f.write(json.dumps({'recorded_utc': result['recorded_utc'], 'status': result['status'],
                            'errors': errors, 'warnings': warnings, 'checkpoints': len(checkpoints),
                            'progress_files': len(files), 'newest_progress_age_minutes': age})+'\n')
    return result


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root', type=Path, default=ROOT)
    ap.add_argument('--hours', type=float, default=0, help='0 performs a single snapshot; bounded max8h')
    ap.add_argument('--interval', type=float, default=120)
    ap.add_argument('--job', action='append', default=[])
    ap.add_argument('--verify-bytes', action='store_true', help='Rehash all inputs, not just changed size/mtime')
    ap.add_argument('--until-pipeline-finished', action='store_true',
                    help='Exit after final inspection when pipeline_status phase is complete/failed/stopped')
    args = ap.parse_args()
    if not 0 <= args.hours <= 8 or args.interval < 10:
        ap.error('hours must be0..8 and interval at least10 seconds')
    stop = time.monotonic()+args.hours*3600
    while True:
        report = inspect(args.root, args.job, args.verify_bytes)
        print(json.dumps({k: report[k] for k in ['recorded_utc', 'status', 'error_count', 'warning_count', 'checkpoint_count']}), flush=True)
        pipeline_finished = False
        pipeline = args.root/'reports/pipeline_status.json'
        if args.until_pipeline_finished and pipeline.exists():
            try:
                phase = json.loads(pipeline.read_text()).get('phase')
                pipeline_finished = phase in {'complete', 'failed', 'stopped'}
            except (OSError, ValueError):
                pass
        if not args.hours or time.monotonic() >= stop or report['error_count'] or pipeline_finished:
            break
        time.sleep(min(args.interval, max(0, stop-time.monotonic())))
    return 1 if report['error_count'] else 0


if __name__ == '__main__':
    raise SystemExit(main())
