# LoD2 semantic filtering experiment, 2026-10-26

Train six source-supervised point classifiers with three fixed seeds. Predict
roof / vegetation-or-fence-hedge / other, calibrating deletion thresholds only
on the spatial source validation area for at least 99.5% roof retention.
Learned neighborhood aggregation and a reliability gate are tested separately.
The gate and its ungated control share the same augmentation draws.

The source image supplies R/G/NIR descriptors, not RGB patches. The US input is
NAIP plus 3DEP with frozen, registered footprints. All original XYZ and source
indices remain unchanged. This experiment does not train roof completion.

All 120 US buildings receive predictions. The predeclared 24-case subset is
reconstructed using the same native Roofer settings, ground and footprints.
Eight input policies comprise raw, historical guarded, and the six new models
at seed 20261026. Identical point selections reuse the same native execution.
Source accuracy and US reconstruction diagnostics are reported separately.
There is no independent local semantic or roof GT. The official source test
was used in historical experiments, and is not a new blind benchmark.

Source code and small configuration are here. Datasets, weights, logs, results,
exports and caches are under
`/lustre/isaac24/scratch/yfeng21/lod2_dl_round_20261026`.
The existing GitHub Pages destination is `research-daily/lod2/dl/`.

The manager agent reviews the design and code. The bounded supervisor records
progress and immutable-input checks on the compute allocation; it does not
launch a new Codex backend or rewrite models autonomously.
